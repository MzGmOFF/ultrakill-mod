package com.ultrakillmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;

/**
 * Spear lunge (client side): LMB, then key 2 (the spear), then key 7 (back to the free slot). You do the sprint jump,
 * then press the key (H). It clicks with the free slot already in hand: the tutorial's rule is that the switch comes
 * AFTER the click ("switch + left click" does not work), so if another slot is selected it first moves to the
 * free slot and waits PREP_TICKS before it clicks. Slot numbers are 0-based (hotbar slot 2 = index 1).
 */
public final class SpearLunge {
    private static final int FREE_SLOT = 6;            // hotbar slot 7: empty (or an item with an instant cooldown)
    private static final int SPEAR_SLOT = 1;           // hotbar slot 2: the spear
    private static final int PREP_TICKS = 2;           // wait after moving to the free slot, before the click
    private static final int GAP_CLICK_TO_SPEAR = 1;   // ticks between the click and key 2 (0 = same tick)
    private static final int GAP_SPEAR_TO_FREE = 1;    // ticks between key 2 and key 7 (0 = same tick)

    private static int step = 0;                       // 0 idle, 1 click, 2 key 2, 3 key 7
    private static int wait = 0;

    private SpearLunge() {}

    public static void start(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        if (player == null || client.interactionManager == null || step != 0) return;
        if (player.getInventory().getSelectedSlot() != FREE_SLOT) {
            selectSlot(player, FREE_SLOT);             // get onto the free slot first, click a moment later
            wait = PREP_TICKS;
        } else {
            wait = 0;
        }
        step = 1;
        run(client);
    }

    /** Called every client tick: carries on with the sequence after each gap. */
    public static void tick(MinecraftClient client) {
        if (step == 0) return;
        if (wait > 0) wait--;
        run(client);
    }

    private static void run(MinecraftClient client) {
        while (step != 0 && wait == 0) {
            ClientPlayerEntity player = client.player;
            if (player == null || client.interactionManager == null) {
                step = 0;
                return;
            }
            if (step == 1) {                           // LMB: invoke the same vanilla attack action as a real left click
                client.doAttack();
                step = 2;
                wait = GAP_CLICK_TO_SPEAR;
            } else if (step == 2) {                    // key 2: the spear
                selectSlot(player, SPEAR_SLOT);
                step = 3;
                wait = GAP_SPEAR_TO_FREE;
            } else {                                   // key 7: back to the free slot
                selectSlot(player, FREE_SLOT);
                step = 0;
            }
        }
    }

    private static void selectSlot(ClientPlayerEntity player, int slot) {
        player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(slot));
        player.getInventory().setSelectedSlot(slot);
    }

}
