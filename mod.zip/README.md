# ULTRAKILL Mod (Fabric 1.21.11)

Keys (rebind in Controls > ULTRAKILL):
- X: dash (3 charges)
- Z: slide (low crawl pose, fits under 1-block gaps; dash into slide for extra speed, jump to cancel)
- V: cycle revolver variant (Piercer -> Marksman -> Sharpshooter)
- Right click: fire
- Marksman (green) only: left click tosses a coin; shoot it to ricochet to other coins, then the nearest enemy
- Shift in mid-air (2+ blocks above ground): ground slam, no fall damage, shockwave hurts nearby mobs
- H: breach swap, one tick, in the order of the tutorial: LMB (hit with the sword) -> slot 8 (mace) -> slot 5 (sword) (BreachSwap.java, slots at the top).
- O: stun slam combo over 2 ticks (attribute swap): slot 2 -> 3 + hit, then slot 2 -> 8 + hit. Works any time, no item checks
- I: cycles the sparring bot: sword mode -> spear mace mode -> off. It targets the closest player (set ONLY_LISTED = true in SparBot.java to limit it to the PARTNERS name list). Auto totem (a new totem into the off-hand right after every pop), and no jump hits in the sword fight. No pearls.


HUD: worn armor and durability are shown left of the hotbar (red blinking ! under 10%). Potion effects are shown top-right as icons with the timer on them (green = helpful, red = harmful, flashing under 15 s).

Get the guns: Creative inventory > Combat tab, or
/give @s ultrakill:marksman_revolver
- J: spar bot difficulty: ADAPTIVE (default, ramps up when you are beating it) / EASY / NORMAL / HARD / INSANE (instant aim, no reaction delay, 1-tick sprint resets, hits at 90% charge, spaces itself out of reach). No jump crits and no jump hits: in sword mode the bot never jumps, it sprint-hits, W-taps and S-taps (steps back during the sprint reset when it is tight on you), strafes constantly and keeps itself at max reach.



Spear mace mode (2nd stop of the I key): items are found by type anywhere on the hotbar (wind charges, a spear, a mace, a sword) and refilled from the inventory when they run out, so there is no fixed layout. From 3-7 blocks away a run goes: wind charge thrown at its own feet while jumping (launch), spear dash toward the target (spear + attack in the same tick), mace smash when it is close and falling (the stun slam swap: spear slot -> mace slot -> hit), then it does it again. Between runs it fights with the sword (or the spear). SM_* constants at the top of the spear mace section in SparBot.java.

Auto-off at the end of a round (STOP_AT_ROUND_END in SparBot.java): the bot switches itself off and shows "Spar bot: ..., OFF". Press I and the same mode comes back. It stops on: a server title or game message with a phrase from END_PHRASES ("Match over", "You won", "Defeat", ...) or just "Win" / "Lose", ANY server title after 5 s of real fighting (so the 3-2-1-FIGHT countdown is ignored), you dying (the death screen), the target dying / being removed, or the target being gone for 3 s. A totem pop (yours or theirs) does NOT stop it. The title hook is a mixin (InGameHudMixin, require = 0) and the message hook is a Fabric event.
