# ULTRAKILL Mod (Fabric 1.21.11)

Keys (rebind in Controls > ULTRAKILL):
- X: dash (3 charges)
- Z: slide (low crawl pose, fits under 1-block gaps; dash into slide for extra speed, jump to cancel)
- V: cycle revolver variant (Piercer -> Marksman -> Sharpshooter)
- Right click: fire
- Marksman (green) only: left click tosses a coin; shoot it to ricochet to other coins, then the nearest enemy
- Space in mid-air: double jump (much higher than a normal jump)
- Shift in mid-air (2+ blocks above ground): ground slam, no fall damage, shockwave hurts nearby mobs
- O: stun slam combo over 2 ticks (attribute swap): slot 2 -> 3 + hit, then slot 2 -> 8 + hit. Works any time, no item checks

HUD: worn armor and durability are shown left of the hotbar.

Get the guns: Creative inventory > Combat tab, or
/give @s ultrakill:marksman_revolver
