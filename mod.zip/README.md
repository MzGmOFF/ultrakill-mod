# ULTRAKILL Mod (Fabric 1.21.11)

Keys (rebind in Controls > ULTRAKILL):
- X: dash (3 charges)
- Z: slide (low crawl pose, fits under 1-block gaps; dash into slide for extra speed, jump to cancel)
- V: cycle revolver variant (Piercer -> Marksman -> Sharpshooter)
- Right click: fire
- Marksman (green) only: left click tosses a coin; shoot it to ricochet to other coins, then the nearest enemy
- Space in mid-air: double jump (much higher than a normal jump)
- Shift in mid-air (2+ blocks above ground): ground slam, no fall damage, shockwave hurts nearby mobs
- O: stun slam combo over 2 ticks (attribute swap): slot 2 -> 3 + hit, then slot 2 -> 8 + hit. Works any time, no item checks
- I: cycles the sparring bot: sword mode -> crystal mode -> UHC mode -> off. Slots: pearls 1, axe 3 (shield break), sword 5, crystals 6, obsidian 9. Crystal mode pearls in from far away, pops crystals with the sword with no waiting, and spams crystals when you are boxed in. Auto totem. Only targets the usernames listed in SparBot.java (PARTNERS)

HUD: worn armor and durability are shown left of the hotbar (red blinking ! under 10%). Potion effects are shown top-right as icons with the timer on them (green = helpful, red = harmful, flashing under 15 s).

Get the guns: Creative inventory > Combat tab, or
/give @s ultrakill:marksman_revolver
- J: spar bot difficulty: ADAPTIVE (default, ramps up when you are beating it) / EASY / NORMAL / HARD / INSANE (instant aim, no reaction delay, 1-tick sprint resets, hits at 90% charge, spaces itself out of reach). No jump crits and no jump hits: in sword mode the bot never jumps, it sprint-hits, W-taps and S-taps (steps back during the sprint reset when it is tight on you), strafes constantly and keeps itself at max reach.


UHC mode (third press of I): the bot plays UHC. Items are found by type anywhere on the hotbar (arrows anywhere in the inventory), nothing has a fixed slot except the pearl in slot 1:
- golden apple: eats when under 6 hearts and it has room (or under 3.5 hearts), backing away while it eats
- bow: full draw with lead and arrow drop from 7+ blocks; fishing rod: cast + reel from 3.6-7 blocks
- cobweb on your feet just before the fight; lava on your feet from 3.5-4.4 blocks, then it scoops the lava back up (UHC_LAVA in SparBot.java turns this off)
- water bucket: water clutch on long falls, puts itself out when on fire, and always picks the water back up
- blocks: pillars up to you when you are 2+ blocks above it, bridges across gaps; cuts itself out of cobwebs
- melee is the normal sword fight (no jump hits, W/S-taps). No totem handling in this mode.

UHC extras:
- you in a cobweb: lava on your head (clicks the top of the web), then it scoops the lava back up
- him in a cobweb: he places water to wash it away (cuts it with the sword if he has no water)
- sprint-bridging: 6-16 blocks out he fills holes in front of him (two blocks per tick) so he never loses speed
- corner trap (UHC_TRAP in SparBot.java): after a hit, if you are backed into a corner he webs you to the wall, puts lava on your head, walls the open sides with blocks, then drops water on top so the lava turns to obsidian, and takes the water back. Needs lava + blocks on the hotbar (web and water make it better). Aborts if you get out of the cell.
- buckets are aimed and used with right-click (not block-clicked), so lava and water placement needs a clear line to the block face
- UHC mode (3rd step of the I key): the bot also raises its own off-hand shield while its sword recharges (not against axes), and the debug line shows what UHC is doing (act=) and whether the shield is up (sh=).
- UHC healing: golden apple under 7 hearts (when it is safe), golden head (player head in the hotbar) at 4 hearts or less, even in the middle of a fight.
- UHC off-hand: shield normally; totem at 3 hearts or less; shield again after a pop (for 3 s) or once healed to 5 hearts. Water on a web is only scooped once the web is gone; lava is scooped back from within reach; the obsidian trap no longer needs a corner.
