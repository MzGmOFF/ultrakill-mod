# ULTRAKILL Mod (Fabric 1.21.11)

Keys (rebind in Controls > ULTRAKILL):
- X: dash (3 charges)
- Z: slide (low crawl pose, fits under 1-block gaps; dash into slide for extra speed, jump to cancel)
- V: cycle revolver variant (Piercer -> Marksman -> Sharpshooter)
- Right click: fire
- Marksman (green) only: left click tosses a coin; shoot it to ricochet to other coins, then the nearest enemy
- Shift in mid-air (2+ blocks above ground): ground slam, no fall damage, shockwave hurts nearby mobs
- H: Elytra Mace bot on / off (see below).
- O: stun slam combo over 2 ticks (attribute swap): slot 2 -> 3 + hit, then slot 2 -> 8 + hit. Works any time, no item checks
- I: sword-mode sparring bot on / off. It targets the closest player (set ONLY_LISTED = true in SparBot.java to limit it to the PARTNERS name list). Auto totem (a new totem into the off-hand right after every pop), no jump hits, no pearls.


HUD: worn armor and durability are shown left of the hotbar (red blinking ! under 10%). Potion effects are shown top-right as icons with the timer on them (green = helpful, red = harmful, flashing under 15 s).

Get the guns: Creative inventory > Combat tab, or
/give @s ultrakill:marksman_revolver
- J: spar bot difficulty: ADAPTIVE (default, ramps up when you are beating it) / EASY / NORMAL / HARD / INSANE (instant aim, no reaction delay, 1-tick sprint resets, hits at 90% charge, spaces itself out of reach). No jump crits and no jump hits: in sword mode the bot never jumps, it sprint-hits, W-taps and S-taps (steps back during the sprint reset when it is tight on you), strafes constantly and keeps itself at max reach.



Elytra Mace mode (H key; the sword mode on I is untouched): no ground fight, only takeoff, aim, strike. Hotbar: 1 rockets, 2 spear, 3 axe, 4 elytra (the chestplate after the swap), 5 sword, 6 shield, 7 golden apples, 8 mace, 9 pearls. It sees players up to 150 blocks away, also flying ones (it aims with prediction). Scheme: elytra on -> jump + open -> rockets up, only as high as the target needs (16-20 blocks above it, a new random value each run: ELY_HEIGHT_MIN / ELY_HEIGHT_MAX, so it flies high only when the enemy is high) -> aim -> when close: chestplate on (elytra off), spear slot -> axe -> hit, then spear slot -> mace -> hit (exactly the O key) -> a 2 tick pause (ELY_POST_HIT_WAIT, so the mace's Wind Burst can throw it up) -> elytra back on, a little up, and again. No cooldown between strikes. Rockets, mace, axe and spear are refilled from the inventory. Auto totem works here too. It switches itself off at the end of a round like the sword mode.

Auto-off at the end of a round (STOP_AT_ROUND_END in SparBot.java): the bot switches itself off and shows "Spar bot: ..., OFF". Press I and the same mode comes back. It stops on: a server title or game message with a phrase from END_PHRASES ("Match over", "You won", "Defeat", ...) or just "Win" / "Lose", ANY server title after 5 s of real fighting (so the 3-2-1-FIGHT countdown is ignored), you dying (the death screen), the target dying / being removed, or the target being gone for 3 s. A totem pop (yours or theirs) does NOT stop it. The title hook is a mixin (InGameHudMixin, require = 0) and the message hook is a Fabric event.
