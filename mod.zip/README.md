# ULTRAKILL Mod (Fabric 1.21.11)

Keys (rebind in Controls > ULTRAKILL):
- X: dash (3 charges)
- V: cycle revolver variant (Piercer -> Marksman -> Sharpshooter)
- Right click: fire

Get the guns: Creative inventory > Combat tab, or
/give @s ultrakill:piercer_revolver
