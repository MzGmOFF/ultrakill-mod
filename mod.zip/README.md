# ULTRAKILL Mod (Fabric 1.21.11)

Keys (rebind in Controls > ULTRAKILL):
- X: dash (3 charges)
- Z: slide (low crawl pose, fits under 1-block gaps; dash into slide for extra speed, jump to cancel)
- V: cycle revolver variant (Piercer -> Marksman -> Sharpshooter)
- Right click: fire
- Marksman (green) only: left click tosses a coin; shoot it to ricochet to other coins, then the nearest enemy
- Space in mid-air: double jump (much higher than a normal jump)
- Shift in mid-air (2+ blocks above ground): ground slam, no fall damage, shockwave hurts nearby mobs
- O: stun slam combo over 2 ticks (attribute swap): slot 2 -> 3 + hit, then slot 2 -> 8 + hit. Works any time, no item checks
- I: cycles the sparring bot: sword mode -> crystal mode -> off. Pearls slot 1, sword slot 5, crystals slot 6, obsidian slot 9, axe slot 3 (shield break). Auto totem. Only targets the usernames listed in SparBot.java (PARTNERS)
  - Far away (8+ blocks) it throws an ender pearl (slot 1) onto the target instead of walking, then hits instantly.
  - Crystal mode: sword hit, then obsidian + crystal + pop, twice, chained in the same tick (no waiting).
  - Blocks around / can't land the sword hit: it drops the sword and spams crystals (pop + re-place every tick).

HUD: worn armor and durability are shown left of the hotbar (red blinking ! under 10%). Potion effects are shown top-right as icons with the timer on them (green = helpful, red = harmful, flashing under 15 s).

Get the guns: Creative inventory > Combat tab, or
/give @s ultrakill:marksman_revolver
