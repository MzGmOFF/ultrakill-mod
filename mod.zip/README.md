# ULTRAKILL Mod (Fabric 1.21.11)

Keys (rebind in Controls > ULTRAKILL):
- X: dash (3 charges)
- Z: slide (low crawl pose, fits under 1-block gaps; dash into slide for extra speed, jump to cancel)
- V: cycle revolver variant (Piercer -> Marksman -> Sharpshooter)
- Right click: fire
- Marksman (green) only: left click tosses a coin; shoot it to ricochet to other coins, then the nearest enemy

Get the guns: Creative inventory > Combat tab, or
/give @s ultrakill:marksman_revolver
