package com.ultrakillmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.function.Predicate;

/**
 * Insta cart (client side, key N), the tech from the video: "first bow, then place the rail, finally place the cart".
 * Aim at the ground next to the enemy (or at the enemy) and press N. It draws the bow aimed at the spot, and on the
 * tick the arrow is let go it puts the rail and the TNT cart on that spot, all in the same tick, so the burning
 * arrow reaches the cart the moment it exists. Press N again while it is drawing to cancel.
 * Needs in the hotbar (found by type, any slot; carts and rails are pulled from the inventory when the hotbar has
 * none): a bow (Flame, for the arrow to light the cart), a rail, a TNT minecart. Arrows anywhere in the inventory.
 */
public final class InstaCart {
    private static final int DRAW_TICKS = 22;        // a bow is fully drawn after 20 ticks
    private static final double REACH = 4.4;         // the rail and the cart have to be placed within this range

    private static int stage = 0;                    // 0 idle, 1 drawing, 2 waiting for a fetched item
    private static int ticks = 0;
    private static int prevSlot = 0, bowSlot = -1, railSlot = -1, cartSlot = -1;
    private static BlockPos floor = null;            // the block the rail goes on top of

    private InstaCart() {}

    public static void start(MinecraftClient client) {
        if (stage != 0) {
            cancel(client, "Insta cart cancelled");
            return;
        }
        ClientPlayerEntity player = client.player;
        if (player == null || client.world == null || client.interactionManager == null) return;
        if (client.currentScreen != null) return;

        floor = aimFloor(client);
        if (floor == null) {
            msg(player, "Insta cart: aim at the ground (or at the enemy) within 4 blocks");
            return;
        }
        BlockPos rail = floor.up();
        if (!client.world.getBlockState(rail).isAir() || !solid(client.world, floor)) {
            msg(player, "Insta cart: no free spot for the rail there");
            floor = null;
            return;
        }
        if (player.getEyePos().distanceTo(faceCenter(floor)) > REACH) {
            msg(player, "Insta cart: too far, get within 4 blocks");
            floor = null;
            return;
        }
        prevSlot = player.getInventory().getSelectedSlot();
        begin(client, player);
    }

    /** Finds the items; pulls a missing cart / rail out of the inventory (then waits 3 ticks for it to arrive). */
    private static void begin(MinecraftClient client, ClientPlayerEntity player) {
        bowSlot = findHotbar(player, st -> st.isOf(Items.BOW));
        railSlot = findHotbar(player, st -> isRail(st));
        cartSlot = findHotbar(player, st -> st.isOf(Items.TNT_MINECART));
        boolean fetched = false;
        if (railSlot < 0) fetched |= fetch(client, player, st -> isRail(st));
        if (cartSlot < 0) fetched |= fetch(client, player, st -> st.isOf(Items.TNT_MINECART));
        if (fetched && stage != 2) {
            stage = 2;
            ticks = 0;
            return;
        }
        if (bowSlot < 0 || railSlot < 0 || cartSlot < 0 || !hasArrows(player)) {
            String need = (bowSlot < 0 ? "bow " : "") + (hasArrows(player) ? "" : "arrows ")
                    + (railSlot < 0 ? "rail " : "") + (cartSlot < 0 ? "TNT minecart" : "");
            msg(player, "Insta cart needs: " + need.trim());
            stage = 0;
            floor = null;
            return;
        }
        stage = 1;
        ticks = 0;
    }

    /** Called every client tick. */
    public static void tick(MinecraftClient client) {
        if (stage == 0) return;
        ClientPlayerEntity player = client.player;
        if (player == null || client.world == null || client.interactionManager == null || client.currentScreen != null
                || floor == null) {
            cancel(client, null);
            return;
        }
        if (stage == 2) {                            // waiting for the swapped-in item
            if (++ticks >= 3) {
                stage = 0;
                begin(client, player);
            }
            return;
        }
        // stage 1: bow in hand, drawing, looking at the cart spot
        ticks++;
        player.getInventory().setSelectedSlot(bowSlot);
        client.options.useKey.setPressed(true);
        aimAt(player, Vec3d.ofCenter(floor.up()));
        if (ticks >= DRAW_TICKS) fire(client, player);
    }

    /** One tick: let go of the arrow, rail, cart. The arrow is already on its way when the cart appears. */
    private static void fire(MinecraftClient client, ClientPlayerEntity player) {
        BlockPos rail = floor.up();
        client.interactionManager.stopUsingItem(player);                          // 1) bow: the arrow goes
        client.options.useKey.setPressed(false);

        player.getInventory().setSelectedSlot(railSlot);                          // 2) the rail on the spot
        Vec3d top = new Vec3d(floor.getX() + 0.5, floor.getY() + 1.0, floor.getZ() + 0.5);
        client.interactionManager.interactBlock(player, Hand.MAIN_HAND, new BlockHitResult(top, Direction.UP, floor, false));
        player.swingHand(Hand.MAIN_HAND);

        player.getInventory().setSelectedSlot(cartSlot);                          // 3) the cart on the rail
        Vec3d on = new Vec3d(rail.getX() + 0.5, rail.getY() + 0.1, rail.getZ() + 0.5);
        client.interactionManager.interactBlock(player, Hand.MAIN_HAND, new BlockHitResult(on, Direction.UP, rail, false));
        player.swingHand(Hand.MAIN_HAND);

        player.getInventory().setSelectedSlot(prevSlot);                          // back to what was in hand
        stage = 0;
        floor = null;
    }

    private static void cancel(MinecraftClient client, String message) {
        stage = 0;
        floor = null;
        if (client.options != null) client.options.useKey.setPressed(false);
        if (client.player != null) {
            client.player.getInventory().setSelectedSlot(prevSlot);
            if (message != null) msg(client.player, message);
        }
    }

    /** The block the rail goes on top of: under the enemy's feet, or the ground the crosshair is on. */
    private static BlockPos aimFloor(MinecraftClient client) {
        HitResult hit = client.crosshairTarget;
        if (hit instanceof EntityHitResult ehr) {
            Entity e = ehr.getEntity();
            return e.getBlockPos().down();
        }
        if (hit instanceof BlockHitResult bhr && bhr.getType() == HitResult.Type.BLOCK) {
            if (bhr.getSide() == Direction.UP) return bhr.getBlockPos();
            return bhr.getBlockPos().offset(bhr.getSide()).down();               // a wall: the floor in front of it
        }
        return null;
    }

    private static Vec3d faceCenter(BlockPos block) {
        return new Vec3d(block.getX() + 0.5, block.getY() + 1.0, block.getZ() + 0.5);
    }

    private static boolean solid(ClientWorld world, BlockPos p) {
        return !world.getBlockState(p).getCollisionShape(world, p).isEmpty();
    }

    private static boolean isRail(ItemStack st) {
        return st.isOf(Items.RAIL) || st.isOf(Items.POWERED_RAIL) || st.isOf(Items.DETECTOR_RAIL)
                || st.isOf(Items.ACTIVATOR_RAIL);
    }

    private static int findHotbar(ClientPlayerEntity player, Predicate<ItemStack> test) {
        for (int i = 0; i < 9; i++) {
            if (test.test(player.getInventory().getStack(i))) return i;
        }
        return -1;
    }

    private static boolean hasArrows(ClientPlayerEntity player) {
        for (int i = 0; i < player.getInventory().size(); i++) {
            ItemStack st = player.getInventory().getStack(i);
            if (st.isOf(Items.ARROW) || st.isOf(Items.SPECTRAL_ARROW) || st.isOf(Items.TIPPED_ARROW)) return true;
        }
        return false;
    }

    /** Swaps an inventory stack into an empty hotbar slot. True if it did. */
    private static boolean fetch(MinecraftClient client, ClientPlayerEntity player, Predicate<ItemStack> test) {
        int idx = -1;
        for (int i = 9; i < 36; i++) {
            if (test.test(player.getInventory().getStack(i))) {
                idx = i;
                break;
            }
        }
        int spare = -1;
        for (int i = 0; i < 9; i++) {
            if (player.getInventory().getStack(i).isEmpty()) {
                spare = i;
                break;
            }
        }
        if (idx < 0 || spare < 0) return false;
        client.interactionManager.clickSlot(player.playerScreenHandler.syncId, idx, spare, SlotActionType.SWAP, player);
        return true;
    }

    /** Looks at a point, with the pitch raised to make up for how far the arrow drops. */
    private static void aimAt(ClientPlayerEntity player, Vec3d point) {
        Vec3d eye = player.getEyePos();
        double dx = point.x - eye.x, dy = point.y - eye.y, dz = point.z - eye.z;
        double horiz = Math.sqrt(dx * dx + dz * dz);
        float pitch = solvePitch(horiz, dy, 3.0, 0.05);
        if (Float.isNaN(pitch)) pitch = (float) -Math.toDegrees(Math.atan2(dy, horiz));
        player.setYaw((float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0f);
        player.setPitch(MathHelper.clamp(pitch, -90.0f, 90.0f));
    }

    /** Pitch (degrees, negative = up) so an arrow (speed, gravity, drag 0.99) lands horiz blocks away and dy up/down. */
    private static float solvePitch(double horiz, double dy, double speed, double gravity) {
        float best = Float.NaN;
        double bestErr = 2.0;
        for (float elev = -60f; elev <= 60f; elev += 0.25f) {
            double rad = Math.toRadians(elev);
            double vx = speed * Math.cos(rad);
            double vy = speed * Math.sin(rad);
            double x = 0, y = 0;
            for (int t = 0; t < 120; t++) {
                double px = x, py = y;
                x += vx;
                y += vy;
                vx *= 0.99;
                vy = vy * 0.99 - gravity;
                if (x >= horiz) {
                    double f = (horiz - px) / (x - px);
                    double err = Math.abs(py + f * (y - py) - dy);
                    if (err < bestErr - 0.02) {
                        bestErr = err;
                        best = -elev;
                    }
                    break;
                }
                if (vx < 0.01) break;
            }
        }
        return best;
    }

    private static void msg(ClientPlayerEntity player, String text) {
        player.sendMessage(Text.literal(text), true);
    }
}
