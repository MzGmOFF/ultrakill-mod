package com.ultrakillmod;

/** Client-side style meter: points go up when you hit things, and drain over time. */
public final class StyleMeter {
    public static final String[] NAMES = {"D", "C", "B", "A", "S", "SS", "SSS", "ULTRAKILL"};
    public static final int[] THRESHOLDS = {0, 100, 250, 450, 700, 1000, 1400, 1900};
    public static final float MAX = 2300f;

    private static float points = 0f;
    private static float flash = 0f;
    private static int lastVariant = -1;
    private static int varietyTicks = 0;

    private StyleMeter() {}

    public static void add(int gain, int variant) {
        float mult = 1.0f;
        // Variety bonus: using a different variant than the last hit.
        if (lastVariant != -1 && variant != lastVariant) {
            mult = 1.5f;
            varietyTicks = 40;
        }
        lastVariant = variant;
        points = Math.min(MAX, points + gain * mult);
        flash = 1.0f;
    }

    public static void tick() {
        if (points > 0f) {
            // Higher ranks drain faster, like the real thing.
            float decay = 0.15f * (1.0f + rank() * 0.6f);
            points = Math.max(0f, points - decay);
        } else {
            lastVariant = -1;
        }
        flash *= 0.88f;
        if (varietyTicks > 0) varietyTicks--;
    }

    public static int rank() {
        int r = 0;
        for (int i = 0; i < THRESHOLDS.length; i++) {
            if (points >= THRESHOLDS[i]) r = i;
        }
        return r;
    }

    public static float points() { return points; }
    public static float flash() { return flash; }
    public static boolean varietyActive() { return varietyTicks > 0; }

    public static int color(int rank, int age) {
        switch (rank) {
            case 0: return 0xFF9AA0A6;
            case 1: return 0xFF63D471;
            case 2: return 0xFFE8D44D;
            case 3: return 0xFFF29B38;
            case 4: return 0xFFEE5A3A;
            case 5: return 0xFFE8323C;
            case 6: return 0xFFFF2D6F;
            default: return (age / 3) % 2 == 0 ? 0xFFFF3C3C : 0xFFFFFFFF;
        }
    }
}
