package com.ultrakillmod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.item.ItemGroups;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;

public class UltrakillMod implements ModInitializer {
    public static final String MOD_ID = "ultrakill";

    public static Identifier id(String path) {
        return Identifier.of(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ModItems.register();
        Networking.register();

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(entries -> {
            for (RevolverItem item : ModItems.REVOLVERS) {
                entries.add(item);
            }
            entries.add(ModItems.COIN);
        });

        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            SlideTracker.set(handler.getPlayer().getUuid(), false);
            Slam.clear(handler.getPlayer().getUuid());
        });

        // No fall damage while (and just after) ground slamming.
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) ->
                !(entity instanceof ServerPlayerEntity player
                        && source.isOf(DamageTypes.FALL)
                        && Slam.isImmuneToFall(player.getUuid())));

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            Coins.tick(server.getTicks());
            Slam.tick(server.getTicks());
        });
    }
}
