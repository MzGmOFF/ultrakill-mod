package com.ultrakillmod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.ItemGroups;
import net.minecraft.util.Identifier;

public class UltrakillMod implements ModInitializer {
    public static final String MOD_ID = "ultrakill";

    public static Identifier id(String path) {
        return Identifier.of(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ModItems.register();
        Networking.register();

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(entries -> {
            for (RevolverItem item : ModItems.REVOLVERS) {
                entries.add(item);
            }
        });
    }
}
