package com.ultrakillmod;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Box;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Server side of the ground slam: fall damage immunity and the shockwave on impact. */
public final class Slam {
    private static final Set<UUID> ACTIVE = ConcurrentHashMap.newKeySet();
    private static final Map<UUID, Integer> IMMUNE_UNTIL = new ConcurrentHashMap<>();
    private static int now = 0;

    private Slam() {}

    public static void tick(int serverTick) {
        now = serverTick;
        IMMUNE_UNTIL.values().removeIf(expiry -> expiry <= serverTick);
    }

    public static boolean isImmuneToFall(UUID id) {
        Integer expiry = IMMUNE_UNTIL.get(id);
        return expiry != null && expiry > now;
    }

    public static void clear(UUID id) {
        ACTIVE.remove(id);
        IMMUNE_UNTIL.remove(id);
    }

    public static void start(UUID id) {
        ACTIVE.add(id);
        IMMUNE_UNTIL.put(id, now + 200); // safety cap: 10 seconds
    }

    public static void land(MinecraftServer server, ServerPlayerEntity player, int heightRaw) {
        UUID id = player.getUuid();
        if (!ACTIVE.remove(id)) return; // no slam was in progress
        IMMUNE_UNTIL.put(id, now + 20);  // covers the landing tick

        int height = Math.max(0, Math.min(heightRaw, 64));
        for (ServerWorld world : server.getWorlds()) {
            if (world.getPlayerByUuid(id) == player) {
                impact(world, player, height);
                break;
            }
        }
    }

    private static void impact(ServerWorld world, ServerPlayerEntity player, int height) {
        double x = player.getX();
        double y = player.getY();
        double z = player.getZ();
        double radius = Math.min(7.0, 3.0 + height * 0.15);
        float damage = (float) Math.min(30.0, 4.0 + height * 0.7);

        Box box = new Box(x - radius, y - 1.0, z - radius, x + radius, y + 3.0, z + radius);
        List<LivingEntity> targets = world.getEntitiesByClass(LivingEntity.class, box,
                e -> e != player && !(e instanceof PlayerEntity) && e.isAlive()
                        && !e.isSpectator() && !(e instanceof ArmorStandEntity));

        DamageSource source = world.getDamageSources().playerAttack(player);
        int gain = 0;
        for (LivingEntity e : targets) {
            double dx = e.getX() - x;
            double dz = e.getZ() - z;
            double dist = Math.sqrt(dx * dx + dz * dz);
            if (dist > radius) continue;

            float scaled = (float) (damage * (1.0 - 0.5 * dist / radius));
            e.damage(world, source, scaled);
            double len = Math.max(0.1, dist);
            e.addVelocity(dx / len * 0.6, 0.6, dz / len * 0.6);
            gain += 60;
            if (!e.isAlive()) {
                gain += 100;
            }
        }

        // Shockwave visuals and sound.
        world.spawnParticles(ParticleTypes.EXPLOSION, x, y + 0.3, z, 1, 0.0, 0.0, 0.0, 0.0);
        int steps = 28;
        for (int i = 0; i < steps; i++) {
            double angle = i * (Math.PI * 2.0 / steps);
            double px = x + Math.cos(angle) * radius * 0.8;
            double pz = z + Math.sin(angle) * radius * 0.8;
            world.spawnParticles(ParticleTypes.POOF, px, y + 0.2, pz, 2, 0.1, 0.05, 0.1, 0.02);
        }
        world.playSound(null, x, y, z, SoundEvents.BLOCK_ANVIL_LAND, SoundCategory.PLAYERS, 1.0F, 0.6F);

        if (gain > 0) {
            ServerPlayNetworking.send(player, new Networking.StylePayload(gain, -2));
        }
    }
}
