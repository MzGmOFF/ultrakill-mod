package com.ultrakillmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/**
 * Spear Mace, as in the two guides. One call per tick from the bot loop: SpearMace.act(...). Self-contained.
 *
 * Hotbar (0-based indexes, hotbar slot numbers in brackets): wind charge 0 [1], spear 1 [2], axe 2 [3],
 * ender pearls 3 [4], sword 4 [5], potion 5 [6], golden apples 6 [7] = the "prep" slot, mace 7 [8], shield 8 [9].
 *
 * A run: wind charge at its own feet while jumping (launch) -> in the air it holds the prep slot until the item's
 * attack cooldown is 100%, then presses LEFT CLICK + the spear key (2) in the same tick (the Spear Lunge: the
 * charged cooldown is kept through the swap), 2 ticks later the prep key (7), and repeats to close the distance
 * -> when close and falling: the O key strike (spear slot -> axe -> hit, then spear slot -> mace -> hit)
 * -> again (from the air if the mace's Wind Burst threw it up, else with a new wind charge).
 * Lunges stop when it is within 3 blocks of the target HORIZONTALLY (the height does not matter). It eats golden
 * apples (slot 7) when under 4 hearts or under 5 food bars, one after another. If it has been on the ground for
 * 10 ticks (it missed, or the target is right next to it) it starts over with a wind charge.
 * The key presses go through the game's own input handling, exactly like a human pressing the keys.
 */
public final class SpearMace {
    private static final int WIND = 0, SPEAR = 1, AXE = 2, PREP = 6, MACE = 7;
    private static final double START_MAX = 18.0;      // starts a run from this far; further away it sprints in
    private static final double STRIKE_REACH = 4.6;    // axe + mace when this close and past the top of the jump
    private static final int LUNGE_BACK_TICKS = 2;     // ticks between "LMB + 2" and going back to the prep slot
    private static final int COMBO_GAP = 1;            // ticks between the axe hit and the mace hit (like the O key)
    private static final int RUN_COOLDOWN = 8;         // ticks on the ground between runs
    private static final double LUNGE_STOP_HORIZ = 3.0; // no lunges when this close horizontally (height is ignored)
    private static final int GROUND_RESET_TICKS = 10;  // on the ground this long = missed: new wind charge
    private static final float EAT_BELOW_HP = 8.0f;    // under 4 hearts: golden apples
    private static final int EAT_BELOW_FOOD = 10;      // under 5 food bars (10 points): golden apples

    private static int stage = 0, ticks = 0, cd = 0, lungeBack = 0, combo = 0, gap = 0, notice = 0;
    private static int groundTicks = 0, eatTicks = 0;
    private static boolean useHold = false;            // right-click held this tick (eating)

    private SpearMace() {}

    public static void reset() {
        stage = 0;
        ticks = 0;
        cd = 0;
        lungeBack = 0;
        combo = 0;
        gap = 0;
        notice = 0;
        groundTicks = 0;
        eatTicks = 0;
        useHold = false;
    }

    /** Returns true: while this mode is on, it owns the controls. */
    public static boolean act(MinecraftClient client, ClientWorld world, ClientPlayerEntity player, PlayerEntity target) {
        useHold = false;
        boolean owns = run(client, world, player, target);
        client.options.useKey.setPressed(useHold);         // right-click is held only while eating
        return owns;
    }

    private static boolean run(MinecraftClient client, ClientWorld world, ClientPlayerEntity player, PlayerEntity target) {
        if (cd > 0) cd--;
        double dist = player.distanceTo(target);
        boolean onGround = player.isOnGround();
        Vec3d vel = player.getVelocity();
        int windSlot = findWind(player);

        if (!isSpear(player.getInventory().getStack(SPEAR)) || !player.getInventory().getStack(MACE).isOf(Items.MACE)) {
            keys(client, false, false, false);               // nothing to fight with: say what is missing
            if (--notice <= 0) {
                player.sendMessage(Text.literal("Spear mace needs: spear (slot 2) and mace (slot 8)"), true);
                notice = 60;
            }
            return true;
        }

        // Eat golden apples (slot 7) like the hungriest person alive: under 4 hearts, or under 5 food bars.
        boolean haveApple = player.getInventory().getStack(PREP).isOf(Items.GOLDEN_APPLE);
        boolean needFood = player.getHealth() < EAT_BELOW_HP || player.getHungerManager().getFoodLevel() < EAT_BELOW_FOOD;
        if (haveApple && stage != 5 && lungeBack == 0 && (needFood || eatTicks > 0)) {
            eatTicks++;
            select(player, PREP);
            useHold = true;
            aimAt(player, target);
            if ((eatTicks > 4 && !player.isUsingItem()) || eatTicks > 60) {   // that apple is down: the next one if still needed
                eatTicks = 0;
                useHold = false;
            }
            keys(client, false, false, false);
            return true;
        }
        if (!needFood) eatTicks = 0;

        switch (stage) {
            case 0: {                                          // on the ground: charge the prep item, start a run
                hold(player, PREP);
                aimAt(player, target);
                if (!onGround) {                               // thrown up by the Wind Burst: carry on from the air
                    stage = 3;
                    ticks = 0;
                    return true;
                }
                if (dist > START_MAX) {
                    keys(client, true, true, false);           // too far: sprint in
                    return true;
                }
                if (cd == 0) {
                    if (windSlot >= 0) {
                        stage = 1;
                    } else {                                   // no wind charge: sprint-jump and lunge from here
                        stage = 3;
                        ticks = 0;
                        lungeBack = 0;
                        keys(client, true, true, true);
                        return true;
                    }
                }
                keys(client, false, false, false);
                return true;
            }
            case 1:                                            // 1) wind charge in hand, look straight down
                select(player, windSlot >= 0 ? windSlot : WIND);
                player.setPitch(90.0f);
                stage = 2;
                keys(client, false, false, false);
                return true;
            case 2:                                            // 2) throw it at our feet, jump with it
                select(player, windSlot >= 0 ? windSlot : WIND);
                player.setPitch(90.0f);
                client.interactionManager.interactItem(player, Hand.MAIN_HAND);
                player.swingHand(Hand.MAIN_HAND);
                stage = 3;
                ticks = 0;
                lungeBack = 0;
                keys(client, false, false, true);
                return true;
            case 3: {                                          // 3) in the air: lunge toward the target, strike when close
                ticks++;
                aimAt(player, target);
                double horiz = Math.hypot(target.getX() - player.getX(), target.getZ() - player.getZ());
                groundTicks = onGround ? groundTicks + 1 : 0;
                if (groundTicks >= GROUND_RESET_TICKS || ticks > 150) {   // on the ground for 10 ticks = missed: start over
                    stage = 0;
                    cd = 0;
                    ticks = 0;
                    lungeBack = 0;
                    groundTicks = 0;
                    keys(client, false, false, false);
                    return true;
                }
                if (!onGround && dist <= STRIKE_REACH && vel.y < 0.15) {   // a smash needs the fall: only in the air
                    stage = 5;
                    combo = 0;
                    return strikeStep(client, player, target);
                }
                if (lungeBack > 0) {                           // after "LMB + 2": back to the prep slot
                    if (--lungeBack == 0) pressHotbar(client, PREP);
                    keys(client, horiz > 1.5, horiz > 1.5, false);
                    return true;
                }
                hold(player, PREP);                            // holding the prep item charges its cooldown
                // lunge only while it is more than 3 blocks away HORIZONTALLY: above the target it just falls on it
                if (!onGround && horiz > LUNGE_STOP_HORIZ && ticks >= 2 && player.getInventory().getSelectedSlot() == PREP
                        && player.getAttackCooldownProgress(0.0F) >= 1.0f) {
                    pressHotbar(client, SPEAR);                // LMB + key 2, the same tick
                    press(client.options.attackKey);
                    lungeBack = LUNGE_BACK_TICKS;
                }
                keys(client, horiz > 1.5, horiz > 1.5, false);
                return true;
            }
            default:
                return strikeStep(client, player, target);
        }
    }

    /** The O key strike: tick 1 spear slot -> axe -> hit, tick 2 spear slot -> mace -> hit. */
    private static boolean strikeStep(MinecraftClient client, ClientPlayerEntity player, PlayerEntity target) {
        aimAt(player, target);
        if (combo == 0) {
            strike(client, player, AXE, target);
            combo = 1;
            gap = COMBO_GAP;
        } else if (--gap <= 0) {
            strike(client, player, MACE, target);
            end(player, player.isOnGround());
        }
        keys(client, false, false, false);
        return true;
    }

    private static void strike(MinecraftClient client, ClientPlayerEntity player, int slot, Entity target) {
        player.networkHandler.sendPacket(new net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket(SPEAR));
        player.networkHandler.sendPacket(new net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket(slot));
        player.getInventory().setSelectedSlot(slot);
        client.interactionManager.attackEntity(player, target);
        player.swingHand(Hand.MAIN_HAND);
    }

    /** After the strike: still in the air (Wind Burst threw us up) = keep going from there, else a short pause. */
    private static void end(ClientPlayerEntity player, boolean onGround) {
        hold(player, PREP);
        combo = 0;
        lungeBack = 0;
        ticks = 0;
        groundTicks = 0;
        if (onGround) {
            stage = 0;
            cd = RUN_COOLDOWN;
        } else {
            stage = 3;
        }
    }

    // ---- small helpers ----

    private static int findWind(ClientPlayerEntity p) {
        for (int i = 0; i < 9; i++) {
            if (p.getInventory().getStack(i).isOf(Items.WIND_CHARGE)) return i;
        }
        return -1;
    }

    private static boolean isSpear(ItemStack st) {
        return !st.isEmpty() && net.minecraft.registry.Registries.ITEM.getId(st.getItem()).getPath().endsWith("_spear");
    }

    private static void select(ClientPlayerEntity player, int slot) {
        player.getInventory().setSelectedSlot(slot);
    }

    private static void hold(ClientPlayerEntity player, int slot) {
        if (player.getInventory().getSelectedSlot() != slot) player.getInventory().setSelectedSlot(slot);
    }

    /** Presses a key the way the keyboard / mouse does: the game handles it at the start of the next tick. */
    private static void press(KeyBinding binding) {
        KeyBinding.onKeyPressed(InputUtil.fromTranslationKey(binding.getBoundKeyTranslationKey()));
    }

    private static void pressHotbar(MinecraftClient client, int slot) {
        press(client.options.hotbarKeys[slot]);
    }

    private static void keys(MinecraftClient client, boolean forward, boolean sprint, boolean jump) {
        client.options.forwardKey.setPressed(forward);
        client.options.sprintKey.setPressed(sprint);
        client.options.jumpKey.setPressed(jump);
        client.options.leftKey.setPressed(false);
        client.options.rightKey.setPressed(false);
        client.options.backKey.setPressed(false);
    }

    /** Looks at the middle of the target (this is the direction the lunge goes). */
    private static void aimAt(ClientPlayerEntity player, Entity target) {
        Vec3d eye = player.getEyePos();
        double dx = target.getX() - eye.x;
        double dy = target.getY() + target.getHeight() * 0.5 - eye.y;
        double dz = target.getZ() - eye.z;
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        player.setYaw((float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0f);
        player.setPitch(MathHelper.clamp((float) -Math.toDegrees(Math.atan2(dy, horizontal)), -90.0f, 90.0f));
    }
}
