package com.ultrakillmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Vec3d;

/**
 * Spear lunge (client side), steps 2 and 3 of the tutorial: LEFT CLICK while holding the free slot (nothing, or an
 * item with an instant cooldown), then quickly switch to the spear. (Step 1, the sprint jump, is yours.)
 * The order matters: "left click > switch to spear" works, "switch + left click" does not.
 * Runs every time the key (H) is pressed. Slot numbers are 0-based (hotbar slot 2 = index 1).
 */
public final class SpearLunge {
    private static final int FREE_SLOT = 6;     // hotbar slot 7: empty (or something with an instant cooldown)
    private static final int SPEAR_SLOT = 1;    // hotbar slot 2: the spear
    private static final int GAP_TICKS = 1;     // ticks between the click and the switch (0 = same tick)
    private static final double REACH = 4.5;

    private static int pending = 0;

    private SpearLunge() {}

    public static void start(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        if (player == null || client.interactionManager == null) return;
        // 2) left click with the free slot in hand (hits what the crosshair is on, or just swings)
        player.getInventory().setSelectedSlot(FREE_SLOT);          // (the attack below sends this slot first)
        Entity target = findTarget(player);
        if (target != null) {
            client.interactionManager.attackEntity(player, target);
        }
        player.swingHand(Hand.MAIN_HAND);
        // 3) quickly switch to the spear
        if (GAP_TICKS <= 0) {
            toSpear(player);
        } else {
            pending = GAP_TICKS;
        }
    }

    /** Called every client tick: does the switch to the spear after the gap. */
    public static void tick(MinecraftClient client) {
        if (pending > 0 && --pending == 0 && client.player != null) {
            toSpear(client.player);
        }
    }

    private static void toSpear(ClientPlayerEntity player) {
        player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(SPEAR_SLOT));
        player.getInventory().setSelectedSlot(SPEAR_SLOT);
    }

    /** What the crosshair is on, out to REACH blocks, whatever you are holding. */
    private static Entity findTarget(ClientPlayerEntity player) {
        Vec3d start = player.getEyePos();
        Vec3d dir = player.getRotationVec(1.0F);
        Vec3d end = start.add(dir.multiply(REACH));
        EntityHitResult hit = ProjectileUtil.raycast(player, start, end,
                player.getBoundingBox().stretch(dir.multiply(REACH)).expand(1.0),
                e -> !e.isSpectator() && e.canHit(), REACH * REACH);
        return hit == null ? null : hit.getEntity();
    }
}
