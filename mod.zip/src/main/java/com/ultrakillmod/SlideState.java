package com.ultrakillmod;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.sound.SoundEvents;

/** Client-side slide: a fast, decaying glide in a low crawl pose. Jump to cancel and keep the speed. */
public final class SlideState {
    private static int ticks = 0;
    private static double dx, dz, speed;

    private SlideState() {}

    public static void tryStart(ClientPlayerEntity player) {
        if (ticks > 0 || !player.isOnGround()) return;
        double yaw = Math.toRadians(player.getYaw());
        dx = -Math.sin(yaw);
        dz = Math.cos(yaw);
        // Dash into a slide for extra speed.
        speed = DashState.recentlyDashed() ? 1.35 : 0.95;
        ticks = 24;
        SlideTracker.set(player.getUuid(), true);
        ClientPlayNetworking.send(new Networking.SlidePayload(true));
        player.playSound(SoundEvents.BLOCK_SAND_BREAK, 0.9f, 0.8f);
    }

    private static void end(ClientPlayerEntity player) {
        ticks = 0;
        SlideTracker.set(player.getUuid(), false);
        ClientPlayNetworking.send(new Networking.SlidePayload(false));
    }

    public static void tick(ClientPlayerEntity player) {
        if (ticks <= 0) return;
        if (!player.isOnGround()) {
            end(player); // jumped or fell off: keep whatever momentum we have
            return;
        }
        player.setVelocity(dx * speed, player.getVelocity().y, dz * speed);
        speed *= 0.955;
        ticks--;
        if (speed < 0.2 || ticks <= 0) {
            end(player);
        }
    }
}
