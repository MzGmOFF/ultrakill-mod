package com.ultrakillmod;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.Set;

/**
 * Sparring partner (client side). Press the key to start, press again to stop.
 * It only ever targets the usernames listed in PARTNERS, so it is a training opponent
 * for your own accounts and cannot be pointed at anyone else.
 *
 * It sprints in, jumps, hits on the way down for crits, W-taps, and strafes around the target.
 * Aim and timing are deliberately a little imperfect so it feels like a real opponent.
 */
public final class SparBot {
    // Only these players can be targeted (lower-case).
    private static final Set<String> PARTNERS = Set.of(
            "babaykala22", "axyzet", "rico46_5556", "theobaldthebot");

    // ---- Tunables ----
    private static final int SWORD_SLOT = 4;          // hotbar slot 5 (0-based index)
    private static final int AXE_SLOT = 2;            // hotbar slot 3: swung once to break a raised shield
    private static final int SHIELD_BREAK_COOLDOWN = 25; // ticks before it will try to break a shield again
    private static final int CRYSTAL_SLOT = 5;       // hotbar slot 6: end crystals
    private static final int OBSIDIAN_SLOT = 8;      // hotbar slot 9: obsidian
    private static final int CRYSTAL_COOLDOWN = 30;  // ticks of sword fighting between crystal combos
    private static final float SAFE_HEALTH = 8.0f;   // below this (4 hearts) with no totem it skips crystals
    private static final double SEARCH_RANGE = 48.0;  // how far away it looks for a partner
    private static final double CLOSE_DIST = 3.4;     // below this it starts the fight loop
    private static final double HIT_REACH = 3.0;      // a sword hit needs the target this close (eye to hitbox)
    private static final float MAX_TURN_YAW = 35.0f;  // degrees per tick
    private static final float MAX_TURN_PITCH = 25.0f;
    private static final float AIM_NOISE_YAW = 2.5f;  // aim wobble (degrees)
    private static final float AIM_NOISE_PITCH = 1.5f;
    private static final float HIT_CHARGE = 0.90f;    // attack charge needed before swinging (90%)
    private static final float JUMP_CHARGE = 0.5f;    // starts the jump early so the crit lands at ~95%
    private static final double JUMP_DIST = 2.8;      // only jump when this close (jumping from far away overshoots)
    private static final boolean CRIT_JUMPS = false;  // true = jump and hit on the way down (no sprint hit then)
    private static final boolean DEBUG = true;        // shows a status line above the hotbar
    private static final int WTAP_TICKS = 2;          // forward released this long after a hit
    private static final int MAX_REACTION_TICKS = 2;  // random extra delay before a hit

    private static final Random RND = new Random();

    private static boolean active = false;
    private static int mode = 0;                      // 0 = off, 1 = sword, 2 = crystal
    private static int crystalStage = 0;              // 0 = none, 1 = obsidian, 2/4 = place crystal, 3 = pop it
    private static int crystalCooldown = 0;
    private static int stageTicks = 0;
    private static int stageDelay = 0;
    private static int obsidianTries = 0;
    private static int placeWait = 0;
    private static int retries = 0;
    private static int pops = 0;
    private static int totemCooldown = 0;
    private static int totemWarn = 0;
    private static BlockPos basePos = null;
    private static int wTapTicks = 0;
    private static int strafeTicks = 0;
    private static int strafeDir = 0;
    private static int reaction = 0;
    private static int noiseTicks = 0;
    private static float noiseYaw = 0f;
    private static float noisePitch = 0f;
    private static int noticeCooldown = 0;
    private static int debugTicks = 0;
    private static int shieldCooldown = 0;

    private SparBot() {}

    public static boolean isActive() {
        return active;
    }

    /** I cycles: sword mode -> crystal mode -> off. */
    public static void toggle(MinecraftClient client) {
        if (client.player == null) return;
        mode = (mode + 1) % 3;
        active = mode != 0;
        crystalStage = 0;
        if (active) {
            wTapTicks = 0;
            strafeTicks = 0;
            reaction = 0;
            shieldCooldown = 0;
            crystalCooldown = 0;
            totemCooldown = 0;
            client.player.getInventory().setSelectedSlot(SWORD_SLOT);
            client.player.sendMessage(Text.literal(mode == 1
                    ? "Spar bot: SWORD mode (I again = crystal mode)"
                    : "Spar bot: CRYSTAL mode (I again = off)"), true);
        } else {
            releaseKeys(client);
            client.player.sendMessage(Text.literal("Spar bot OFF"), true);
        }
    }

    public static void reset(MinecraftClient client) {
        active = false;
        mode = 0;
        crystalStage = 0;
        if (client != null && client.options != null) releaseKeys(client);
    }

    private static void releaseKeys(MinecraftClient client) {
        client.options.forwardKey.setPressed(false);
        client.options.sprintKey.setPressed(false);
        client.options.leftKey.setPressed(false);
        client.options.rightKey.setPressed(false);
        client.options.jumpKey.setPressed(false);
    }

    private static PlayerEntity findPartner(MinecraftClient client, ClientPlayerEntity self) {
        PlayerEntity best = null;
        double bestDist = SEARCH_RANGE * SEARCH_RANGE;
        for (PlayerEntity other : client.world.getPlayers()) {
            if (other == self || !other.isAlive() || other.isSpectator()) continue;
            String name = other.getName().getString().toLowerCase(Locale.ROOT);
            if (!PARTNERS.contains(name)) continue;
            double d = self.squaredDistanceTo(other);
            if (d < bestDist) {
                bestDist = d;
                best = other;
            }
        }
        return best;
    }

    /** True if the line of sight reaches the target's hitbox within sword reach (a little forgiving). */
    private static boolean canHit(ClientPlayerEntity player, Entity target) {
        Vec3d eye = player.getEyePos();
        Vec3d dir = player.getRotationVec(1.0F);
        Vec3d end = eye.add(dir.multiply(HIT_REACH));
        Box box = target.getBoundingBox().expand(0.12);
        return box.contains(eye) || box.raycast(eye, end).isPresent();
    }

    private static void aim(ClientPlayerEntity player, Entity target) {
        if (--noiseTicks <= 0) {
            noiseTicks = 6 + RND.nextInt(8);
            noiseYaw = (RND.nextFloat() * 2f - 1f) * AIM_NOISE_YAW;
            noisePitch = (RND.nextFloat() * 2f - 1f) * AIM_NOISE_PITCH;
        }
        Vec3d eye = player.getEyePos();
        double dx = target.getX() - eye.x;
        double dy = (target.getY() + target.getHeight() * 0.65) - eye.y;
        double dz = target.getZ() - eye.z;
        double horizontal = Math.sqrt(dx * dx + dz * dz);

        float wantYaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0f + noiseYaw;
        float wantPitch = (float) -Math.toDegrees(Math.atan2(dy, horizontal)) + noisePitch;

        float dYaw = MathHelper.clamp(MathHelper.wrapDegrees(wantYaw - player.getYaw()), -MAX_TURN_YAW, MAX_TURN_YAW);
        float dPitch = MathHelper.clamp(wantPitch - player.getPitch(), -MAX_TURN_PITCH, MAX_TURN_PITCH);
        player.setYaw(player.getYaw() + dYaw);
        player.setPitch(MathHelper.clamp(player.getPitch() + dPitch, -90.0f, 90.0f));
    }

    // ------------------------------------------------------------------
    // Auto totem
    // ------------------------------------------------------------------

    /** Keeps a totem in the off-hand: after a pop, the next one is moved there within a few ticks. */
    private static void ensureTotem(MinecraftClient client, ClientPlayerEntity player) {
        if (totemCooldown > 0) {
            totemCooldown--;
            return;
        }
        if (player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;
        for (int i = 0; i < 36; i++) {
            if (player.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) {
                int slotId = i < 9 ? 36 + i : i;     // hotbar slots are 36-44 in the inventory screen
                client.interactionManager.clickSlot(
                        player.playerScreenHandler.syncId, slotId, 40, SlotActionType.SWAP, player);
                totemCooldown = 3;
                return;
            }
        }
        if (--totemWarn <= 0) {
            player.sendMessage(Text.literal("Spar bot: out of totems"), true);
            totemWarn = 100;
        }
    }

    private static boolean crystalSafe(ClientPlayerEntity player) {
        return player.getHealth() > SAFE_HEALTH || player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING);
    }

    // ------------------------------------------------------------------
    // Crystal combo: sword hit launches you, then obsidian -> crystal -> pop -> crystal -> pop
    // ------------------------------------------------------------------

    private static void startCrystal() {
        crystalStage = 1;
        stageTicks = 0;
        stageDelay = 1 + RND.nextInt(2);
        obsidianTries = 0;
        placeWait = 0;
        retries = 0;
        pops = 0;
        basePos = null;
    }

    private static void endCrystal(ClientPlayerEntity player) {
        crystalStage = 0;
        crystalCooldown = CRYSTAL_COOLDOWN;
        player.getInventory().setSelectedSlot(SWORD_SLOT);
    }

    private static boolean isBase(ClientWorld world, BlockPos pos) {
        BlockState state = world.getBlockState(pos);
        return state.isOf(Blocks.OBSIDIAN) || state.isOf(Blocks.BEDROCK);
    }

    /** A block next to the target (not under it) that a crystal can sit on. Existing obsidian/bedrock is reused. */
    private static BlockPos findBase(ClientWorld world, ClientPlayerEntity bot, Entity target) {
        BlockPos t = target.getBlockPos();
        int gy = t.getY();
        for (int i = 0; i < 8; i++) {                 // the target may be in the air: find the ground below
            if (!world.getBlockState(new BlockPos(t.getX(), gy - 1, t.getZ())).isAir()) break;
            gy--;
        }
        Vec3d eye = bot.getEyePos();
        Vec3d center = target.getBoundingBox().getCenter();
        BlockPos best = null;
        double bestScore = Double.MAX_VALUE;

        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                int x = t.getX() + dx;
                int z = t.getZ() + dz;
                BlockPos floor = new BlockPos(x, gy - 1, z);
                BlockState floorState = world.getBlockState(floor);
                BlockPos base;
                if (floorState.isOf(Blocks.OBSIDIAN) || floorState.isOf(Blocks.BEDROCK)) {
                    base = floor;                      // already a crystal base
                } else if (floorState.isSideSolidFullSquare(world, floor, Direction.UP)
                        && world.getBlockState(floor.up()).isAir()) {
                    base = floor.up();                 // obsidian goes here
                } else {
                    continue;
                }
                if (!world.getBlockState(base.up()).isAir() || !world.getBlockState(base.up().up()).isAir()) continue;

                Box zone = new Box(x, base.getY(), z, x + 1, base.getY() + 3, z + 1);
                if (target.getBoundingBox().intersects(zone) || bot.getBoundingBox().intersects(zone)) continue;

                double reachSq = eye.squaredDistanceTo(x + 0.5, base.getY() + 1.0, z + 0.5);
                if (reachSq > 4.4 * 4.4) continue;

                double score = center.squaredDistanceTo(x + 0.5, base.getY() + 1.0, z + 0.5);
                if (score < bestScore) {
                    bestScore = score;
                    best = base;
                }
            }
        }
        return best;
    }

    /** Right-click the top face of a block. */
    private static void clickTop(MinecraftClient client, ClientPlayerEntity player, BlockPos block) {
        Vec3d hit = new Vec3d(block.getX() + 0.5, block.getY() + 1.0, block.getZ() + 0.5);
        client.interactionManager.interactBlock(player, Hand.MAIN_HAND,
                new BlockHitResult(hit, Direction.UP, block, false));
        player.swingHand(Hand.MAIN_HAND);
    }

    private static EndCrystalEntity findCrystal(ClientWorld world, BlockPos base) {
        Box box = new Box(base.up()).expand(0.8);
        List<EndCrystalEntity> list = world.getEntitiesByClass(EndCrystalEntity.class, box, e -> e.isAlive());
        return list.isEmpty() ? null : list.get(0);
    }

    private static void runCrystalStage(MinecraftClient client, ClientPlayerEntity player, PlayerEntity target) {
        ClientWorld world = client.world;
        if (++stageTicks > 40) {                       // took too long: give up and go back to the sword
            endCrystal(player);
            return;
        }
        if (stageDelay > 0) {
            stageDelay--;
            return;
        }

        switch (crystalStage) {
            case 1: {                                  // obsidian base
                if (basePos == null) {
                    basePos = findBase(world, player, target);
                    if (basePos == null) {
                        endCrystal(player);
                        return;
                    }
                }
                if (isBase(world, basePos)) {
                    crystalStage = 2;
                    stageDelay = RND.nextInt(2);
                    return;
                }
                if (!player.getInventory().getStack(OBSIDIAN_SLOT).isOf(Items.OBSIDIAN) || ++obsidianTries > 4) {
                    endCrystal(player);
                    return;
                }
                player.getInventory().setSelectedSlot(OBSIDIAN_SLOT);
                clickTop(client, player, basePos.down());
                stageDelay = 1;
                return;
            }
            case 2:
            case 4: {                                  // place a crystal on the base
                if (!isBase(world, basePos)) return;   // obsidian not visible yet: wait
                if (findCrystal(world, basePos) != null) return; // the last one is still there
                if (!player.getInventory().getStack(CRYSTAL_SLOT).isOf(Items.END_CRYSTAL)) {
                    endCrystal(player);
                    return;
                }
                player.getInventory().setSelectedSlot(CRYSTAL_SLOT);
                clickTop(client, player, basePos);
                crystalStage = 3;
                placeWait = 0;
                return;
            }
            case 3: {                                  // pop it
                EndCrystalEntity crystal = findCrystal(world, basePos);
                if (crystal == null) {
                    if (++placeWait > 5) {             // the crystal never appeared: try placing again
                        placeWait = 0;
                        crystalStage = pops == 0 ? 2 : 4;
                        if (++retries > 3) endCrystal(player);
                    }
                    return;
                }
                if (player.getEyePos().distanceTo(crystal.getBoundingBox().getCenter()) > 3.6) return; // too far
                client.interactionManager.attackEntity(player, crystal);
                player.swingHand(Hand.MAIN_HAND);
                pops++;
                if (pops >= 2) {
                    endCrystal(player);
                } else {
                    crystalStage = 4;
                    stageDelay = RND.nextInt(2);
                }
                return;
            }
            default:
                endCrystal(player);
        }
    }

    public static void tick(MinecraftClient client) {
        if (!active) return;
        ClientPlayerEntity player = client.player;
        if (player == null || client.world == null || client.interactionManager == null) {
            reset(client);
            return;
        }
        if (client.currentScreen != null) {      // menus / chat open: pause
            releaseKeys(client);
            return;
        }

        PlayerEntity target = findPartner(client, player);
        if (target == null) {
            releaseKeys(client);
            if (--noticeCooldown <= 0) {
                player.sendMessage(Text.literal("Spar bot: no partner nearby"), true);
                noticeCooldown = 40;
            }
            return;
        }

        if (crystalStage == 0 && player.getInventory().getSelectedSlot() != SWORD_SLOT) {
            player.getInventory().setSelectedSlot(SWORD_SLOT);
        }

        aim(player, target);
        ensureTotem(client, player);

        if (crystalStage != 0) {                       // crystal combo in progress: stand still and run it
            releaseKeys(client);
            runCrystalStage(client, player, target);
            return;
        }
        if (crystalCooldown > 0) crystalCooldown--;

        double dist = player.distanceTo(target);
        boolean onGround = player.isOnGround();
        boolean falling = !onGround && player.getVelocity().y < -0.06;
        float charge = player.getAttackCooldownProgress(0.0F);

        if (--strafeTicks <= 0) {
            strafeDir = RND.nextInt(3) - 1;           // -1 left, 0 none, 1 right
            strafeTicks = 10 + RND.nextInt(20);
        }

        boolean forward = true;
        boolean sprint = true;
        boolean jump = false;

        if (wTapTicks > 0) {                          // W-tap: let go of forward to reset sprint
            wTapTicks--;
            forward = false;
            sprint = false;
        }

        boolean aimedInReach = canHit(player, target);
        boolean ready = charge >= HIT_CHARGE;

        if (dist <= CLOSE_DIST) {
            if (CRIT_JUMPS) {
                // Optional crit mode: jump early, release W while falling, hit on the way down.
                if (onGround && charge >= JUMP_CHARGE && dist <= JUMP_DIST && wTapTicks == 0) {
                    jump = true;
                }
                if (falling) {
                    forward = false;
                    sprint = false;
                }
            }

            // Shield up? Swap to the axe and hit at once (the sword comes back next tick).
            if (shieldCooldown > 0) shieldCooldown--;
            boolean blocking = target.isBlocking();

            // Sprint-hit combo: 1) hold W (sprinting)  2) hit  3) release W, then press it again.
            if (reaction > 0) {
                reaction--;
            } else if (blocking && aimedInReach && shieldCooldown == 0) {
                player.getInventory().setSelectedSlot(AXE_SLOT);
                client.interactionManager.attackEntity(player, target);
                player.swingHand(Hand.MAIN_HAND);
                shieldCooldown = SHIELD_BREAK_COOLDOWN;
                wTapTicks = WTAP_TICKS;
                reaction = RND.nextInt(MAX_REACTION_TICKS + 1);
            } else if (ready && aimedInReach && !blocking && aimedInReach && (!CRIT_JUMPS || (falling && !player.isSprinting()) || player.isSprinting())) {
                client.interactionManager.attackEntity(player, target);
                player.swingHand(Hand.MAIN_HAND);
                wTapTicks = WTAP_TICKS;                   // release W so the sprint resets
                reaction = RND.nextInt(MAX_REACTION_TICKS + 1);

                // Crystal mode: this sword hit launches the target; follow up with obsidian + crystals.
                if (mode == 2 && crystalCooldown == 0 && crystalSafe(player)
                        && player.getInventory().getStack(CRYSTAL_SLOT).isOf(Items.END_CRYSTAL)) {
                    startCrystal();
                }
            }
        }

        if (DEBUG && --debugTicks <= 0) {
            debugTicks = 10;
            player.sendMessage(Text.literal(String.format(Locale.ROOT,
                    "d=%.1f charge=%.2f %s%s%s aim=%s",
                    dist, charge, onGround ? "G" : "-", falling ? "F" : "-",
                    player.isSprinting() ? "S" : "-", aimedInReach ? "Y" : "N")), true);
        }

        client.options.forwardKey.setPressed(forward);
        client.options.sprintKey.setPressed(sprint);
        client.options.jumpKey.setPressed(jump);
        client.options.leftKey.setPressed(strafeDir < 0);
        client.options.rightKey.setPressed(strafeDir > 0);
    }
}
