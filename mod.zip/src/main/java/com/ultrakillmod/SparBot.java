package com.ultrakillmod;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.DeathScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.function.Predicate;

/**
 * Sparring partner (client side). Press the key to start, press again to stop.
 * It fights the closest player (or only the usernames in PARTNERS when ONLY_LISTED is true).
 * Meant for training on your own private server: it will go for anyone who is nearby.
 *
 * Far away it ender-pearls straight onto the target (slot 1) instead of walking. Up close it hits with
 * the sword and, in crystal mode, follows with obsidian + crystals in the same tick (no waiting). When
 * blocks around make the sword + crystal combo awkward, it switches to pure crystal spam: pop and
 * re-place every tick, as fast as the connection allows.
 */
public final class SparBot {
    // Only these players can be targeted (lower-case).
    // false = it fights the CLOSEST player, whoever that is (so friends can train with it too).
    // true  = it only fights the usernames in PARTNERS below.
    private static final boolean ONLY_LISTED = false;

    private static final Set<String> PARTNERS = Set.of(
            "babaykala22", "axyzet", "rico46_5556", "theobaldthebot");

    // ---- Tunables ----
    private static final int SWORD_SLOT = 4;          // hotbar slot 5 (0-based index)
    private static final int AXE_SLOT = 2;            // hotbar slot 3: swung once to break a raised shield
    private static final int SHIELD_BREAK_COOLDOWN = 25; // ticks before it will try to break a shield again
    private static final int CRYSTAL_SLOT = 5;       // hotbar slot 6: end crystals
    private static final int OBSIDIAN_SLOT = 8;      // hotbar slot 9: obsidian
    private static final int PEARL_SLOT = 0;          // hotbar slot 1: ender pearls
    private static final boolean PEARL_ENABLED = true;
    private static final double PEARL_MIN_DIST = 8.0; // pearl in from at least this far away
    private static final double PEARL_MAX_DIST = 40.0;
    private static final int PEARL_COOLDOWN = 22;     // ticks between pearl throws
    private static final double PEARL_SPEED = 1.5;
    private static final int RUSH_TICKS = 30;         // after a pearl: hit instantly, perfect aim, no cooldowns
    private static final int CRYSTAL_COOLDOWN = 8;   // ticks of sword fighting between crystal combos
    private static final int COMBO_POPS = 2;          // sword hit, then place+pop this many crystals
    private static final double SPAM_RANGE = 6.5;     // crystal spam only when the target is this close
    private static final int SPAM_HOLD = 20;          // keep spamming this long after the blocks stop being a problem
    private static final int STUCK_TICKS = 30;        // near the target this long without landing a sword hit = spam
    private static final int STUCK_HOLD = 60;
    private static final int CROWDED_BLOCKS = 8;      // solid blocks around feet+head (of 16) = cramped
    private static final double POP_REACH = 4.5;
    private static final int POP_REPEAT = 3;          // don't re-hit the same crystal within this many ticks
    private static final int PLACE_RETRY = 2;         // ticks before placing again if no crystal showed up
    private static final float SAFE_HEALTH = 8.0f;   // below this (4 hearts) with no totem it skips crystals
    private static final double SEARCH_RANGE = 48.0;  // how far away it looks for a partner
    private static final double CLOSE_DIST = 3.4;     // below this it starts the fight loop
    private static final double HIT_REACH = 3.0;      // a sword hit needs the target this close (eye to hitbox)
    private static final float MAX_TURN_YAW = 35.0f;  // degrees per tick
    private static final float MAX_TURN_PITCH = 25.0f;
    private static final float AIM_NOISE_YAW = 2.5f;  // aim wobble (degrees)
    private static final float AIM_NOISE_PITCH = 1.5f;
    private static final float HIT_CHARGE = 0.90f;    // attack charge needed before swinging (90%)
    private static final float JUMP_CHARGE = 0.5f;    // starts the jump early so the crit lands at ~95%
    private static final double JUMP_DIST = 2.8;      // only jump when this close (jumping from far away overshoots)
    private static final boolean CRIT_JUMPS = false;  // true = jump and hit on the way down (no sprint hit then)
    private static final boolean DEBUG = true;        // shows a status line above the hotbar
    private static final int WTAP_TICKS = 2;          // forward released this long after a hit
    private static final int MAX_REACTION_TICKS = 2;  // random extra delay before a hit

    private static final Random RND = new Random();

    private static boolean active = false;
    private static int mode = 0;                      // 0 = off, 1 = sword, 2 = crystal, 3 = UHC
    private static int state = 0;                     // what the I key cycles: 0 off, 1 sword, 2 crystal, 3 UHC
    private static int crystalStage = 0;              // 0 = none, 1 = sword+crystal combo, 2 = crystal spam
    private static int crystalCooldown = 0;
    private static int stageTicks = 0;
    private static int obsidianTries = 0;
    private static int pops = 0;
    private static int placeCd = 0;
    private static int noBaseTicks = 0;
    private static int spamHold = 0;
    private static int spamBlock = 0;
    private static int ticksSinceHit = 0;
    private static int tickNo = 0;
    private static int pearlCooldown = 0;
    private static boolean pearlPending = false;
    private static int rush = 0;
    private static Vec3d lastBotPos = null;
    private static Vec3d lastTargetPos = null;
    private static int lastTargetId = -1;
    private static Vec3d targetVel = Vec3d.ZERO;
    private static final Map<Integer, Integer> recentPops = new HashMap<>();
    private static int totemCooldown = 0;
    private static int totemWarn = 0;
    private static int wTapTicks = 0;
    private static int strafeTicks = 0;
    private static int strafeDir = 0;
    private static int reaction = 0;
    private static int noiseTicks = 0;
    private static float noiseYaw = 0f;
    private static float noisePitch = 0f;
    private static int noticeCooldown = 0;
    private static int debugTicks = 0;
    private static int shieldCooldown = 0;

    // ---- difficulty: 0 = adaptive (follows how you are doing), 1 easy, 2 normal, 3 hard, 4 insane ----
    private static final float SKILL_MIN = 0.25f;
    private static final float SKILL_MAX = 1.0f;
    private static final float[] FIXED_SKILL = {0.65f, 0.30f, 0.55f, 0.90f, 1.00f};
    private static final String[] DIFF_NAMES = {"ADAPTIVE", "EASY", "NORMAL", "HARD", "INSANE"};
    private static int difficulty = 0;
    private static float skill = 0.65f;               // 0.25 .. 1.0, drives everything below
    private static float hitBalance = 0f;             // + when the bot is winning exchanges, - when you are
    private static int adaptTicks = 0;
    private static float lastTargetHealth = -1f;
    private static float lastBotHealth = -1f;
    private static boolean critNext = false;          // next swing is a jump crit instead of a sprint hit
    private static int critWait = 0;
    private static int hopCd = 0;
    private static boolean wantBack = false;          // S key for this tick (spacing)
    private static int infoHold = 0;                  // ticks the mode/difficulty message stays on screen
    private static PlayerEntity lastTarget = null;    // who we were fighting last tick (to notice when it dies)

    private static String modeName() {
        return state == 1 ? "SWORD" : state == 2 ? "CRYSTAL" : state == 3 ? "UHC" : "OFF";
    }

    private static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    /** INSANE: the bot plays at a level no human reaches (instant aim, no wobble, no reaction delay). */
    private static boolean insane() { return difficulty == 4; }

    private static float turnYaw() { return insane() ? 180f : lerp(14f, 90f, skill); }   // degrees per tick
    private static float turnPitch() { return insane() ? 90f : lerp(10f, 60f, skill); }
    private static float noiseYawMax() { return insane() ? 0f : lerp(6.0f, 0.3f, skill); }   // aim wobble
    private static float noisePitchMax() { return insane() ? 0f : lerp(4.0f, 0.2f, skill); }
    private static int maxReaction() { return Math.round(lerp(5f, 0f, skill)); }   // extra ticks before a swing
    private static float hitCharge() { return insane() ? 0.90f : lerp(1.0f, 0.90f, skill); }   // never swings below 90%
    private static float leadTicks() { return insane() ? 3.0f : lerp(0f, 2.5f, skill); }   // aims ahead of a moving target
    private static float critChance() { return 0f; }                         // crits are off: sprint hits only
    private static int wtapTicks() { return insane() ? 1 : WTAP_TICKS; }     // INSANE resets its sprint a tick faster
    private static float spaceDist() {                                       // backs off while recharging when closer than this
        if (insane()) return 3.1f;
        return skill > 0.5f ? lerp(2.2f, 2.8f, (skill - 0.5f) / 0.5f) : 0f;
    }

    /** Cycles ADAPTIVE -> EASY -> NORMAL -> HARD -> INSANE. */
    public static void cycleDifficulty(MinecraftClient client) {
        difficulty = (difficulty + 1) % DIFF_NAMES.length;
        skill = FIXED_SKILL[difficulty];
        hitBalance = 0f;
        if (client.player != null) {
            infoHold = 30;
            client.player.sendMessage(Text.literal("Spar bot: " + modeName() + " mode, difficulty "
                    + DIFF_NAMES[difficulty] + (difficulty == 0 ? " (adjusts to you)" : "")), true);
        }
    }

    /** Watches health on both sides: counts hits, and in ADAPTIVE mode turns the skill up when you are winning. */
    private static void trackResults(ClientPlayerEntity player, PlayerEntity target) {
        float th = target.getHealth();
        float bh = player.getHealth();
        if (lastTargetHealth >= 0f && th < lastTargetHealth - 0.01f) {
            hitBalance += 1f;                                  // the bot landed a hit
        }
        if (lastBotHealth >= 0f && bh < lastBotHealth - 0.01f && crystalStage == 0) {
            hitBalance -= 1f;                                  // you landed a hit
            strafeTicks = 0;                                   // react: change direction right away
            if (skill > 0.5f && player.isOnGround()) hopCd = 0;
        }
        lastTargetHealth = th;
        lastBotHealth = bh;

        if (difficulty == 0 && ++adaptTicks >= 40) {          // every 2 seconds
            adaptTicks = 0;
            if (hitBalance < -1.5f) skill = Math.min(SKILL_MAX, skill + 0.04f);       // you are ahead: harder
            else if (hitBalance > 3.0f) skill = Math.max(SKILL_MIN, skill - 0.02f);   // bot is far ahead: ease off
            hitBalance *= 0.7f;                                // forget old exchanges
        }
    }

    // ------------------------------------------------------------------
    // Round / match end: the bot switches itself off (press I to bring the same mode back).
    // Signals: the server's title or a game message ("Match over", ...), you died, the target is dead or gone.
    // ------------------------------------------------------------------
    private static final boolean STOP_AT_ROUND_END = true;
    private static final boolean STOP_ON_ANY_TITLE = true;   // after a real fight, ANY title from the server = round over
    private static final int TITLE_FIGHT_TICKS = 100;        // ...so the "3, 2, 1, FIGHT" countdown titles are ignored
    private static final String[] END_PHRASES = {
            "match over", "round over", "game over", "you won", "you lost", "you win", "you lose",
            "victory", "defeat", "winner", "round won", "round lost", "won the round", "lost the round",
            "победа", "поражение", "раунд окончен", "матч окончен", "вы победили", "вы проиграли", "вы выиграли"
    };
    private static volatile boolean roundOverFlag = false;
    private static volatile String roundOverWhy = "";
    private static int fightTicks = 0, noTargetTicks = 0, resumeState = 0;

    /** Called by the title hook (title = true) and the game-message hook. Only sets a flag; the tick does the work. */
    public static void onServerText(Text text, boolean title) {
        if (!active || !STOP_AT_ROUND_END || text == null) return;
        String s = text.getString().trim().toLowerCase(Locale.ROOT);
        if (s.isEmpty()) return;
        for (String phrase : END_PHRASES) {
            if (s.contains(phrase)) {
                roundOverWhy = "\"" + phrase + "\"";
                roundOverFlag = true;
                return;
            }
        }
        if (title && STOP_ON_ANY_TITLE && fightTicks >= TITLE_FIGHT_TICKS) {
            roundOverWhy = "server title";
            roundOverFlag = true;
        }
    }

    private static void stopBot(MinecraftClient client, ClientPlayerEntity player, String why) {
        int was = state;
        reset(client);
        resumeState = was;
        infoHold = 40;
        if (player != null) {
            player.sendMessage(Text.literal("Spar bot: " + why + ", OFF (press I to start again)"), true);
        }
    }

    private SparBot() {}

    public static boolean isActive() {
        return active;
    }

    /** I cycles: sword mode -> crystal mode -> UHC mode -> off. */
    public static void toggle(MinecraftClient client) {
        if (client.player == null) return;
        if (state == 0 && resumeState != 0) {          // it switched itself off after a round: I brings the same mode back
            state = resumeState;
            resumeState = 0;
        } else {
            state = (state + 1) % 4;
            resumeState = 0;
        }
        mode = state;
        lastTarget = null;
        active = state != 0;
        crystalStage = 0;
        if (active) {
            wTapTicks = 0;
            strafeTicks = 0;
            reaction = 0;
            shieldCooldown = 0;
            crystalCooldown = 0;
            totemCooldown = 0;
            resetFight();
            client.player.getInventory().setSelectedSlot(SWORD_SLOT);
            infoHold = 30;                             // keep this message up for ~1.5 s before the PvP info
            client.player.sendMessage(Text.literal("Spar bot: " + modeName() + " mode, difficulty "
                    + DIFF_NAMES[difficulty] + " (I = next mode, J = difficulty)"), true);
        } else {
            releaseKeys(client);
            infoHold = 30;
            client.player.sendMessage(Text.literal("Spar bot OFF"), true);
        }
    }

    public static void reset(MinecraftClient client) {
        active = false;
        mode = 0;
        state = 0;
        resumeState = 0;
        lastTarget = null;
        crystalStage = 0;
        resetFight();
        if (client != null && client.options != null) releaseKeys(client);
    }

    private static void resetFight() {
        fightTicks = 0;
        noTargetTicks = 0;
        pearlPending = false;
        pearlCooldown = 0;
        rush = 0;
        spamHold = 0;
        spamBlock = 0;
        ticksSinceHit = 0;
        noBaseTicks = 0;
        placeCd = 0;
        lastBotPos = null;
        lastTargetPos = null;
        lastTargetId = -1;
        targetVel = Vec3d.ZERO;
        recentPops.clear();
        lastTargetHealth = -1f;
        lastBotHealth = -1f;
        hitBalance = 0f;
        adaptTicks = 0;
        critNext = false;
        critWait = 0;
        hopCd = 0;
        eating = false;
        eatTicks = 0;
        healCd = 0;
        drawing = false;
        bowCd = 0;
        rodState = 0;
        rodCd = 0;
        webCd = 0;
        lavaPos = null;
        lavaCd = 0;
        waterOut = false;
        waterCd = 0;
        clutchAimed = false;
        pillarBase = null;
        aimPhase = false;
        trapStage = 0;
        trapCd = 0;
        lastHitNo = -1000;
    }

    private static void releaseKeys(MinecraftClient client) {
        client.options.forwardKey.setPressed(false);
        client.options.sprintKey.setPressed(false);
        client.options.leftKey.setPressed(false);
        client.options.rightKey.setPressed(false);
        client.options.jumpKey.setPressed(false);
        client.options.backKey.setPressed(false);
        client.options.useKey.setPressed(false);
    }

    private static PlayerEntity findPartner(MinecraftClient client, ClientPlayerEntity self) {
        PlayerEntity best = null;
        double range = SEARCH_RANGE;
        double bestDist = range * range;
        for (PlayerEntity other : client.world.getPlayers()) {
            if (other == self || !other.isAlive() || other.isSpectator()) continue;
            String name = other.getName().getString().toLowerCase(Locale.ROOT);
            if (ONLY_LISTED && !PARTNERS.contains(name)) continue;
            double d = self.squaredDistanceTo(other);
            if (d < bestDist) {
                bestDist = d;
                best = other;
            }
        }
        return best;
    }

    /** True if the line of sight reaches the target's hitbox within sword reach (a little forgiving). */
    private static boolean canHit(ClientPlayerEntity player, Entity target) {
        Vec3d eye = player.getEyePos();
        Vec3d dir = player.getRotationVec(1.0F);
        Vec3d end = eye.add(dir.multiply(HIT_REACH));
        Box box = target.getBoundingBox().expand(0.12);
        return box.contains(eye) || box.raycast(eye, end).isPresent();
    }

    private static void aim(ClientPlayerEntity player, Entity target, boolean snap) {
        if (--noiseTicks <= 0) {
            noiseTicks = 6 + RND.nextInt(8);
            noiseYaw = (RND.nextFloat() * 2f - 1f) * noiseYawMax();
            noisePitch = (RND.nextFloat() * 2f - 1f) * noisePitchMax();
        }
        Vec3d eye = player.getEyePos();
        double dx = target.getX() + targetVel.x * leadTicks() - eye.x;
        double dy = (target.getY() + target.getHeight() * 0.65) - eye.y;
        double dz = target.getZ() + targetVel.z * leadTicks() - eye.z;
        double horizontal = Math.sqrt(dx * dx + dz * dz);

        float nYaw = snap ? 0f : noiseYaw;
        float nPitch = snap ? 0f : noisePitch;
        float wantYaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0f + nYaw;
        float wantPitch = (float) -Math.toDegrees(Math.atan2(dy, horizontal)) + nPitch;

        if (snap) {                                    // right after a pearl: look at the target instantly
            player.setYaw(wantYaw);
            player.setPitch(MathHelper.clamp(wantPitch, -90.0f, 90.0f));
            return;
        }
        float dYaw = MathHelper.clamp(MathHelper.wrapDegrees(wantYaw - player.getYaw()), -turnYaw(), turnYaw());
        float dPitch = MathHelper.clamp(wantPitch - player.getPitch(), -turnPitch(), turnPitch());
        player.setYaw(player.getYaw() + dYaw);
        player.setPitch(MathHelper.clamp(player.getPitch() + dPitch, -90.0f, 90.0f));
    }

    private static void trackMotion(ClientPlayerEntity player, PlayerEntity target) {
        if (rush > 0) rush--;
        if (pearlCooldown > 0) pearlCooldown--;
        if (spamBlock > 0) spamBlock--;
        Vec3d pos = new Vec3d(player.getX(), player.getY(), player.getZ());
        if (lastBotPos != null && pos.distanceTo(lastBotPos) > 4.0) rush = RUSH_TICKS;   // we just teleported
        lastBotPos = pos;
        Vec3d tp = new Vec3d(target.getX(), target.getY(), target.getZ());
        if (lastTargetPos != null && lastTargetId == target.getId()) {
            Vec3d v = tp.subtract(lastTargetPos);
            targetVel = new Vec3d(MathHelper.clamp(v.x, -0.5, 0.5), 0.0, MathHelper.clamp(v.z, -0.5, 0.5));
        } else {
            targetVel = Vec3d.ZERO;
        }
        lastTargetPos = tp;
        lastTargetId = target.getId();
    }

    // ------------------------------------------------------------------
    // Terrain checks
    // ------------------------------------------------------------------

    /** True if nothing solid is between our eyes and the target. */
    private static boolean lineClear(ClientWorld world, ClientPlayerEntity player, Entity target) {
        Vec3d from = player.getEyePos();
        Vec3d to = target.getBoundingBox().getCenter();
        HitResult hit = world.raycast(new RaycastContext(from, to,
                RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, player));
        return hit.getType() == HitResult.Type.MISS;
    }

    /** Solid blocks in the 8 columns around a position, at feet and head height (max 16). */
    private static int solidAround(ClientWorld world, BlockPos pos) {
        int n = 0;
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                if (dx == 0 && dz == 0) continue;
                for (int dy = 0; dy <= 1; dy++) {
                    BlockPos p = pos.add(dx, dy, dz);
                    if (!world.getBlockState(p).getCollisionShape(world, p).isEmpty()) n++;
                }
            }
        }
        return n;
    }

    /** Blocks make the sword hit + crystal combo awkward: walls in the way, or either of us boxed in. */
    private static boolean isCrowded(ClientWorld world, ClientPlayerEntity player, Entity target) {
        return !lineClear(world, player, target)
                || solidAround(world, target.getBlockPos()) >= CROWDED_BLOCKS
                || solidAround(world, player.getBlockPos()) >= CROWDED_BLOCKS;
    }

    // ------------------------------------------------------------------
    // Ender pearl: instead of walking over, throw one onto the target
    // ------------------------------------------------------------------

    /** Pitch for a pearl (speed 1.5, gravity 0.03). NaN = out of range. */
    private static float solvePitch(double horiz, double dy) {
        return solveLaunch(horiz, dy, PEARL_SPEED, 0.03, 2.0);
    }

    /**
     * Pitch (degrees, negative = up) that makes a projectile launched at the given speed land horiz blocks
     * away and dy blocks up/down, with drag 0.99 and the given gravity. NaN = out of range.
     */
    private static float solveLaunch(double horiz, double dy, double speed, double gravity, double maxErr) {
        float best = Float.NaN;
        double bestErr = maxErr;
        for (float elev = -20f; elev <= 75f; elev += 0.5f) {   // flattest (fastest) solution wins ties
            double rad = Math.toRadians(elev);
            double vx = speed * Math.cos(rad);
            double vy = speed * Math.sin(rad);
            double x = 0, y = 0;
            for (int t = 0; t < 150; t++) {
                double px = x, py = y;
                x += vx;
                y += vy;
                vx *= 0.99;
                vy = vy * 0.99 - gravity;
                if (x >= horiz) {
                    double f = (horiz - px) / (x - px);
                    double err = Math.abs(py + f * (y - py) - dy);
                    if (err < bestErr - 0.05) {
                        bestErr = err;
                        best = -elev;
                    }
                    break;
                }
                if (vx < 0.01) break;
            }
        }
        return best;
    }

    /** Snaps the view onto the pearl's arc to the target (with a little lead). False if it can't be reached. */
    private static boolean aimPearl(ClientPlayerEntity player, PlayerEntity target) {
        Vec3d eye = player.getEyePos();
        double flight = player.distanceTo(target) / 1.3;
        double tx = target.getX() + targetVel.x * flight * 0.8;
        double tz = target.getZ() + targetVel.z * flight * 0.8;
        double ty = target.getY() + target.getHeight() * 0.5;
        double dx = tx - eye.x, dz = tz - eye.z, dy = ty - eye.y;
        float pitch = solvePitch(Math.sqrt(dx * dx + dz * dz), dy);
        if (Float.isNaN(pitch)) return false;
        player.setYaw((float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0f);
        player.setPitch(pitch);
        return true;
    }

    /** Phase 1: look along the pearl arc now, so the server has the rotation before the throw next tick. */
    private static void tryStartPearl(ClientWorld world, ClientPlayerEntity player, PlayerEntity target, double dist) {
        if (!PEARL_ENABLED || pearlCooldown > 0) return;
        if (dist < PEARL_MIN_DIST || dist > PEARL_MAX_DIST) return;
        if (!player.getInventory().getStack(PEARL_SLOT).isOf(Items.ENDER_PEARL)) return;
        if (!lineClear(world, player, target)) return;
        if (aimPearl(player, target)) pearlPending = true;
    }

    /** Phase 2: throw it. */
    private static void throwPearl(MinecraftClient client, ClientPlayerEntity player, PlayerEntity target, double dist) {
        pearlPending = false;
        if (dist < PEARL_MIN_DIST - 2.0 || dist > PEARL_MAX_DIST + 4.0) return;
        if (!player.getInventory().getStack(PEARL_SLOT).isOf(Items.ENDER_PEARL)) return;
        if (!aimPearl(player, target)) return;
        player.getInventory().setSelectedSlot(PEARL_SLOT);
        client.interactionManager.interactItem(player, Hand.MAIN_HAND);
        player.swingHand(Hand.MAIN_HAND);
        pearlCooldown = PEARL_COOLDOWN;
        rush = RUSH_TICKS;
    }

    // ------------------------------------------------------------------
    // Auto totem
    // ------------------------------------------------------------------

    /** Keeps a totem in the off-hand: after a pop, the next one is moved there within a few ticks. */
    private static void ensureTotem(MinecraftClient client, ClientPlayerEntity player) {
        if (totemCooldown > 0) {
            totemCooldown--;
            return;
        }
        if (player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;
        for (int i = 0; i < 36; i++) {
            if (player.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) {
                int slotId = i < 9 ? 36 + i : i;     // hotbar slots are 36-44 in the inventory screen
                client.interactionManager.clickSlot(
                        player.playerScreenHandler.syncId, slotId, 40, SlotActionType.SWAP, player);
                totemCooldown = 1;
                return;
            }
        }
        if (--totemWarn <= 0) {
            if (infoHold == 0) player.sendMessage(Text.literal("Spar bot: out of totems"), true);
            totemWarn = 100;
        }
    }

    private static int findInventory(ClientPlayerEntity player, net.minecraft.item.Item item) {
        for (int i = 0; i < 36; i++) {
            if (player.getInventory().getStack(i).isOf(item)) return i;
        }
        return -1;
    }

    /** UHC off-hand: shield normally; a totem when close to death; shield again after a pop or once healed. */
    private static void uhcOffhand(MinecraftClient client, ClientPlayerEntity player) {
        boolean offTotem = player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING);
        if (hadTotem && !offTotem) {                     // the totem popped: back to the shield for a bit
            totemMode = false;
            shieldUntil = tickNo + 60;
        }
        hadTotem = offTotem;

        float hp = player.getHealth();
        boolean totemAvailable = offTotem || findInventory(player, Items.TOTEM_OF_UNDYING) >= 0;
        if (!totemMode) {
            if (hp <= TOTEM_BELOW && totemAvailable && tickNo >= shieldUntil) totemMode = true;
        } else if (hp >= SHIELD_BACK || !totemAvailable) {   // healed enough (or none left): shield again
            totemMode = false;
        }

        net.minecraft.item.Item want = totemMode ? Items.TOTEM_OF_UNDYING : Items.SHIELD;
        if (offhandCd > 0) {
            offhandCd--;
            return;
        }
        if (player.getOffHandStack().isOf(want)) return;
        int idx = findInventory(player, want);
        if (idx < 0) return;
        int slotId = idx < 9 ? 36 + idx : idx;           // hotbar slots are 36-44 in the inventory screen
        client.interactionManager.clickSlot(
                player.playerScreenHandler.syncId, slotId, 40, SlotActionType.SWAP, player);
        offhandCd = 2;
    }

    /** A hotbar slot that none of the UHC moves rely on (an empty one first). */
    private static int spareHotbarSlot(ClientPlayerEntity player) {
        boolean[] used = new boolean[9];
        int[] roles = {SWORD_SLOT, uhcSword, uhcAxe, uhcBow, uhcRod, uhcGap, uhcHead, uhcWater, uhcLava,
                uhcBucket, uhcWeb, uhcBlocks};
        for (int r : roles) {
            if (r >= 0 && r < 9) used[r] = true;
        }
        for (int i = 8; i >= 0; i--) {
            if (!used[i] && player.getInventory().getStack(i).isEmpty()) return i;
        }
        for (int i = 8; i >= 0; i--) {
            if (!used[i]) return i;
        }
        return -1;
    }

    /** Lava and water buckets in the inventory (not the hotbar) are swapped into a free hotbar slot. */
    private static void uhcFetchBuckets(MinecraftClient client, ClientPlayerEntity player) {
        if (fetchCd > 0) {
            fetchCd--;
            return;
        }
        for (net.minecraft.item.Item item : new net.minecraft.item.Item[]{Items.LAVA_BUCKET, Items.WATER_BUCKET}) {
            if (findHotbar(player, st -> st.isOf(item)) >= 0) continue;     // already in the hotbar
            int idx = -1;
            for (int i = 9; i < 36; i++) {
                if (player.getInventory().getStack(i).isOf(item)) {
                    idx = i;
                    break;
                }
            }
            if (idx < 0) continue;
            int spare = spareHotbarSlot(player);
            if (spare < 0) return;
            client.interactionManager.clickSlot(
                    player.playerScreenHandler.syncId, idx, spare, SlotActionType.SWAP, player);
            fetchCd = 6;
            return;
        }
    }

    /** The nearest still (source) water block within bucket range, or null. */
    private static BlockPos nearestWaterSource(ClientWorld world, ClientPlayerEntity player) {
        BlockPos origin = player.getBlockPos();
        Vec3d eye = player.getEyePos();
        BlockPos best = null;
        double bestD = 4.0 * 4.0;
        for (int dx = -4; dx <= 4; dx++) {
            for (int dy = -3; dy <= 3; dy++) {
                for (int dz = -4; dz <= 4; dz++) {
                    BlockPos p = origin.add(dx, dy, dz);
                    if (!world.getBlockState(p).isOf(Blocks.WATER) || !world.getFluidState(p).isStill()) continue;
                    double d = eye.squaredDistanceTo(Vec3d.ofCenter(p));
                    if (d < bestD) {
                        bestD = d;
                        best = p;
                    }
                }
            }
        }
        return best;
    }

    /** Water the bot has left lying around (trap water, web water): walk back and scoop it up. */
    private static boolean uhcCleanup(MinecraftClient client, ClientWorld world, ClientPlayerEntity player,
                                      PlayerEntity target, double dist) {
        if (pendingWater == null) return false;
        boolean stillWater = world.getBlockState(pendingWater).isOf(Blocks.WATER)
                && world.getFluidState(pendingWater).isStill();
        if (!stillWater || tickNo - pendingWaterTick > 260 || pendingTries >= 6) {
            pendingWater = null;
            pendAimed = false;
            return false;
        }
        if (dist < 2.5 || tickNo - pendingWaterTick < 10) return false;     // fight first / let the obsidian form
        int bucket = findHotbar(player, st -> st.isOf(Items.BUCKET));
        if (bucket < 0) {
            pendingWater = null;
            return false;
        }
        Vec3d c = Vec3d.ofCenter(pendingWater);
        select(player, bucket);
        lookAt(player, c);
        if (player.getEyePos().distanceTo(c) > 4.0) {                       // walk back into reach
            pendAimed = false;
            setKeys(client, true, false, false, 0);
            return true;
        }
        if (pendAimed) {                                                   // rotation was sent last tick: scoop
            client.interactionManager.interactItem(player, Hand.MAIN_HAND);
            player.swingHand(Hand.MAIN_HAND);
            pendingTries++;
            pendAimed = false;
        } else {
            pendAimed = true;
        }
        setKeys(client, false, false, false, 0);
        return true;
    }

    private static boolean crystalSafe(ClientPlayerEntity player) {
        return player.getHealth() > SAFE_HEALTH || player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING);
    }

    // ------------------------------------------------------------------
    // Crystals. Combo: sword hit, then place + pop twice. Spam: place + pop every tick, no sword.
    // Everything is chained in the same tick: no delays between obsidian, crystal and pop.
    // ------------------------------------------------------------------

    private static boolean hasCrystals(ClientPlayerEntity player) {
        return player.getInventory().getStack(CRYSTAL_SLOT).isOf(Items.END_CRYSTAL);
    }

    private static void startCrystal() {
        crystalStage = 1;
        stageTicks = 0;
        obsidianTries = 0;
        pops = 0;
        placeCd = 0;
        noBaseTicks = 0;
    }

    private static void startSpam(boolean crowded) {
        crystalStage = 2;
        spamHold = crowded ? SPAM_HOLD : STUCK_HOLD;
        obsidianTries = 0;
        noBaseTicks = 0;
        placeCd = 0;
    }

    private static void endCrystal(ClientPlayerEntity player) {
        crystalStage = 0;
        crystalCooldown = CRYSTAL_COOLDOWN;
        ticksSinceHit = 0;
        player.getInventory().setSelectedSlot(SWORD_SLOT);
    }

    private static boolean isBase(ClientWorld world, BlockPos pos) {
        BlockState state = world.getBlockState(pos);
        return state.isOf(Blocks.OBSIDIAN) || state.isOf(Blocks.BEDROCK);
    }

    /** Best block next to the target for a crystal. Existing obsidian/bedrock is preferred (saves a placement). */
    private static BlockPos findBase(ClientWorld world, ClientPlayerEntity bot, Entity target) {
        BlockPos t = target.getBlockPos();
        int gy = t.getY();
        for (int i = 0; i < 8; i++) {                 // the target may be in the air: find the ground below
            if (!world.getBlockState(new BlockPos(t.getX(), gy - 1, t.getZ())).isAir()) break;
            gy--;
        }
        Vec3d eye = bot.getEyePos();
        Vec3d center = target.getBoundingBox().getCenter();
        BlockPos best = null;
        double bestScore = Double.MAX_VALUE;

        for (int dx = -3; dx <= 3; dx++) {
            for (int dz = -3; dz <= 3; dz++) {
                int x = t.getX() + dx;
                int z = t.getZ() + dz;
                BlockPos floor = new BlockPos(x, gy - 1, z);
                BlockState floorState = world.getBlockState(floor);
                BlockPos base;
                boolean existing = false;
                if (floorState.isOf(Blocks.OBSIDIAN) || floorState.isOf(Blocks.BEDROCK)) {
                    base = floor;                      // already a crystal base
                    existing = true;
                } else if (floorState.isSideSolidFullSquare(world, floor, Direction.UP)
                        && world.getBlockState(floor.up()).isAir()) {
                    base = floor.up();                 // obsidian goes here
                } else {
                    continue;
                }
                if (!world.getBlockState(base.up()).isAir() || !world.getBlockState(base.up().up()).isAir()) continue;

                Box zone = new Box(x, base.getY(), z, x + 1, base.getY() + 3, z + 1);
                if (target.getBoundingBox().intersects(zone) || bot.getBoundingBox().intersects(zone)) continue;

                double reachSq = eye.squaredDistanceTo(x + 0.5, base.getY() + 1.0, z + 0.5);
                if (reachSq > 4.4 * 4.4) continue;

                double dT = Math.sqrt(center.squaredDistanceTo(x + 0.5, base.getY() + 1.0, z + 0.5));
                double score = dT - 0.25 * Math.sqrt(reachSq) - (existing ? 1.5 : 0.0);
                if (score < bestScore) {
                    bestScore = score;
                    best = base;
                }
            }
        }
        return best;
    }

    /** Right-click the top face of a block. */
    private static void clickTop(MinecraftClient client, ClientPlayerEntity player, BlockPos block) {
        Vec3d hit = new Vec3d(block.getX() + 0.5, block.getY() + 1.0, block.getZ() + 0.5);
        client.interactionManager.interactBlock(player, Hand.MAIN_HAND,
                new BlockHitResult(hit, Direction.UP, block, false));
        player.swingHand(Hand.MAIN_HAND);
    }

    private static EndCrystalEntity findCrystal(ClientWorld world, BlockPos base) {
        Box box = new Box(base.up()).expand(0.8);
        List<EndCrystalEntity> list = world.getEntitiesByClass(EndCrystalEntity.class, box, e -> e.isAlive());
        return list.isEmpty() ? null : list.get(0);
    }

    /**
     * One tick of crystal work: pop every crystal in reach next to the target, then (in the same tick)
     * put the next one down. In combo mode it stops after COMBO_POPS pops, in spam mode it never stops.
     */
    private static void crystalCycle(MinecraftClient client, ClientPlayerEntity player, PlayerEntity target) {
        ClientWorld world = client.world;
        boolean spam = crystalStage == 2;
        if (!spam && ++stageTicks > 40) {              // combo took too long: back to the sword
            endCrystal(player);
            return;
        }
        if (placeCd > 0) placeCd--;

        // 1) pop right away
        boolean popped = false;
        int hits = 0;
        Vec3d eye = player.getEyePos();
        for (EndCrystalEntity c : world.getEntitiesByClass(EndCrystalEntity.class,
                target.getBoundingBox().expand(7.0), e -> e.isAlive())) {
            Integer last = recentPops.get(c.getId());
            if (last != null && tickNo - last < POP_REPEAT) continue;
            if (eye.distanceTo(c.getBoundingBox().getCenter()) > POP_REACH) continue;
            client.interactionManager.attackEntity(player, c);
            player.swingHand(Hand.MAIN_HAND);
            recentPops.put(c.getId(), tickNo);
            popped = true;
            pops++;
            if (++hits >= 2) break;
        }
        if (recentPops.size() > 64) recentPops.clear();
        if (!spam && pops >= COMBO_POPS) {
            endCrystal(player);
            return;
        }

        // 2) base block
        BlockPos base = findBase(world, player, target);
        if (base == null) {                            // no space for a crystal anywhere
            if (spam) noBaseTicks++; else endCrystal(player);
            return;
        }
        if (!isBase(world, base)) {
            if (!player.getInventory().getStack(OBSIDIAN_SLOT).isOf(Items.OBSIDIAN) || ++obsidianTries > 6) {
                if (spam) noBaseTicks += 4; else endCrystal(player);
                return;
            }
            player.getInventory().setSelectedSlot(OBSIDIAN_SLOT);
            clickTop(client, player, base.down());     // the client predicts it, so the crystal can go down this same tick
        } else {
            obsidianTries = 0;
        }

        // 3) crystal: straight after a pop (same tick), or when nothing is on the base
        if (!hasCrystals(player)) {
            if (spam) noBaseTicks += 4; else endCrystal(player);
            return;
        }
        noBaseTicks = 0;
        if (popped || (placeCd == 0 && findCrystal(world, base) == null)) {
            player.getInventory().setSelectedSlot(CRYSTAL_SLOT);
            clickTop(client, player, base);
            placeCd = PLACE_RETRY;
        }
    }

    private static boolean keepSpamming(ClientWorld world, ClientPlayerEntity player, PlayerEntity target, double dist) {
        if (dist > SPAM_RANGE + 2.0 || !crystalSafe(player) || !hasCrystals(player)) return false;
        if (noBaseTicks > 12) {                        // nowhere to put a crystal: fight with the sword instead
            spamBlock = 60;
            return false;
        }
        if (isCrowded(world, player, target)) spamHold = Math.max(spamHold, SPAM_HOLD);
        return --spamHold > 0;
    }

    private static void setKeys(MinecraftClient client, boolean forward, boolean sprint, boolean jump, int strafe) {
        client.options.forwardKey.setPressed(forward);
        client.options.sprintKey.setPressed(sprint);
        client.options.jumpKey.setPressed(jump);
        client.options.leftKey.setPressed(strafe < 0);
        client.options.rightKey.setPressed(strafe > 0);
        client.options.backKey.setPressed(wantBack);
        wantBack = false;
    }

    // ------------------------------------------------------------------
    // UHC mode (mode 3): no natural regen, so it heals with golden apples, and it fights with everything
    // on the hotbar: bow, rod, cobwebs, lava, water bucket, blocks. Items are found by type, any slot.
    // Arrows can be anywhere in the inventory. Melee is the normal sword fight.
    // ------------------------------------------------------------------

    private static final boolean UHC_LAVA = true;       // lava on the target's feet, then scoop it back up
    private static final float HEAL_BELOW = 14.0f;      // eats a golden apple under 7 hearts (when it is safe to)
    private static final float HEAD_BELOW = 8.0f;       // golden head at 4 hearts or less (it also eats in a fight then)
    private static final int LAVA_HOLD = 20;            // ticks the lava stays down before it is scooped up
    private static final boolean UHC_TRAP = true;       // corner trap: web + lava + blocks + water -> obsidian

    private static int uhcSword = SWORD_SLOT, uhcAxe = AXE_SLOT;
    private static int uhcBow = -1, uhcRod = -1, uhcGap = -1, uhcWater = -1, uhcLava = -1;
    private static int uhcBucket = -1, uhcBlocks = -1, uhcWeb = -1;
    private static int uhcHead = -1, eatSlot = -1;

    // ---- UHC off-hand: shield normally, totem when close to death, shield again after a pop or once healed ----
    private static final float TOTEM_BELOW = 6.0f;      // 3 hearts or less: swap the shield for a totem
    private static final float SHIELD_BACK = 10.0f;     // 5 hearts or more: healed enough, shield back
    private static boolean totemMode = false, hadTotem = false;
    private static int shieldUntil = 0, offhandCd = 0;

    // ---- pulling buckets from the inventory, picking up leftover water, getting out from behind walls ----
    private static int fetchCd = 0;
    private static BlockPos pendingWater = null;
    private static int pendingWaterTick = 0, pendingTries = 0;
    private static boolean pendAimed = false;
    private static int stuckTicks = 0, detourTicks = 0, detourDir = 1, detourFlips = 0;
    private static boolean uhcArrows = false;
    private static boolean useHold = false;             // right-click held this tick (eating / drawing the bow)
    private static String uhcAction = "-";              // what UHC mode is doing this tick (shown in the debug line)
    private static boolean shieldUp = false;            // our own shield is raised this tick
    private static boolean eating = false;
    private static int eatTicks = 0, healCd = 0;
    private static boolean drawing = false;
    private static int drawTicks = 0, bowCd = 0;
    private static int rodState = 0, rodTicks = 0, rodCd = 0, rodReel = 8;
    private static int webCd = 0, lavaCd = 0, lavaTick = 0, lavaSlotUsed = 0;
    private static BlockPos lavaPos = null;
    private static boolean lavaAimed = false;
    private static boolean waterOut = false, clutchAimed = false, waterForWeb = false;
    private static int waterTick = 0, waterTries = 0, waterCd = 0, waterSlotUsed = 0;
    private static double groundY = 0;
    private static BlockPos pillarBase = null;
    private static boolean pillarPlaced = false;
    private static int lastHitNo = -1000;
    private static boolean aimPhase = false;            // bucket: rotation sent this tick, use it next tick
    private static int aimPhaseTick = -10;
    private static int trapStage = 0, trapStageTick = 0, trapTick = 0, trapCd = 0, trapTries = 0;
    private static boolean trapWasSure = false;          // the trap was started in a near-certain situation
    private static BlockPos trapF = null, trapWaterCell = null;
    private static boolean trapLavaDone = false, trapWaterDone = false;

    private static int findHotbar(ClientPlayerEntity player, Predicate<ItemStack> test) {
        for (int i = 0; i < 9; i++) {
            if (test.test(player.getInventory().getStack(i))) return i;
        }
        return -1;
    }

    private static void scanUhcItems(ClientPlayerEntity player) {
        uhcSword = findHotbar(player, st -> st.isIn(ItemTags.SWORDS));
        if (uhcSword < 0) uhcSword = SWORD_SLOT;
        uhcAxe = findHotbar(player, st -> st.isIn(ItemTags.AXES));
        if (uhcAxe < 0) uhcAxe = uhcSword;
        uhcBow = findHotbar(player, st -> st.isOf(Items.BOW));
        uhcRod = findHotbar(player, st -> st.isOf(Items.FISHING_ROD));
        uhcGap = findHotbar(player, st -> st.isOf(Items.GOLDEN_APPLE));
        uhcHead = findHotbar(player, st -> st.isOf(Items.PLAYER_HEAD));
        uhcWater = findHotbar(player, st -> st.isOf(Items.WATER_BUCKET));
        uhcLava = findHotbar(player, st -> st.isOf(Items.LAVA_BUCKET));
        uhcBucket = findHotbar(player, st -> st.isOf(Items.BUCKET));
        uhcWeb = findHotbar(player, st -> st.isOf(Items.COBWEB));
        uhcBlocks = findHotbar(player, st -> st.getItem() instanceof BlockItem
                && !st.isOf(Items.COBWEB) && !st.isOf(Items.TNT));
        uhcArrows = false;
        for (int i = 0; i < player.getInventory().size(); i++) {
            ItemStack st = player.getInventory().getStack(i);
            if (st.isOf(Items.ARROW) || st.isOf(Items.SPECTRAL_ARROW) || st.isOf(Items.TIPPED_ARROW)) {
                uhcArrows = true;
                break;
            }
        }
    }

    private static void select(ClientPlayerEntity player, int slot) {
        if (slot >= 0) player.getInventory().setSelectedSlot(slot);
    }

    private static void lookAt(ClientPlayerEntity player, Vec3d p) {
        Vec3d eye = player.getEyePos();
        double dx = p.x - eye.x, dy = p.y - eye.y, dz = p.z - eye.z;
        player.setYaw((float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0f);
        player.setPitch((float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz))));
    }

    /** Snaps onto a projectile arc (with lead on a moving target). False if out of range. */
    private static boolean aimProjectile(ClientPlayerEntity player, PlayerEntity target,
                                         double speed, double gravity, double lead) {
        Vec3d eye = player.getEyePos();
        double flight = player.distanceTo(target) / speed;
        double tx = target.getX() + targetVel.x * flight * lead;
        double tz = target.getZ() + targetVel.z * flight * lead;
        double ty = target.getY() + target.getHeight() * 0.6;
        double dx = tx - eye.x, dz = tz - eye.z, dy = ty - eye.y;
        float pitch = solveLaunch(Math.sqrt(dx * dx + dz * dz), dy, speed, gravity, 2.0);
        if (Float.isNaN(pitch)) return false;
        player.setYaw((float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0f);
        player.setPitch(pitch);
        return true;
    }

    /** Blocks of air between the feet and the first solid block / liquid below (99 = nothing close, or water). */
    private static double heightAbove(ClientWorld world, ClientPlayerEntity player) {
        int bx = MathHelper.floor(player.getX());
        int bz = MathHelper.floor(player.getZ());
        int y0 = MathHelper.floor(player.getY() - 0.001);
        for (int d = 0; d <= 12; d++) {
            BlockPos p = new BlockPos(bx, y0 - d, bz);
            BlockState st = world.getBlockState(p);
            if (!st.getFluidState().isEmpty()) return 99.0;           // already landing in a liquid
            if (!st.getCollisionShape(world, p).isEmpty()) return player.getY() - (p.getY() + 1.0);
        }
        return 99.0;
    }

    /** One tick of UHC behaviour. True = this tick is fully handled (keys set); false = go and melee. */
    private static boolean uhcAct(MinecraftClient client, ClientWorld world, ClientPlayerEntity player, PlayerEntity target) {
        scanUhcItems(player);
        if (healCd > 0) healCd--;
        if (bowCd > 0) bowCd--;
        if (rodCd > 0) rodCd--;
        if (webCd > 0) webCd--;
        if (lavaCd > 0) lavaCd--;
        if (waterCd > 0) waterCd--;

        double dist = player.distanceTo(target);
        boolean onGround = player.isOnGround();
        if (onGround) groundY = player.getY();
        double fallen = groundY - player.getY();

        uhcAction = "melee";
        if (uhcWater(client, world, player, onGround, fallen)) { uhcAction = "water"; return true; }   // also the way out of a cobweb

        // stuck in a cobweb and no water: cut it with the sword unless the target is already in reach
        if (dist > 3.2 && inWeb(world, player)) {
            select(player, uhcSword);
            aim(player, target, false);
            client.interactionManager.updateBlockBreakingProgress(player.getBlockPos(), Direction.UP);
            player.swingHand(Hand.MAIN_HAND);
            setKeys(client, false, false, false, 0);
            uhcAction = "cut web";
            return true;
        }

        if (uhcHeal(client, player, target, dist)) { uhcAction = "heal"; return true; }
        if (uhcTrap(client, world, player, target, dist)) { uhcAction = "trap" + trapStage; return true; }
        if (trapStage == 0 && uhcCleanup(client, world, player, target, dist)) { uhcAction = "pick up water"; return true; }
        if (uhcLava(client, world, player, target, dist)) { uhcAction = "lava"; return true; }
        if (uhcWeb(client, world, player, target, dist)) { uhcAction = "web"; return true; }
        if (uhcRod(client, world, player, target, dist)) { uhcAction = "rod"; return true; }
        if (uhcMomentum(client, world, player, target, dist, onGround)) { uhcAction = "momentum"; return true; }
        if (uhcBow(client, world, player, target, dist)) { uhcAction = "bow"; return true; }
        boolean blocked = uhcBlocks(client, world, player, target, dist, onGround);
        if (blocked) uhcAction = "blocks";
        return blocked;
    }

    // ---- shared helpers for the world-interaction moves ----

    private static boolean solid(ClientWorld world, BlockPos p) {
        return !world.getBlockState(p).getCollisionShape(world, p).isEmpty();
    }

    private static boolean inWeb(ClientWorld world, Entity e) {
        return world.getBlockState(e.getBlockPos()).isOf(Blocks.COBWEB)
                || world.getBlockState(BlockPos.ofFloored(e.getX(), e.getEyeY(), e.getZ())).isOf(Blocks.COBWEB);
    }

    private static Vec3d faceCenter(BlockPos support, Direction face) {
        return Vec3d.ofCenter(support).add(face.getOffsetX() * 0.5, face.getOffsetY() * 0.5, face.getOffsetZ() * 0.5);
    }

    /** True if a ray from our eyes through the middle of that face really hits that face, within bucket reach. */
    private static boolean canBucketAt(ClientWorld world, ClientPlayerEntity player, BlockPos support, Direction face) {
        Vec3d eye = player.getEyePos();
        Vec3d point = faceCenter(support, face);
        if (eye.distanceTo(point) > 4.4) return false;
        Vec3d end = eye.add(point.subtract(eye).normalize().multiply(4.6));
        BlockHitResult hit = world.raycast(new RaycastContext(eye, end,
                RaycastContext.ShapeType.OUTLINE, RaycastContext.FluidHandling.NONE, player));
        return hit.getType() == HitResult.Type.BLOCK && hit.getBlockPos().equals(support) && hit.getSide() == face;
    }

    /**
     * Buckets do not work with a block-click: they use whatever the crosshair is on. So: select the bucket and look
     * at the spot this tick, use it next tick (the server has the rotation by then). True on the tick it was used.
     */
    private static boolean bucketUse(MinecraftClient client, ClientPlayerEntity player, int slot, Vec3d point) {
        select(player, slot);
        lookAt(player, point);
        if (!aimPhase || aimPhaseTick != tickNo - 1) {
            aimPhase = true;
            aimPhaseTick = tickNo;
            return false;
        }
        aimPhase = false;
        client.interactionManager.interactItem(player, Hand.MAIN_HAND);
        player.swingHand(Hand.MAIN_HAND);
        return true;
    }

    private static Direction dirToward(double dx, double dz) {
        return Math.abs(dx) > Math.abs(dz)
                ? (dx > 0 ? Direction.EAST : Direction.WEST)
                : (dz > 0 ? Direction.SOUTH : Direction.NORTH);
    }

    private static void placeSide(MinecraftClient client, ClientPlayerEntity player, BlockPos support, Direction dir) {
        Vec3d hit = new Vec3d(support.getX() + 0.5 + dir.getOffsetX() * 0.5, support.getY() + 0.5,
                support.getZ() + 0.5 + dir.getOffsetZ() * 0.5);
        client.interactionManager.interactBlock(player, Hand.MAIN_HAND, new BlockHitResult(hit, dir, support, false));
        player.swingHand(Hand.MAIN_HAND);
    }

    /** Water bucket: clutch long falls, put out fire, and always pick the water back up. */
    private static boolean uhcWater(MinecraftClient client, ClientWorld world, ClientPlayerEntity player,
                                    boolean onGround, double fallen) {
        if (waterOut) {
            if (tickNo - waterTick >= 3 && player.getInventory().getStack(waterSlotUsed).isOf(Items.WATER_BUCKET)) {   // got it back
                waterOut = false;
                waterCd = 30;
                clutchAimed = false;
                return false;
            }
            boolean landed = (onGround && tickNo - waterTick >= 6) || tickNo - waterTick > 8;
            if (waterForWeb) {
                // The water is poured above the web and has to flow down into it: do not scoop it
                // until the web is really gone (or a long timeout has passed).
                BlockPos here = player.getBlockPos();
                boolean webGone = !inWeb(world, player)
                        && !world.getBlockState(here).isOf(Blocks.COBWEB)
                        && !world.getBlockState(here.up()).isOf(Blocks.COBWEB);
                landed = tickNo - waterTick >= 10 && (webGone || tickNo - waterTick > 40);
            }
            if (!landed) {                                   // still falling: keep looking down
                player.setPitch(90.0f);
                setKeys(client, false, false, false, 0);
                return true;
            }
            int bucket = findHotbar(player, st -> st.isOf(Items.BUCKET));
            if (bucket < 0 || waterTries >= 3 || tickNo - waterTick > 80) {
                BlockPos leftover = nearestWaterSource(world, player);
                if (leftover != null) {                      // could not scoop it: come back for it later
                    pendingWater = leftover;
                    pendingWaterTick = tickNo;
                    pendingTries = 0;
                    pendAimed = false;
                }
                waterOut = false;
                waterCd = 60;
                clutchAimed = false;
                return false;
            }
            select(player, bucket);
            BlockPos source = nearestWaterSource(world, player);
            if (source != null) lookAt(player, Vec3d.ofCenter(source));   // the water sits above the web, not under us
            else player.setPitch(90.0f);
            if (clutchAimed) {                               // rotation was sent last tick: scoop
                client.interactionManager.interactItem(player, Hand.MAIN_HAND);
                player.swingHand(Hand.MAIN_HAND);
                waterTries++;
                clutchAimed = false;
            } else {
                clutchAimed = true;
            }
            setKeys(client, false, false, false, 0);
            return true;
        }

        boolean fire = player.isOnFire() && onGround;
        boolean falling = !onGround && fallen > 3.8 && player.getVelocity().y < -0.45;
        boolean webbed = inWeb(world, player);              // water washes a cobweb away
        if (uhcWater < 0 || waterCd > 0 || !(fire || falling || webbed)) {
            clutchAimed = false;
            return false;
        }
        if (falling) {
            double h = heightAbove(world, player);
            if (h > 7.0) {
                clutchAimed = false;
                return false;
            }
            select(player, uhcWater);
            player.setPitch(90.0f);
            if (!clutchAimed) {                              // look down a tick early so the server has the rotation
                clutchAimed = true;
                setKeys(client, false, false, false, 0);
                return true;
            }
            if (h > 2.6) {                                   // wait until the ground is inside bucket reach
                setKeys(client, false, false, false, 0);
                return true;
            }
        } else {
            select(player, uhcWater);
            player.setPitch(90.0f);
            if (!clutchAimed) {
                clutchAimed = true;
                setKeys(client, false, false, false, 0);
                return true;
            }
        }
        client.interactionManager.interactItem(player, Hand.MAIN_HAND);
        player.swingHand(Hand.MAIN_HAND);
        waterOut = true;
        waterTick = tickNo;
        waterTries = 0;
        waterSlotUsed = uhcWater;
        waterForWeb = webbed && !falling;
        clutchAimed = false;
        setKeys(client, false, false, false, 0);
        return true;
    }

    /** Golden apples: eats when low and safe (or very low), backing away while it eats. */
    private static boolean uhcHeal(MinecraftClient client, ClientPlayerEntity player, PlayerEntity target, double dist) {
        float hp = player.getHealth();
        boolean noAbsorb = player.getAbsorptionAmount() < 1.0f;
        if (!eating) {
            if ((uhcGap < 0 && uhcHead < 0) || healCd > 0 || !noAbsorb || hp >= HEAL_BELOW) return false;
            // 4 hearts or less: the head if there is one, otherwise the golden apple
            eatSlot = (hp <= HEAD_BELOW && uhcHead >= 0) ? uhcHead : uhcGap;
            if (eatSlot < 0) return false;
            boolean emergency = hp <= HEAD_BELOW;
            if (dist <= 4.5 && !emergency) return false;    // fight first, eat when there is room
            eating = true;
            eatTicks = 0;
            drawing = false;
            rodState = 0;
        }
        eatTicks++;
        if (eatSlot < 0 || eatTicks > 60 || (dist < 2.4 && hp > HEAD_BELOW)) {
            eating = false;
            healCd = 20;
            return false;
        }
        if (eatTicks > 4 && !player.isUsingItem()) {         // finished
            eating = false;
            healCd = 40;
            return false;
        }
        select(player, eatSlot);
        aim(player, target, false);
        if (eatSlot == uhcHead) player.setPitch(-80.0f);   // a head would be PLACED on a block: look at the sky so it is eaten
        useHold = true;
        wantBack = dist < 6.0;
        setKeys(client, false, false, false, strafeDir);
        return true;
    }

    /**
     * Lava: on the head of a target sitting in a cobweb, or on the feet of a free one. Then back off and scoop it
     * up before it spreads to us. (Buckets are aimed, not block-clicked.)
     */
    private static boolean uhcLava(MinecraftClient client, ClientWorld world, ClientPlayerEntity player,
                                   PlayerEntity target, double dist) {
        if (!UHC_LAVA) return false;
        if (lavaPos != null) {
            boolean regained = player.getInventory().getStack(lavaSlotUsed).isOf(Items.LAVA_BUCKET);
            Vec3d c = Vec3d.ofCenter(lavaPos);
            double d = player.getEyePos().distanceTo(c);
            if (regained || tickNo - lavaTick > 140) {
                lavaPos = null;
                lavaCd = 200;
                lavaAimed = false;
                return false;
            }
            if (tickNo - lavaTick < LAVA_HOLD) {             // let it burn, keep out of the flow
                select(player, uhcSword);
                aim(player, target, false);
                wantBack = d < 3.0;                          // stay close enough to scoop it back
                setKeys(client, false, false, false, strafeDir);
                return true;
            }
            int bucket = findHotbar(player, st -> st.isOf(Items.BUCKET));
            if (bucket < 0) {                                // no empty bucket: give up on it
                lavaPos = null;
                lavaCd = 200;
                lavaAimed = false;
                return false;
            }
            select(player, bucket);
            lookAt(player, c);
            if (d > 4.0) {                                   // too far to scoop: walk back into reach
                lavaAimed = false;
                setKeys(client, true, false, false, 0);
                return true;
            }
            if (lavaAimed) {
                client.interactionManager.interactItem(player, Hand.MAIN_HAND);
                player.swingHand(Hand.MAIN_HAND);
                lavaAimed = false;
            } else {
                lavaAimed = true;
            }
            setKeys(client, false, false, false, 0);
            return true;
        }
        if (uhcLava < 0 || lavaCd > 0 || dist < 2.6 || dist > 4.6) return false;
        if (player.getY() < target.getY() - 0.3) return false;   // lava flows downhill: never from below

        BlockPos tf = target.getBlockPos();
        BlockPos support;
        BlockPos cell;
        if (world.getBlockState(tf).isOf(Blocks.COBWEB) && world.getBlockState(tf.up()).isAir()) {
            support = tf;                                    // click the top of the web: lava lands on their head
            cell = tf.up();
        } else if (target.isOnGround() && dist >= 3.5 && world.getBlockState(tf).isAir() && solid(world, tf.down())) {
            support = tf.down();                             // free target: lava on their feet
            cell = tf;
        } else {
            return false;
        }
        if (!canBucketAt(world, player, support, Direction.UP)) return false;
        if (bucketUse(client, player, uhcLava, faceCenter(support, Direction.UP))) {
            lavaPos = cell;
            lavaTick = tickNo;
            lavaSlotUsed = uhcLava;
            lavaCd = 300;
            lavaAimed = false;
        }
        setKeys(client, false, false, false, 0);
        return true;
    }

    /**
     * Corner trap: after a hit, a target backed into a corner gets webbed to the wall, lava on their head, the open
     * sides walled in with blocks, then water on top so the lava turns to obsidian. The longest move here:
     * every step has a timeout and the whole thing aborts if the target gets out of the cell.
     */
    /**
     * Near-certain trap situations: the target is in a corner, in a one-block-wide corridor, already stuck in a
     * cobweb, or standing still while eating / drinking. The bot goes for the trap at once in these.
     */
    private static boolean trapSure(ClientWorld world, PlayerEntity target) {
        BlockPos f0 = target.getBlockPos();
        if (world.getBlockState(f0).isOf(Blocks.COBWEB)) return true;              // already webbed
        boolean n = solid(world, f0.north()) || solid(world, f0.north().up());
        boolean sth = solid(world, f0.south()) || solid(world, f0.south().up());
        boolean e = solid(world, f0.east()) || solid(world, f0.east().up());
        boolean w = solid(world, f0.west()) || solid(world, f0.west().up());
        if ((n || sth) && (e || w)) return true;                                   // corner
        if ((n && sth) || (e && w)) return true;                                   // corridor
        double speedSq = target.getVelocity().x * target.getVelocity().x + target.getVelocity().z * target.getVelocity().z;
        return target.isUsingItem() && speedSq < 0.0025;                           // standing still, eating
    }

    private static boolean uhcTrap(MinecraftClient client, ClientWorld world, ClientPlayerEntity player,
                                   PlayerEntity target, double dist) {
        if (!UHC_TRAP) return false;
        if (trapStage == 0) {
            if (trapCd > 0 || uhcLava < 0 || uhcBlocks < 0) return false;
            boolean sure = trapSure(world, target);
            double maxDist = sure ? 5.2 : 4.4;
            if (dist < 2.4 || dist > maxDist || !target.isOnGround() || player.getHealth() < 8.0f) return false;
            if (!sure && tickNo - lastHitNo > 200) return false;   // an ordinary trap needs a recent hit first
            trapWasSure = sure;
            BlockPos f0 = target.getBlockPos();
            boolean n = solid(world, f0.north()) || solid(world, f0.north().up());
            boolean sth = solid(world, f0.south()) || solid(world, f0.south().up());
            boolean e = solid(world, f0.east()) || solid(world, f0.east().up());
            boolean w = solid(world, f0.west()) || solid(world, f0.west().up());
            // (no corner needed any more: the side walls are built in step 3 wherever the target stands)
            trapF = f0;
            trapStage = 1;
            trapStageTick = tickNo;
            trapTick = tickNo;
            trapTries = 0;
            trapLavaDone = false;
            trapWaterDone = false;
            trapWaterCell = null;
            aimPhase = false;
        }

        BlockPos f = trapF;
        BlockPos head = f.up();
        Vec3d fc = Vec3d.ofBottomCenter(f);
        double off = Math.hypot(target.getX() - fc.x, target.getZ() - fc.z);
        if (off > 0.95 || dist < 2.0 || dist > (trapWasSure ? 6.0 : 5.0) || tickNo - trapTick > 240 || player.getHealth() < 6.0f
                || inWeb(world, player)) {
            trapStage = 0;                                    // target got out / we are in trouble: give it up
            trapCd = trapWasSure ? 100 : 300;
            return false;
        }
        if (tickNo - trapStageTick > 40 && trapStage < 5) {   // a step is stuck: move on
            trapStage++;
            trapStageTick = tickNo;
            trapTries = 0;
        }
        aim(player, target, false);

        if (trapStage == 1) {                                 // 1) web to the wall
            if (uhcWeb < 0 || world.getBlockState(f).isOf(Blocks.COBWEB) || trapTries >= 3
                    || !world.getBlockState(f).isAir() || !solid(world, f.down())
                    || player.getEyePos().distanceTo(faceCenter(f.down(), Direction.UP)) > 4.4) {
                trapStage = 2;
                trapStageTick = tickNo;
                trapTries = 0;
            } else {
                select(player, uhcWeb);
                clickTop(client, player, f.down());
                trapTries++;
                setKeys(client, false, false, false, 0);
                return true;
            }
        }

        if (trapStage == 2) {                                 // 2) lava on the head (or the feet if there is no web)
            boolean web = world.getBlockState(f).isOf(Blocks.COBWEB);
            BlockPos support = web ? f : f.down();
            BlockPos cell = web ? head : f;
            if (trapLavaDone || !world.getBlockState(cell).isAir()) {
                if (!trapLavaDone) {                          // cell is not free: nothing to trap with
                    trapStage = 0;
                    trapCd = 200;
                    return false;
                }
                trapStage = 3;
                trapStageTick = tickNo;
                trapTries = 0;
            } else if (!canBucketAt(world, player, support, Direction.UP)) {
                if (++trapTries > 8) {
                    trapStage = 0;
                    trapCd = 200;
                    return false;
                }
                setKeys(client, false, false, false, 0);
                return true;
            } else {
                if (bucketUse(client, player, uhcLava, faceCenter(support, Direction.UP))) {
                    trapLavaDone = true;
                    lavaCd = 300;
                    trapStageTick = tickNo;
                }
                setKeys(client, false, false, false, 0);
                return true;
            }
        }

        if (trapStage == 3) {                                 // 3) wall every open side, feet and head level
            Direction[] sides = {Direction.NORTH, Direction.EAST, Direction.SOUTH, Direction.WEST};
            for (Direction d : sides) {
                BlockPos fd = f.offset(d);
                BlockPos hd = fd.up();
                if (!solid(world, fd) && world.getBlockState(fd).isAir() && solid(world, fd.down())
                        && player.getEyePos().distanceTo(faceCenter(fd.down(), Direction.UP)) <= 4.4) {
                    select(player, uhcBlocks);
                    clickTop(client, player, fd.down());
                    setKeys(client, false, false, false, 0);
                    return true;
                }
                if (solid(world, fd) && !solid(world, hd) && world.getBlockState(hd).isAir()
                        && player.getEyePos().distanceTo(faceCenter(fd, Direction.UP)) <= 4.4) {
                    select(player, uhcBlocks);
                    clickTop(client, player, fd);
                    setKeys(client, false, false, false, 0);
                    return true;
                }
            }
            trapStage = 4;                                    // nothing left to place
            trapStageTick = tickNo;
            trapTries = 0;
        }

        if (trapStage == 4) {                                 // 4) water above the lava: lava + water = obsidian
            BlockPos wallTop = null;
            if (!trapWaterDone && uhcWater >= 0) {
                Direction[] sides = {Direction.NORTH, Direction.EAST, Direction.SOUTH, Direction.WEST};
                for (Direction d : sides) {
                    BlockPos hd = f.offset(d).up();
                    if (solid(world, hd) && world.getBlockState(hd.up()).isAir()
                            && canBucketAt(world, player, hd, Direction.UP)) {
                        wallTop = hd;
                        break;
                    }
                }
            }
            if (trapWaterDone || wallTop == null) {
                trapStage = 5;
                trapStageTick = tickNo;
                trapTries = 0;
            } else {
                if (bucketUse(client, player, uhcWater, faceCenter(wallTop, Direction.UP))) {
                    trapWaterDone = true;
                    trapWaterCell = wallTop.up();
                    pendingWater = trapWaterCell;          // scooped back after the trap (uhcCleanup)
                    pendingWaterTick = tickNo;
                    pendingTries = 0;
                    pendAimed = false;
                    trapStage = 5;
                    trapStageTick = tickNo;
                    trapTries = 0;
                }
                setKeys(client, false, false, false, 0);
                return true;
            }
        }

        if (trapStage == 5) {                                 // 5) wait for the obsidian, then take the water back
            boolean obsidian = world.getBlockState(head).isOf(Blocks.OBSIDIAN);
            if (!obsidian && tickNo - trapStageTick < 40) {
                setKeys(client, false, false, false, 0);
                return true;
            }
            // (the water is scooped back by uhcCleanup once the trap is finished: it walks back into reach if needed)
            trapStage = 0;
            trapCd = trapWasSure ? 120 : 400;
            return false;
        }
        return false;
    }

    /** Sprint-bridging: from far out, fill any hole in front of us (and the block after it) so we never lose speed. */
    private static boolean uhcMomentum(MinecraftClient client, ClientWorld world, ClientPlayerEntity player,
                                       PlayerEntity target, double dist, boolean onGround) {
        if (uhcBlocks < 0 || !onGround || dist < 6.0 || dist > 16.0) return false;
        double dx = target.getX() - player.getX();
        double dz = target.getZ() - player.getZ();
        if (Math.abs(target.getY() - player.getY()) > 2.2) return false;
        BlockPos base = new BlockPos(MathHelper.floor(player.getX()), MathHelper.floor(player.getY() - 0.01),
                MathHelper.floor(player.getZ()));
        Direction dir = dirToward(dx, dz);
        BlockPos ahead = base.offset(dir);
        if (world.getBlockState(base).isAir() || !world.getBlockState(ahead).isAir()
                || !world.getBlockState(ahead.down()).isAir()) return false;   // no hole in front: just keep sprinting
        select(player, uhcBlocks);
        placeSide(client, player, base, dir);                // the block in front of us...
        placeSide(client, player, ahead, dir);               // ...and the one after it, same tick
        aim(player, target, false);
        setKeys(client, true, true, false, 0);
        return true;
    }

    /** Cobweb on the target's feet just before the fight (slows them, free hits). */
    private static boolean uhcWeb(MinecraftClient client, ClientWorld world, ClientPlayerEntity player,
                                  PlayerEntity target, double dist) {
        if (uhcWeb < 0 || webCd > 0 || dist < 3.2 || dist > 4.5 || !target.isOnGround()) return false;
        BlockPos feet = target.getBlockPos();
        BlockPos floor = feet.down();
        if (!world.getBlockState(feet).isAir()) return false;
        if (!world.getBlockState(floor).isSideSolidFullSquare(world, floor, Direction.UP)) return false;
        select(player, uhcWeb);
        clickTop(client, player, floor);
        webCd = 100;
        aim(player, target, false);
        setKeys(client, true, true, false, strafeDir);
        return true;
    }

    /** Fishing rod from mid range: cast, reel in a few ticks later (knockback / pull), then the sword is out again. */
    private static boolean uhcRod(MinecraftClient client, ClientWorld world, ClientPlayerEntity player,
                                  PlayerEntity target, double dist) {
        if (uhcRod < 0) {
            rodState = 0;
            return false;
        }
        if (rodState == 0) {
            if (rodCd > 0 || dist < 3.6 || dist > 7.0 || !lineClear(world, player, target)) return false;
            if (!aimProjectile(player, target, 1.1, 0.03, 0.5)) return false;
            select(player, uhcRod);                          // aim now, cast next tick
            rodState = 1;
            setKeys(client, true, true, false, strafeDir);
            return true;
        }
        select(player, uhcRod);
        if (rodState == 1) {
            aimProjectile(player, target, 1.1, 0.03, 0.5);
            client.interactionManager.interactItem(player, Hand.MAIN_HAND);   // cast
            player.swingHand(Hand.MAIN_HAND);
            rodState = 2;
            rodTicks = 0;
            rodReel = MathHelper.clamp((int) (dist / 1.0) + 2, 4, 10);
            setKeys(client, true, true, false, strafeDir);
            return true;
        }
        rodTicks++;
        aim(player, target, false);
        if (rodTicks >= rodReel || dist < 2.5) {
            client.interactionManager.interactItem(player, Hand.MAIN_HAND);   // reel in
            player.swingHand(Hand.MAIN_HAND);
            rodState = 0;
            rodCd = 50;
        }
        setKeys(client, true, true, false, strafeDir);
        return true;
    }

    /** Bow from range: full draw, lead + arrow drop, release, repeat. */
    private static boolean uhcBow(MinecraftClient client, ClientWorld world, ClientPlayerEntity player,
                                  PlayerEntity target, double dist) {
        if (uhcBow < 0 || !uhcArrows || bowCd > 0) {
            drawing = false;
            return false;
        }
        boolean inRange = dist >= 7.0 && dist <= 45.0;
        if (!drawing) {
            if (!inRange || !lineClear(world, player, target)) return false;
            drawing = true;
            drawTicks = 0;
        }
        if (dist < 5.5 || dist > 50.0 || !aimProjectile(player, target, 3.0, 0.05, 0.9)) {
            drawing = false;                                 // too close / out of range: stop (key up)
            bowCd = 5;
            return false;
        }
        select(player, uhcBow);
        drawTicks++;
        if (drawTicks >= 22) {                               // fully drawn: let go this tick
            drawing = false;
            bowCd = 2;
            setKeys(client, false, false, false, strafeDir);
            return true;
        }
        useHold = true;
        setKeys(client, false, false, false, strafeDir);
        return true;
    }

    /** Blocks: pillar up to a target above us, bridge across gaps toward a target. */
    private static boolean uhcBlocks(MinecraftClient client, ClientWorld world, ClientPlayerEntity player,
                                     PlayerEntity target, double dist, boolean onGround) {
        if (uhcBlocks < 0) return false;
        double dx = target.getX() - player.getX();
        double dz = target.getZ() - player.getZ();
        double dxz = Math.sqrt(dx * dx + dz * dz);
        double dy = target.getY() - player.getY();

        if (dy >= 2.2 && dxz <= 6.0) {                       // pillar: jump, drop a block under us at the top of the jump
            boolean jump = false;
            if (onGround) {
                pillarBase = new BlockPos(MathHelper.floor(player.getX()), MathHelper.floor(player.getY() - 0.01),
                        MathHelper.floor(player.getZ()));
                pillarPlaced = false;
                jump = true;
            } else if (pillarBase != null && !pillarPlaced && player.getY() >= pillarBase.getY() + 2.0
                    && world.getBlockState(pillarBase.up()).isAir()) {
                select(player, uhcBlocks);
                clickTop(client, player, pillarBase);
                pillarPlaced = true;
            }
            aim(player, target, false);
            setKeys(client, false, false, jump, 0);
            return true;
        }

        if (onGround && dxz > 3.0 && dy < 2.2) {             // bridge: a real gap (3+ deep) in front of us
            BlockPos base = new BlockPos(MathHelper.floor(player.getX()), MathHelper.floor(player.getY() - 0.01),
                    MathHelper.floor(player.getZ()));
            Direction dir = Math.abs(dx) > Math.abs(dz)
                    ? (dx > 0 ? Direction.EAST : Direction.WEST)
                    : (dz > 0 ? Direction.SOUTH : Direction.NORTH);
            BlockPos ahead = base.offset(dir);
            if (!world.getBlockState(base).isAir()
                    && world.getBlockState(ahead).isAir()
                    && world.getBlockState(ahead.down()).isAir()
                    && world.getBlockState(ahead.down(2)).isAir()) {
                select(player, uhcBlocks);
                Vec3d hit = new Vec3d(base.getX() + 0.5 + dir.getOffsetX() * 0.5, base.getY() + 0.5,
                        base.getZ() + 0.5 + dir.getOffsetZ() * 0.5);
                client.interactionManager.interactBlock(player, Hand.MAIN_HAND, new BlockHitResult(hit, dir, base, false));
                player.swingHand(Hand.MAIN_HAND);
                aim(player, target, false);
                setKeys(client, true, true, false, 0);
                return true;
            }
        }
        return false;
    }

    public static void tick(MinecraftClient client) {
        if (infoHold > 0) infoHold--;
        if (!active) return;
        ClientPlayerEntity player = client.player;
        if (player == null || client.world == null || client.interactionManager == null) {
            reset(client);
            return;
        }
        // Round over (title / message from the server) or you died: stop at once, mid-swing.
        if (roundOverFlag) {
            roundOverFlag = false;
            stopBot(client, player, "round over (" + roundOverWhy + ")");
            return;
        }
        if (STOP_AT_ROUND_END && (player.isDead() || player.getHealth() <= 0.0f
                || client.currentScreen instanceof DeathScreen)) {
            stopBot(client, player, "you died");
            return;
        }

        if (client.currentScreen != null) {      // menus / chat open: pause
            releaseKeys(client);
            return;
        }

        // The target is dead or gone.
        if (STOP_AT_ROUND_END && lastTarget != null
                && (lastTarget.isDead() || lastTarget.getHealth() <= 0.0f || lastTarget.isRemoved())) {
            stopBot(client, player, "target down");
            return;
        }

        PlayerEntity target = findPartner(client, player);
        if (target == null) {
            releaseKeys(client);
            crystalStage = 0;
            pearlPending = false;
            if (STOP_AT_ROUND_END && lastTarget != null && ++noTargetTicks > 60) {   // it left / was teleported away
                stopBot(client, player, "target gone");
                return;
            }
            if (--noticeCooldown <= 0) {
                if (infoHold == 0) player.sendMessage(Text.literal("Spar bot: no partner nearby"), true);
                noticeCooldown = 40;
            }
            return;
        }
        noTargetTicks = 0;
        lastTarget = target;
        if (player.distanceTo(target) < 12.0f) fightTicks++;
        ClientWorld world = client.world;
        tickNo++;
        trackMotion(player, target);
        trackResults(player, target);

        if (mode == 3) {                               // UHC: heal, shoot, rod, buckets, blocks... or fall through to melee
            useHold = false;
            boolean handled = uhcAct(client, world, player, target);
            client.options.useKey.setPressed(useHold);
            if (handled) return;
        }

        int swordSlot = mode == 3 ? uhcSword : SWORD_SLOT;
        if (crystalStage == 0 && !pearlPending && player.getInventory().getSelectedSlot() != swordSlot) {
            player.getInventory().setSelectedSlot(swordSlot);
        }

        if (!pearlPending) aim(player, target, rush > 0 || insane());   // while a pearl is lined up the view stays on its arc
        if (mode != 3) {
            ensureTotem(client, player);
        } else {
            uhcOffhand(client, player);
            if (!eating && !drawing) uhcFetchBuckets(client, player);
        }

        if (--strafeTicks <= 0) {
            if (skill > 0.55f) {                      // skilled: always moving, flips direction often
                strafeDir = RND.nextBoolean() ? 1 : -1;
                strafeTicks = insane() ? 2 + RND.nextInt(3) : Math.round(lerp(14f, 4f, skill)) + RND.nextInt(6);
            } else {
                strafeDir = RND.nextInt(3) - 1;       // -1 left, 0 none, 1 right
                strafeTicks = 10 + RND.nextInt(20);
            }
        }

        double dist = player.distanceTo(target);

        if (pearlPending) throwPearl(client, player, target, dist);

        if (crystalStage == 2) {                       // crystal spam: no sword, place + pop every tick
            if (keepSpamming(world, player, target, dist)) {
                setKeys(client, false, false, false, strafeDir);
                crystalCycle(client, player, target);
                return;
            }
            crystalStage = 0;
            ticksSinceHit = 0;
            player.getInventory().setSelectedSlot(SWORD_SLOT);
        } else if (crystalStage == 1) {                // sword hit landed: run the crystals
            releaseKeys(client);
            crystalCycle(client, player, target);
            return;
        }
        if (crystalCooldown > 0) crystalCooldown--;

        boolean onGround = player.isOnGround();
        boolean falling = !onGround && player.getVelocity().y < -0.06;
        float charge = player.getAttackCooldownProgress(0.0F);

        if (dist <= 5.0) ticksSinceHit++; else ticksSinceHit = 0;

        // Far away: pearl onto the target instead of walking over.
        if (!pearlPending) tryStartPearl(world, player, target, dist);

        // Blocks around (or no way to land the sword hit): skip the sword, just spam crystals.
        if (mode == 2 && crystalStage == 0 && spamBlock == 0 && dist <= SPAM_RANGE
                && crystalSafe(player) && hasCrystals(player)) {
            boolean crowded = isCrowded(world, player, target);
            if (crowded || ticksSinceHit > STUCK_TICKS) {
                startSpam(crowded);
                setKeys(client, false, false, false, strafeDir);
                crystalCycle(client, player, target);
                return;
            }
        }

        boolean forward = true;
        boolean sprint = true;
        boolean jump = false;

        if (wTapTicks > 0) {                          // W-tap: let go of forward to reset sprint
            wTapTicks--;
            forward = false;
            sprint = false;
            if ((mode == 1 || mode == 3) && skill > 0.55f && dist < 2.6) wantBack = true;   // S-tap: step back too when we are tight on the target
        }

        boolean aimedInReach = canHit(player, target);
        boolean quick = rush > 0;                     // just pearled in: don't wait for the sword to charge
        boolean ready = charge >= hitCharge() || quick;

        // UHC: raise our own shield (off-hand) while the sword recharges and the target is in reach.
        // It drops the moment the sword is ready so the sprint hit goes out at full speed. Axes disable
        // shields, so it does not bother against an axe.
        shieldUp = false;
        if (mode == 3 && skill > 0.4f && !quick && !ready && dist <= 3.9 && !eating && !drawing
                && player.getOffHandStack().isOf(Items.SHIELD)
                && !player.getItemCooldownManager().isCoolingDown(player.getOffHandStack())
                && !target.getMainHandStack().isIn(ItemTags.AXES)) {
            shieldUp = true;
            forward = false;                           // you cannot sprint while blocking
            sprint = false;
        }
        if (mode == 3) client.options.useKey.setPressed(shieldUp);

        // Skilled: bunny-hop while closing in to keep sprint speed, and back off a step while the sword
        // recharges so you cannot get the first hit in.
        if (hopCd > 0) hopCd--;
        if (mode == 2 && skill > 0.55f && dist > CLOSE_DIST + 0.6 && onGround && hopCd == 0 && wTapTicks == 0) {   // sword mode never hops
            jump = true;
            hopCd = 6 + RND.nextInt(4);
        }
        if (spaceDist() > 0f && !ready && dist < spaceDist() && wTapTicks == 0 && rush == 0) {
            wantBack = true;
            forward = false;
            sprint = false;
        }

        if (dist <= CLOSE_DIST) {
            if (critNext) {
                // Optional crit mode: jump early, release W while falling, hit on the way down.
                if (onGround && charge >= JUMP_CHARGE && dist <= JUMP_DIST && wTapTicks == 0) {
                    jump = true;
                }
                if (ready && aimedInReach) critWait++;
                if (falling) {
                    forward = false;
                    sprint = false;
                }
            }

            // Shield up? Swap to the axe and hit at once (the sword comes back next tick).
            if (shieldCooldown > 0) shieldCooldown--;
            boolean blocking = target.isBlocking();

            // Sprint-hit combo: 1) hold W (sprinting)  2) hit  3) release W, then press it again.
            if (reaction > 0 && !quick) {
                reaction--;
            } else if (blocking && aimedInReach && shieldCooldown == 0) {
                player.getInventory().setSelectedSlot(mode == 3 ? uhcAxe : AXE_SLOT);
                client.interactionManager.attackEntity(player, target);
                lastHitNo = tickNo;
                player.swingHand(Hand.MAIN_HAND);
                shieldCooldown = SHIELD_BREAK_COOLDOWN;
                wTapTicks = wtapTicks();
                reaction = RND.nextInt(maxReaction() + 1);
            } else if (ready && aimedInReach && !blocking
                    && (!critNext || (falling && !player.isSprinting()) || critWait > 14)) {
                client.interactionManager.attackEntity(player, target);
                lastHitNo = tickNo;
                player.swingHand(Hand.MAIN_HAND);
                wTapTicks = wtapTicks();                   // release W so the sprint resets
                reaction = quick ? 0 : RND.nextInt(maxReaction() + 1);
                ticksSinceHit = 0;
                rush = 0;
                critNext = false;                            // no jump crits
                critWait = 0;

                // Crystal mode: right after the sword hit, obsidian + crystal + pop + crystal + pop, same tick onward.
                if (mode == 2 && (crystalCooldown == 0 || quick) && crystalSafe(player) && hasCrystals(player)) {
                    startCrystal();
                    crystalCycle(client, player, target);
                }
            }
        }

        if (DEBUG && infoHold == 0 && --debugTicks <= 0) {
            debugTicks = 10;
            player.sendMessage(Text.literal(String.format(Locale.ROOT,
                    "d=%.1f charge=%.2f %s%s%s aim=%s st=%d rush=%d pearl=%s skill=%.2f %s act=%s sh=%s off=%s",
                    dist, charge, onGround ? "G" : "-", falling ? "F" : "-",
                    player.isSprinting() ? "S" : "-", aimedInReach ? "Y" : "N",
                    crystalStage, rush, pearlPending ? "Y" : "N", skill, DIFF_NAMES[difficulty],
                    mode == 3 ? uhcAction : "-", shieldUp ? "UP" : "-",
                    player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING) ? "TOT"
                            : player.getOffHandStack().isOf(Items.SHIELD) ? "SHD" : "-")), true);
        }

        if (mode == 1 || mode == 3) jump = false;      // sword / UHC melee: no jump hits, ever

        // Stuck behind a wall? (pushing forward into it with no line to the target): walk along the wall to
        // find the way around, alternating the side every attempt, and hop up 1-block steps.
        boolean noLine = !lineClear(client.world, player, target);
        if (forward && player.horizontalCollision && noLine) stuckTicks++;
        else if (stuckTicks > 0) stuckTicks--;
        if (detourTicks <= 0 && stuckTicks > 10) {
            Vec3d look = player.getRotationVec(1.0F);
            double cross = look.x * (target.getZ() - player.getZ()) - look.z * (target.getX() - player.getX());
            int towardTarget = cross < 0 ? -1 : 1;     // -1 = left, 1 = right
            detourDir = (detourFlips % 2 == 0) ? towardTarget : -towardTarget;
            detourFlips++;
            detourTicks = 30 + RND.nextInt(20);
            stuckTicks = 0;
        }
        if (detourTicks > 0) {
            detourTicks--;
            if (noLine) {
                forward = true;
                sprint = false;
                strafeDir = detourDir;
                if (player.horizontalCollision && onGround) jump = true;   // a 1-block step: hop it
            } else {
                detourTicks = 0;                       // the way is clear again
            }
        }
        setKeys(client, forward, sprint, jump, strafeDir);
    }
}
