package com.ultrakillmod;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.DeathScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.function.Predicate;

/**
 * Sparring partner (client side). Press the key to start, press again to stop.
 * It fights the closest player (or only the usernames in PARTNERS when ONLY_LISTED is true).
 * Meant for training on your own private server: it will go for anyone who is nearby.
 *
 * Up close it hits with
 * the sword and, in crystal mode, follows with obsidian + crystals in the same tick (no waiting). When
 * blocks around make the sword + crystal combo awkward, it switches to pure crystal spam: pop and
 * re-place every tick, as fast as the connection allows.
 */
public final class SparBot {
    // Only these players can be targeted (lower-case).
    // false = it fights the CLOSEST player, whoever that is (so friends can train with it too).
    // true  = it only fights the usernames in PARTNERS below.
    private static final boolean ONLY_LISTED = false;

    private static final Set<String> PARTNERS = Set.of(
            "babaykala22", "axyzet", "rico46_5556", "theobaldthebot");

    // ---- Tunables ----
    private static final int SWORD_SLOT = 4;          // hotbar slot 5 (0-based index)
    private static final int AXE_SLOT = 2;            // hotbar slot 3: swung once to break a raised shield
    private static final int SHIELD_BREAK_COOLDOWN = 25; // ticks before it will try to break a shield again
    private static final int CRYSTAL_SLOT = 5;       // hotbar slot 6: end crystals
    private static final int OBSIDIAN_SLOT = 8;      // hotbar slot 9: obsidian
    private static final int RUSH_TICKS = 30;         // after a teleport: hit instantly, perfect aim, no cooldowns
    private static final int CRYSTAL_COOLDOWN = 8;   // ticks of sword fighting between crystal combos
    private static final int COMBO_POPS = 2;          // sword hit, then place+pop this many crystals
    private static final double SPAM_RANGE = 6.5;     // crystal spam only when the target is this close
    private static final int SPAM_HOLD = 20;          // keep spamming this long after the blocks stop being a problem
    private static final int STUCK_TICKS = 30;        // near the target this long without landing a sword hit = spam
    private static final int STUCK_HOLD = 60;
    private static final int CROWDED_BLOCKS = 8;      // solid blocks around feet+head (of 16) = cramped
    private static final double POP_REACH = 4.5;
    private static final int POP_REPEAT = 3;          // don't re-hit the same crystal within this many ticks
    private static final int PLACE_RETRY = 2;         // ticks before placing again if no crystal showed up
    private static final float SAFE_HEALTH = 8.0f;   // below this (4 hearts) with no totem it skips crystals
    private static final double SEARCH_RANGE = 48.0;  // how far away it looks for a partner
    private static final double CLOSE_DIST = 3.4;     // below this it starts the fight loop
    private static final double HIT_REACH = 3.0;      // a sword hit needs the target this close (eye to hitbox)
    private static final float MAX_TURN_YAW = 35.0f;  // degrees per tick
    private static final float MAX_TURN_PITCH = 25.0f;
    private static final float AIM_NOISE_YAW = 2.5f;  // aim wobble (degrees)
    private static final float AIM_NOISE_PITCH = 1.5f;
    private static final float HIT_CHARGE = 0.90f;    // attack charge needed before swinging (90%)
    private static final float JUMP_CHARGE = 0.5f;    // starts the jump early so the crit lands at ~95%
    private static final double JUMP_DIST = 2.8;      // only jump when this close (jumping from far away overshoots)
    private static final boolean CRIT_JUMPS = false;  // true = jump and hit on the way down (no sprint hit then)
    private static final boolean DEBUG = true;        // shows a status line above the hotbar
    private static final int WTAP_TICKS = 2;          // forward released this long after a hit
    private static final int MAX_REACTION_TICKS = 2;  // random extra delay before a hit

    private static final Random RND = new Random();

    private static boolean active = false;
    private static int mode = 0;                      // 0 = off, 1 = sword, 2 = crystal, 3 = UHC
    private static int state = 0;                     // 0 off, 1 sword (I key), 2 elytra mace (H key)
    private static int crystalStage = 0;              // 0 = none, 1 = sword+crystal combo, 2 = crystal spam
    private static int crystalCooldown = 0;
    private static int stageTicks = 0;
    private static int obsidianTries = 0;
    private static int pops = 0;
    private static int placeCd = 0;
    private static int noBaseTicks = 0;
    private static int spamHold = 0;
    private static int spamBlock = 0;
    private static int ticksSinceHit = 0;
    private static int tickNo = 0;
    private static int rush = 0;
    private static Vec3d lastBotPos = null;
    private static Vec3d lastTargetPos = null;
    private static int lastTargetId = -1;
    private static Vec3d targetVel = Vec3d.ZERO;
    private static final Map<Integer, Integer> recentPops = new HashMap<>();
    private static int totemCooldown = 0;
    private static int totemWarn = 0;
    private static int wTapTicks = 0;
    private static int strafeTicks = 0;
    private static int strafeDir = 0;
    private static int reaction = 0;
    private static int noiseTicks = 0;
    private static float noiseYaw = 0f;
    private static float noisePitch = 0f;
    private static int noticeCooldown = 0;
    private static int debugTicks = 0;
    private static int shieldCooldown = 0;

    // ---- difficulty: 0 = adaptive (follows how you are doing), 1 easy, 2 normal, 3 hard, 4 insane ----
    private static final float SKILL_MIN = 0.25f;
    private static final float SKILL_MAX = 1.0f;
    private static final float[] FIXED_SKILL = {0.65f, 0.30f, 0.55f, 0.90f, 1.00f};
    private static final String[] DIFF_NAMES = {"ADAPTIVE", "EASY", "NORMAL", "HARD", "INSANE"};
    private static int difficulty = 0;
    private static float skill = 0.65f;               // 0.25 .. 1.0, drives everything below
    private static float hitBalance = 0f;             // + when the bot is winning exchanges, - when you are
    private static int adaptTicks = 0;
    private static float lastTargetHealth = -1f;
    private static float lastBotHealth = -1f;
    private static boolean critNext = false;          // next swing is a jump crit instead of a sprint hit
    private static int critWait = 0;
    private static int hopCd = 0;
    private static boolean wantBack = false;          // S key for this tick (spacing)
    private static int infoHold = 0;                  // ticks the mode/difficulty message stays on screen
    private static PlayerEntity lastTarget = null;    // who we were fighting last tick (to notice when it dies)

    private static String modeName() {
        return state == 1 ? "SWORD" : state == 2 ? "ELYTRA MACE" : "OFF";
    }

    private static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    /** INSANE: the bot plays at a level no human reaches (instant aim, no wobble, no reaction delay). */
    private static boolean insane() { return difficulty == 4; }

    private static float turnYaw() { return insane() ? 180f : lerp(14f, 90f, skill); }   // degrees per tick
    private static float turnPitch() { return insane() ? 90f : lerp(10f, 60f, skill); }
    private static float noiseYawMax() { return insane() ? 0f : lerp(6.0f, 0.3f, skill); }   // aim wobble
    private static float noisePitchMax() { return insane() ? 0f : lerp(4.0f, 0.2f, skill); }
    private static int maxReaction() { return Math.round(lerp(5f, 0f, skill)); }   // extra ticks before a swing
    private static float hitCharge() { return insane() ? 0.90f : lerp(1.0f, 0.90f, skill); }   // never swings below 90%
    private static float leadTicks() { return insane() ? 3.0f : lerp(0f, 2.5f, skill); }   // aims ahead of a moving target
    private static float critChance() { return 0f; }                         // crits are off: sprint hits only
    private static int wtapTicks() { return insane() ? 1 : WTAP_TICKS; }     // INSANE resets its sprint a tick faster
    private static float spaceDist() {                                       // backs off while recharging when closer than this
        if (insane()) return 3.1f;
        return skill > 0.5f ? lerp(2.2f, 2.8f, (skill - 0.5f) / 0.5f) : 0f;
    }

    /** Cycles ADAPTIVE -> EASY -> NORMAL -> HARD -> INSANE. */
    public static void cycleDifficulty(MinecraftClient client) {
        difficulty = (difficulty + 1) % DIFF_NAMES.length;
        skill = FIXED_SKILL[difficulty];
        hitBalance = 0f;
        if (client.player != null) {
            infoHold = 30;
            client.player.sendMessage(Text.literal("Spar bot: " + modeName() + " mode, difficulty "
                    + DIFF_NAMES[difficulty] + (difficulty == 0 ? " (adjusts to you)" : "")), true);
        }
    }

    /** Watches health on both sides: counts hits, and in ADAPTIVE mode turns the skill up when you are winning. */
    private static void trackResults(ClientPlayerEntity player, PlayerEntity target) {
        float th = target.getHealth();
        float bh = player.getHealth();
        if (lastTargetHealth >= 0f && th < lastTargetHealth - 0.01f) {
            hitBalance += 1f;                                  // the bot landed a hit
        }
        if (lastBotHealth >= 0f && bh < lastBotHealth - 0.01f && crystalStage == 0) {
            hitBalance -= 1f;                                  // you landed a hit
            strafeTicks = 0;                                   // react: change direction right away
            if (skill > 0.5f && player.isOnGround()) hopCd = 0;
        }
        lastTargetHealth = th;
        lastBotHealth = bh;

        if (difficulty == 0 && ++adaptTicks >= 40) {          // every 2 seconds
            adaptTicks = 0;
            if (hitBalance < -1.5f) skill = Math.min(SKILL_MAX, skill + 0.04f);       // you are ahead: harder
            else if (hitBalance > 3.0f) skill = Math.max(SKILL_MIN, skill - 0.02f);   // bot is far ahead: ease off
            hitBalance *= 0.7f;                                // forget old exchanges
        }
    }

    // ------------------------------------------------------------------
    // Round / match end: the bot switches itself off (press I to bring the same mode back).
    // Signals: the server's title or a game message ("Match over", ...), you died, the target is dead or gone.
    // ------------------------------------------------------------------
    private static final boolean STOP_AT_ROUND_END = true;
    private static final boolean STOP_ON_ANY_TITLE = true;   // after a real fight, ANY title from the server = round over
    private static final int TITLE_FIGHT_TICKS = 100;        // ...so the "3, 2, 1, FIGHT" countdown titles are ignored
    private static final String[] END_PHRASES = {
            "match over", "round over", "game over", "you won", "you lost", "you win", "you lose",
            "victory", "defeat", "winner", "round won", "round lost", "won the round", "lost the round",
            "победа", "поражение", "раунд окончен", "матч окончен", "вы победили", "вы проиграли", "вы выиграли"
    };
    private static final String[] END_WORDS = {"win", "lose", "loss", "loose", "won", "lost", "draw", "tie"};
    private static int ownDeadTicks = 0, targetDeadTicks = 0, lastHitNo = -1000;
    private static int stuckTicks = 0, detourTicks = 0, detourDir = 1, detourFlips = 0;   // walking around walls
    private static volatile boolean roundOverFlag = false;
    private static volatile String roundOverWhy = "";
    private static int fightTicks = 0, noTargetTicks = 0, resumeState = 0;

    /** Called by the title hook (title = true) and the game-message hook. Only sets a flag; the tick does the work. */
    public static void onServerText(Text text, boolean title) {
        if (!active || !STOP_AT_ROUND_END || text == null) return;
        String s = text.getString().trim().toLowerCase(Locale.ROOT);
        if (s.isEmpty()) return;
        String plain = s.replaceAll("[^\\p{L}]", "");              // "WIN!" -> "win"
        if (s.contains("totem") || s.contains("popped")) return;       // a totem pop is not a round end
        for (String word : END_WORDS) {
            if (plain.equals(word)) {                         // a message / title that is just "Win", "Lose", ...
                roundOverWhy = "\"" + word + "\"";
                roundOverFlag = true;
                return;
            }
        }
        for (String phrase : END_PHRASES) {
            if (s.contains(phrase)) {
                roundOverWhy = "\"" + phrase + "\"";
                roundOverFlag = true;
                return;
            }
        }
        if (title && STOP_ON_ANY_TITLE && fightTicks >= TITLE_FIGHT_TICKS) {
            roundOverWhy = "server title";
            roundOverFlag = true;
        }
    }

    private static void stopBot(MinecraftClient client, ClientPlayerEntity player, String why) {
        int was = state;
        reset(client);
        resumeState = was;
        infoHold = 40;
        if (player != null) {
            player.sendMessage(Text.literal("Spar bot: " + why + ", OFF (press I to start again)"), true);
        }
    }

    private SparBot() {}

    public static boolean isActive() {
        return active;
    }

    /** I cycles: sword mode -> spear mace mode -> off. */
    /** I key: sword mode on / off. */
    public static void toggle(MinecraftClient client) {
        setState(client, state == 1 ? 0 : 1);
    }

    /** H key: elytra mace mode on / off. */
    public static void toggleElytra(MinecraftClient client) {
        setState(client, state == 2 ? 0 : 2);
    }

    private static void setState(MinecraftClient client, int newState) {
        if (client.player == null) return;
        state = newState;
        resumeState = 0;
        mode = state;
        lastTarget = null;
        active = state != 0;
        if (active) {
            wTapTicks = 0;
            strafeTicks = 0;
            reaction = 0;
            shieldCooldown = 0;
            totemCooldown = 0;
            resetFight();
            elyStage = 1;
            elyTicks = 0;
            elyJumped = false;
            elyWant = ELY_HEIGHT_MIN + RND.nextDouble() * (ELY_HEIGHT_MAX - ELY_HEIGHT_MIN);
            elyEquipWait = 0;
            elyNotice = 0;
            elyTId = -1;
            elyTPrev = null;
            elyTVel = Vec3d.ZERO;
            if (state == 1) client.player.getInventory().setSelectedSlot(SWORD_SLOT);
            infoHold = 30;                             // keep this message up for ~1.5 s before the PvP info
            if (state == 1) {
                client.player.sendMessage(Text.literal("Spar bot: SWORD mode, difficulty "
                        + DIFF_NAMES[difficulty] + " (I = off, J = difficulty)"), true);
            } else {
                client.player.sendMessage(Text.literal("Elytra mace bot ON (H = off)"), true);
            }
        } else {
            releaseKeys(client);
            infoHold = 30;
            client.player.sendMessage(Text.literal("Spar bot OFF"), true);
        }
    }

    public static void reset(MinecraftClient client) {
        active = false;
        mode = 0;
        state = 0;
        resumeState = 0;
        lastTarget = null;
        crystalStage = 0;
        resetFight();
        if (client != null && client.options != null) releaseKeys(client);
    }

    private static void resetFight() {
        elyFetchCd = 0;
        lastHitNo = -1000;
        ownDeadTicks = 0;
        targetDeadTicks = 0;
        fightTicks = 0;
        noTargetTicks = 0;
        rush = 0;
        spamHold = 0;
        spamBlock = 0;
        ticksSinceHit = 0;
        noBaseTicks = 0;
        placeCd = 0;
        lastBotPos = null;
        lastTargetPos = null;
        lastTargetId = -1;
        targetVel = Vec3d.ZERO;
        recentPops.clear();
        lastTargetHealth = -1f;
        lastBotHealth = -1f;
        hitBalance = 0f;
        adaptTicks = 0;
        critNext = false;
        critWait = 0;
        hopCd = 0;
    }

    private static void releaseKeys(MinecraftClient client) {
        client.options.forwardKey.setPressed(false);
        client.options.sprintKey.setPressed(false);
        client.options.leftKey.setPressed(false);
        client.options.rightKey.setPressed(false);
        client.options.jumpKey.setPressed(false);
        client.options.backKey.setPressed(false);
        client.options.useKey.setPressed(false);
    }

    private static PlayerEntity findPartner(MinecraftClient client, ClientPlayerEntity self) {
        PlayerEntity best = null;
        double range = mode == 2 ? 150.0 : SEARCH_RANGE;   // elytra mace sees 150 blocks
        double bestDist = range * range;
        for (PlayerEntity other : client.world.getPlayers()) {
            if (other == self || !other.isAlive() || other.isSpectator()) continue;
            String name = other.getName().getString().toLowerCase(Locale.ROOT);
            if (ONLY_LISTED && !PARTNERS.contains(name)) continue;
            double d = self.squaredDistanceTo(other);
            if (d < bestDist) {
                bestDist = d;
                best = other;
            }
        }
        return best;
    }

    /** True if the line of sight reaches the target's hitbox within sword reach (a little forgiving). */
    private static boolean canHit(ClientPlayerEntity player, Entity target) {
        Vec3d eye = player.getEyePos();
        Vec3d dir = player.getRotationVec(1.0F);
        Vec3d end = eye.add(dir.multiply(HIT_REACH));
        Box box = target.getBoundingBox().expand(0.12);
        return box.contains(eye) || box.raycast(eye, end).isPresent();
    }

    private static final float AIM_BODY = 0.40f;     // fraction of the target's height: 0.40 = chest / belly
    private static final float AIM_HEAD = 0.92f;     // 0.92 = head
    private static float aimHeight = 0.65f, aimHeightWant = 0.65f;

    private static void aim(ClientPlayerEntity player, Entity target, boolean snap) {
        if (--noiseTicks <= 0) {
            noiseTicks = 6 + RND.nextInt(8);
            noiseYaw = (RND.nextFloat() * 2f - 1f) * noiseYawMax();
            noisePitch = (RND.nextFloat() * 2f - 1f) * noisePitchMax();
            aimHeightWant = AIM_BODY + RND.nextFloat() * (AIM_HEAD - AIM_BODY);   // somewhere from body to head
        }
        aimHeight += (aimHeightWant - aimHeight) * 0.35f;      // slide there, do not jump
        Vec3d eye = player.getEyePos();
        double dx = target.getX() + targetVel.x * leadTicks() - eye.x;
        double dy = (target.getY() + target.getHeight() * aimHeight) - eye.y;
        double dz = target.getZ() + targetVel.z * leadTicks() - eye.z;
        double horizontal = Math.sqrt(dx * dx + dz * dz);

        float nYaw = snap ? 0f : noiseYaw;
        float nPitch = snap ? 0f : noisePitch;
        float wantYaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0f + nYaw;
        float wantPitch = (float) -Math.toDegrees(Math.atan2(dy, horizontal)) + nPitch;

        if (snap) {                                    // look at the target instantly
            player.setYaw(wantYaw);
            player.setPitch(MathHelper.clamp(wantPitch, -90.0f, 90.0f));
            return;
        }
        float dYaw = MathHelper.clamp(MathHelper.wrapDegrees(wantYaw - player.getYaw()), -turnYaw(), turnYaw());
        float dPitch = MathHelper.clamp(wantPitch - player.getPitch(), -turnPitch(), turnPitch());
        player.setYaw(player.getYaw() + dYaw);
        player.setPitch(MathHelper.clamp(player.getPitch() + dPitch, -90.0f, 90.0f));
    }

    private static void trackMotion(ClientPlayerEntity player, PlayerEntity target) {
        if (rush > 0) rush--;
        if (spamBlock > 0) spamBlock--;
        Vec3d pos = new Vec3d(player.getX(), player.getY(), player.getZ());
        if (lastBotPos != null && pos.distanceTo(lastBotPos) > 4.0) rush = RUSH_TICKS;   // we just teleported
        lastBotPos = pos;
        Vec3d tp = new Vec3d(target.getX(), target.getY(), target.getZ());
        if (lastTargetPos != null && lastTargetId == target.getId()) {
            Vec3d v = tp.subtract(lastTargetPos);
            targetVel = new Vec3d(MathHelper.clamp(v.x, -0.5, 0.5), 0.0, MathHelper.clamp(v.z, -0.5, 0.5));
        } else {
            targetVel = Vec3d.ZERO;
        }
        lastTargetPos = tp;
        lastTargetId = target.getId();
    }

    // ------------------------------------------------------------------
    // Terrain checks
    // ------------------------------------------------------------------

    /** True if nothing solid is between our eyes and the target. */
    private static boolean lineClear(ClientWorld world, ClientPlayerEntity player, Entity target) {
        Vec3d from = player.getEyePos();
        Vec3d to = target.getBoundingBox().getCenter();
        HitResult hit = world.raycast(new RaycastContext(from, to,
                RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, player));
        return hit.getType() == HitResult.Type.MISS;
    }

    /** Solid blocks in the 8 columns around a position, at feet and head height (max 16). */
    private static int solidAround(ClientWorld world, BlockPos pos) {
        int n = 0;
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                if (dx == 0 && dz == 0) continue;
                for (int dy = 0; dy <= 1; dy++) {
                    BlockPos p = pos.add(dx, dy, dz);
                    if (!world.getBlockState(p).getCollisionShape(world, p).isEmpty()) n++;
                }
            }
        }
        return n;
    }

    /** Blocks make the sword hit + crystal combo awkward: walls in the way, or either of us boxed in. */
    private static boolean isCrowded(ClientWorld world, ClientPlayerEntity player, Entity target) {
        return !lineClear(world, player, target)
                || solidAround(world, target.getBlockPos()) >= CROWDED_BLOCKS
                || solidAround(world, player.getBlockPos()) >= CROWDED_BLOCKS;
    }

    // ------------------------------------------------------------------
    // Auto totem
    // ------------------------------------------------------------------

    /** Keeps a totem in the off-hand: after a pop, the next one is moved there within a few ticks. */
    private static void ensureTotem(MinecraftClient client, ClientPlayerEntity player) {
        if (totemCooldown > 0) {
            totemCooldown--;
            return;
        }
        if (player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;
        for (int i = 0; i < 36; i++) {
            if (player.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) {
                int slotId = i < 9 ? 36 + i : i;     // hotbar slots are 36-44 in the inventory screen
                client.interactionManager.clickSlot(
                        player.playerScreenHandler.syncId, slotId, 40, SlotActionType.SWAP, player);
                totemCooldown = 1;
                return;
            }
        }
        if (--totemWarn <= 0) {
            if (infoHold == 0) player.sendMessage(Text.literal("Spar bot: out of totems"), true);
            totemWarn = 100;
        }
    }

    private static int findInventory(ClientPlayerEntity player, net.minecraft.item.Item item) {
        for (int i = 0; i < 36; i++) {
            if (player.getInventory().getStack(i).isOf(item)) return i;
        }
        return -1;
    }

    private static void setKeys(MinecraftClient client, boolean forward, boolean sprint, boolean jump, int strafe) {
        client.options.forwardKey.setPressed(forward);
        client.options.sprintKey.setPressed(sprint);
        client.options.jumpKey.setPressed(jump);
        client.options.leftKey.setPressed(strafe < 0);
        client.options.rightKey.setPressed(strafe > 0);
        client.options.backKey.setPressed(wantBack);
        wantBack = false;
    }

    /** Right-click the top face of a block. */
    private static void clickTop(MinecraftClient client, ClientPlayerEntity player, BlockPos block) {
        Vec3d hit = new Vec3d(block.getX() + 0.5, block.getY() + 1.0, block.getZ() + 0.5);
        client.interactionManager.interactBlock(player, Hand.MAIN_HAND,
                new BlockHitResult(hit, Direction.UP, block, false));
        player.swingHand(Hand.MAIN_HAND);
    }

    private static void select(ClientPlayerEntity player, int slot) {
        if (slot >= 0) player.getInventory().setSelectedSlot(slot);
    }

    private static void lookAt(ClientPlayerEntity player, Vec3d p) {
        Vec3d eye = player.getEyePos();
        double dx = p.x - eye.x, dy = p.y - eye.y, dz = p.z - eye.z;
        player.setYaw((float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0f);
        player.setPitch((float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz))));
    }

    private static int findHotbar(ClientPlayerEntity player, Predicate<ItemStack> test) {
        for (int i = 0; i < 9; i++) {
            if (test.test(player.getInventory().getStack(i))) return i;
        }
        return -1;
    }

    private static boolean solid(ClientWorld world, BlockPos p) {
        return !world.getBlockState(p).getCollisionShape(world, p).isEmpty();
    }

    private static Vec3d faceCenter(BlockPos support, Direction face) {
        return Vec3d.ofCenter(support).add(face.getOffsetX() * 0.5, face.getOffsetY() * 0.5, face.getOffsetZ() * 0.5);
    }

    private static Direction dirToward(double dx, double dz) {
        return Math.abs(dx) > Math.abs(dz)
                ? (dx > 0 ? Direction.EAST : Direction.WEST)
                : (dz > 0 ? Direction.SOUTH : Direction.NORTH);
    }

    // ------------------------------------------------------------------
    // ELYTRA MACE mode (mode 2, key H). No ground fight in this mode: takeoff, aim, strike, again.
    //   elytra on -> jump + open it -> rockets up (only as high as the target needs: 16-20 blocks above it, so it
    //   flies high only when the enemy is high) -> aim with prediction (flying targets too) -> when close:
    //   chestplate on (elytra off), spear slot -> axe -> hit, then spear slot -> mace -> hit (the O key stun slam)
    //   -> elytra back on, a little up, and again. No cooldown between strikes. Targets up to 150 blocks away.
    // Hotbar: 1 rockets, 2 spear, 3 axe, 4 elytra (the chestplate after the swap), 5 sword, 6 shield,
    //         7 golden apples, 8 mace, 9 pearls. Rockets, spear, axe and mace are refilled from the inventory.
    // ------------------------------------------------------------------
    private static final int E_ROCKET = 0;              // hotbar slot 1
    private static final int E_SPEAR = 1;               // hotbar slot 2 (the swap slot, like the O key)
    private static final int E_AXE = 2;                 // hotbar slot 3
    private static final int E_ITEM = 3;                // hotbar slot 4: elytra <-> chestplate
    private static final int E_MACE = 7;                // hotbar slot 8
    private static final double ELY_HEIGHT_MIN = 16.0;  // blocks above the target to strike from: a random value
    private static final double ELY_HEIGHT_MAX = 20.0;  // between these two each run
    private static final int ELY_POST_HIT_WAIT = 2;     // ticks to do nothing after the mace hit (Wind Burst launches us)
    private static final int ELY_COMBO_GAP = 1;         // ticks between the axe hit and the mace hit

    private static int elyStage = 1, elyTicks = 0, elyRocketCd = 0, elyAir = 0, elyEquipWait = 0, elyCombo = 0;
    private static int elyGap = 0, elyFetchCd = 0, elyNotice = 0, elyTId = -1;
    private static boolean elyJumped = false;
    private static double elyWant = 18.0;
    private static double elyMinDist = 1.0e9;
    private static Vec3d elyTPrev = null, elyTVel = Vec3d.ZERO;

    /** An empty hotbar slot. */
    private static int spareHotbarSlot(ClientPlayerEntity player) {
        for (int i = 0; i < 9; i++) {
            if (player.getInventory().getStack(i).isEmpty()) return i;
        }
        return -1;
    }

    /**
     * Own hotbar: when an item is missing from the hotbar (used up), a stack from the inventory is swapped into
     * an empty hotbar slot (the preferred one if it is empty).
     */
    private static boolean refill(MinecraftClient client, ClientPlayerEntity player, Predicate<ItemStack> test, int pref) {
        if (findHotbar(player, test) >= 0) return false;
        int idx = -1;
        for (int i = 9; i < 36; i++) {
            if (test.test(player.getInventory().getStack(i))) {
                idx = i;
                break;
            }
        }
        if (idx < 0) return false;
        int target = (pref >= 0 && player.getInventory().getStack(pref).isEmpty()) ? pref : spareHotbarSlot(player);
        if (target < 0) return false;
        client.interactionManager.clickSlot(player.playerScreenHandler.syncId, idx, target, SlotActionType.SWAP, player);
        elyFetchCd = 4;
        return true;
    }

    private static void hotbarRefill(MinecraftClient client, ClientPlayerEntity player) {
        if (mode != 2) return;
        if (elyFetchCd > 0) {
            elyFetchCd--;
            return;
        }
        if (refill(client, player, st -> st.isOf(Items.FIREWORK_ROCKET), E_ROCKET)) return;
        if (refill(client, player, st -> st.isOf(Items.MACE), E_MACE)) return;
        if (refill(client, player, st -> st.isIn(ItemTags.AXES), E_AXE)) return;
        refill(client, player, st -> isSpear(st), E_SPEAR);
    }

    /** Any spear (wooden ... netherite): the item id ends with _spear. */
    private static boolean isSpear(ItemStack st) {
        return !st.isEmpty() && net.minecraft.registry.Registries.ITEM.getId(st.getItem()).getPath().endsWith("_spear");
    }

    private static boolean chestIsElytra(ClientPlayerEntity p) {
        return p.getEquippedStack(net.minecraft.entity.EquipmentSlot.CHEST).isOf(Items.ELYTRA);
    }

    private static boolean hasRockets(ClientPlayerEntity p) {
        return findHotbar(p, st -> st.isOf(Items.FIREWORK_ROCKET)) >= 0;
    }

    private static boolean elyKitOk(ClientPlayerEntity p) {
        return (chestIsElytra(p) || p.getInventory().getStack(E_ITEM).isOf(Items.ELYTRA))
                && p.getInventory().getStack(E_MACE).isOf(Items.MACE) && hasRockets(p);
    }

    /** Gliding shows as the low (0.6 blocks tall) body pose while off the ground and not in water. */
    private static boolean flyingElytra(ClientPlayerEntity p) {
        return !p.isOnGround() && p.getHeight() < 1.0f && !p.isTouchingWater();
    }

    /** Right-click the item in slot 4: puts the elytra on, or (after that) the chestplate back on. */
    private static void swapChest(MinecraftClient client, ClientPlayerEntity player) {
        player.getInventory().setSelectedSlot(E_ITEM);
        client.interactionManager.interactItem(player, Hand.MAIN_HAND);
    }

    private static void useRocket(MinecraftClient client, ClientPlayerEntity player) {
        int slot = findHotbar(player, st -> st.isOf(Items.FIREWORK_ROCKET));
        if (slot < 0) return;
        player.getInventory().setSelectedSlot(slot);
        client.interactionManager.interactItem(player, Hand.MAIN_HAND);
    }

    /** Solid roof right above us (the Nether ceiling, a cave): no point climbing into it. */
    private static boolean ceilingAbove(ClientWorld world, ClientPlayerEntity player) {
        BlockPos p = player.getBlockPos();
        for (int i = 3; i <= 10; i++) {
            if (solid(world, p.up(i))) return true;
        }
        return false;
    }

    /** Blocks of air between the feet and the first solid block / liquid below (99 = nothing close, or water). */
    private static double heightAbove(ClientWorld world, ClientPlayerEntity player) {
        int bx = MathHelper.floor(player.getX());
        int bz = MathHelper.floor(player.getZ());
        int y0 = MathHelper.floor(player.getY() - 0.001);
        for (int d = 0; d <= 12; d++) {
            BlockPos p = new BlockPos(bx, y0 - d, bz);
            net.minecraft.block.BlockState st = world.getBlockState(p);
            if (!st.getFluidState().isEmpty()) return 99.0;
            if (!st.getCollisionShape(world, p).isEmpty()) return player.getY() - (p.getY() + 1.0);
        }
        return 99.0;
    }

    /** Once per tick: the target's velocity (smoothed). */
    private static void elyTrack(PlayerEntity target) {
        if (elyTId != target.getId()) {
            elyTId = target.getId();
            elyTPrev = null;
            elyTVel = Vec3d.ZERO;
        }
        Vec3d pos = new Vec3d(target.getX(), target.getY() + target.getHeight() * 0.5, target.getZ());
        if (elyTPrev != null) {
            Vec3d raw = pos.subtract(elyTPrev);                        // blocks per tick
            if (raw.lengthSquared() > 36.0) raw = Vec3d.ZERO;          // it teleported
            elyTVel = elyTVel.multiply(0.5).add(raw.multiply(0.5));
        }
        elyTPrev = pos;
    }

    /** Aims at where the target will be when we get there (works on a target that is flying too). */
    private static void elyAim(ClientPlayerEntity player, PlayerEntity target) {
        Vec3d pos = new Vec3d(target.getX(), target.getY() + target.getHeight() * 0.5, target.getZ());
        Vec3d eye = player.getEyePos();
        double d = eye.distanceTo(pos);
        double speed = Math.max(0.9, player.getVelocity().length());
        double ticksAway = Math.min(25.0, d / speed);
        Vec3d aimPoint = pos.add(elyTVel.multiply(ticksAway));
        double dx = aimPoint.x - eye.x;
        double dy = aimPoint.y - eye.y;
        double dz = aimPoint.z - eye.z;
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        player.setYaw((float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0f);
        player.setPitch(MathHelper.clamp((float) -Math.toDegrees(Math.atan2(dy, horizontal)), -90.0f, 90.0f));
    }

    /** Forgiving: we are moving fast, so the window for a hit is only a tick or two. */
    private static boolean elyCanHit(ClientPlayerEntity player, Entity target) {
        Vec3d eye = player.getEyePos();
        Vec3d end = eye.add(player.getRotationVec(1.0F).multiply(3.4));
        Box box = target.getBoundingBox().expand(0.35);
        return box.contains(eye) || box.raycast(eye, end).isPresent();
    }

    /** One hit exactly like the O key: spear slot, then the weapon slot, then attack, all in the same tick. */
    private static void elyStrike(MinecraftClient client, ClientPlayerEntity player, int slot, Entity target) {
        player.networkHandler.sendPacket(new net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket(E_SPEAR));
        player.networkHandler.sendPacket(new net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket(slot));
        player.getInventory().setSelectedSlot(slot);
        client.interactionManager.attackEntity(player, target);
        player.swingHand(Hand.MAIN_HAND);
        lastHitNo = tickNo;
    }

    /** Returns true: in this mode the elytra logic always owns the controls. */
    private static boolean elytraAct(MinecraftClient client, ClientWorld world, ClientPlayerEntity player,
                                     PlayerEntity target) {
        if (elyRocketCd > 0) elyRocketCd--;
        elyTrack(target);
        boolean onGround = player.isOnGround();
        double dist = player.distanceTo(target);

        if (!elyKitOk(player)) {                           // nothing to fly with: say what is missing, do nothing
            setKeys(client, false, false, false, 0);
            if (--elyNotice <= 0) {
                player.sendMessage(Text.literal("Elytra mace needs: elytra (slot 4 or worn), mace (slot 8), fireworks"), true);
                elyNotice = 60;
            }
            return true;
        }
        elyTicks++;

        switch (elyStage) {
            case 1: {                                      // 1) elytra on, jump, press jump again in the air to open it
                elyAim(player, target);
                if (!chestIsElytra(player)) {
                    elyEquipWait++;
                    if (elyEquipWait % 4 == 1) swapChest(client, player);
                    setKeys(client, false, false, false, 0);
                    return true;
                }
                elyEquipWait = 0;
                player.getInventory().setSelectedSlot(E_ROCKET);
                boolean jump = false;
                if (onGround) {
                    if (!elyJumped) {
                        jump = true;
                        elyJumped = true;
                        elyAir = 0;
                    } else if (elyTicks > 40) {            // the jump did not take: try again
                        elyJumped = false;
                        elyTicks = 0;
                    }
                } else {
                    elyAir++;
                    if (flyingElytra(player)) {
                        elyStage = 2;
                        elyTicks = 0;
                    } else if (elyAir >= 5 && elyAir % 3 == 2) {
                        jump = true;                       // a fresh jump press in the air opens the elytra
                    }
                }
                setKeys(client, false, false, jump, 0);
                return true;
            }
            case 2: {                                      // 2) rockets up to 16-20 blocks above the target (no other cap)
                if (onGround) {
                    elyStage = 1;
                    elyTicks = 0;
                    elyJumped = false;
                    return true;
                }
                if (!flyingElytra(player) && elyTicks > 15) {   // lost the glide: get it back
                    elyStage = 7;
                    elyTicks = 0;
                    elyEquipWait = 0;
                    elyAir = 0;
                    return true;
                }
                boolean rockets = hasRockets(player);
                double height = player.getY() - target.getY();
                if (height >= elyWant || ceilingAbove(world, player) || !rockets) {
                    elyStage = 3;
                    elyTicks = 0;
                    elyMinDist = 1.0e9;
                    return true;
                }
                elyAim(player, target);
                double horiz = Math.hypot(target.getX() - player.getX(), target.getZ() - player.getZ());
                // steeper the closer we are, so the climb ends above the target and not far past it
                player.setPitch(horiz > 40.0 ? -45.0f : horiz > 15.0 ? -62.0f : -80.0f);
                if (elyRocketCd == 0 && flyingElytra(player)) {
                    useRocket(client, player);
                    elyRocketCd = 16;
                }
                setKeys(client, false, false, false, 0);
                return true;
            }
            case 3: {                                      // 3) dive / intercept (a flying target too)
                if (onGround) {
                    elyStage = 1;
                    elyTicks = 0;
                    elyJumped = false;
                    return true;
                }
                elyAim(player, target);
                elyMinDist = Math.min(elyMinDist, dist);
                boolean rockets = hasRockets(player);
                // the target climbed above us: get above it again before diving
                if (player.getY() < target.getY() - 3.0 && rockets && flyingElytra(player)) {
                    elyStage = 2;
                    elyTicks = 0;
                    return true;
                }
                // far from a target that is running or flying away: boost to catch up
                boolean chase = dist > 22.0 || (dist > 12.0 && elyTVel.length() > 0.8);
                if (rockets && elyRocketCd == 0 && chase && player.getVelocity().length() < 1.3 && flyingElytra(player)) {
                    useRocket(client, player);
                    elyRocketCd = 14;
                }
                if (elyCanHit(player, target) && player.getVelocity().y < 0.2) {
                    elyStage = 5;
                    elyCombo = 0;
                    elyTicks = 0;
                    return elyComboStep(client, player, target);
                }
                // flew past it without a hit: climb and go again
                if (elyTicks > 25 && dist > elyMinDist + 12.0 && rockets && flyingElytra(player)) {
                    elyStage = 2;
                    elyTicks = 0;
                    return true;
                }
                if (!flyingElytra(player) && elyTicks > 20) {   // the glide stopped (we were hit?): recover
                    elyStage = 7;
                    elyTicks = 0;
                    elyEquipWait = 0;
                    elyAir = 0;
                    return true;
                }
                setKeys(client, false, false, false, 0);
                return true;
            }
            case 5:
                return elyComboStep(client, player, target);
            default: {                                     // 7) after the strike: elytra back on, open it, a little up, again
                if (elyTicks <= ELY_POST_HIT_WAIT) {       // first a moment of nothing: the mace's Wind Burst throws us up
                    elyAim(player, target);
                    setKeys(client, false, false, false, 0);
                    return true;
                }
                if (onGround || heightAbove(world, player) <= 3.0) {
                    elyStage = 1;                          // close to the ground: take off again from here
                    elyTicks = 0;
                    elyJumped = false;
                    elyEquipWait = 0;
                    return true;
                }
                elyAim(player, target);
                if (!chestIsElytra(player)) {
                    elyEquipWait++;
                    if (elyEquipWait % 3 == 1) swapChest(client, player);
                    setKeys(client, false, false, false, 0);
                    return true;
                }
                if (flyingElytra(player)) {
                    elyStage = 2;                          // a little up, then dive again
                    elyTicks = 0;
                    elyMinDist = 1.0e9;
                    return true;
                }
                elyAir++;
                boolean jump = elyAir % 3 == 1;            // a fresh jump press in the air opens the elytra
                if (elyTicks > 80) {
                    elyStage = 1;
                    elyTicks = 0;
                    elyJumped = false;
                }
                setKeys(client, false, false, jump, 0);
                return true;
            }
        }
    }

    /**
     * The O key stun slam, in the air: tick 1 = chestplate on (elytra off) + spear slot -> axe -> hit,
     * tick 2 = spear slot -> mace -> hit. Then stage 7 gets the elytra back on and goes again.
     */
    private static boolean elyComboStep(MinecraftClient client, ClientPlayerEntity player, PlayerEntity target) {
        elyAim(player, target);
        if (elyCombo == 0) {
            if (chestIsElytra(player)) swapChest(client, player);                // elytra off
            elyStrike(client, player, E_AXE, target);                           // spear slot -> axe -> hit
            elyCombo = 1;
            elyGap = ELY_COMBO_GAP;
        } else if (--elyGap <= 0) {
            elyStrike(client, player, E_MACE, target);                          // spear slot -> mace -> hit
            elyCombo = 2;
            elyStage = 7;
            elyWant = ELY_HEIGHT_MIN + RND.nextDouble() * (ELY_HEIGHT_MAX - ELY_HEIGHT_MIN);
            elyTicks = 0;
            elyEquipWait = 0;
            elyAir = 0;
        }
        setKeys(client, false, false, false, 0);
        return true;
    }

    public static void tick(MinecraftClient client) {
        if (infoHold > 0) infoHold--;
        if (!active) return;
        ClientPlayerEntity player = client.player;
        if (player == null || client.world == null || client.interactionManager == null) {
            reset(client);
            return;
        }
        // Round over (title / message from the server) or you died: stop at once, mid-swing.
        if (roundOverFlag) {
            roundOverFlag = false;
            stopBot(client, player, "round over (" + roundOverWhy + ")");
            return;
        }
        if (STOP_AT_ROUND_END) {
            boolean dead = player.isDead() || player.getHealth() <= 0.0f;
            ownDeadTicks = dead ? ownDeadTicks + 1 : 0;                  // a totem pop is gone within a tick
            if (ownDeadTicks > 3 || client.currentScreen instanceof DeathScreen) {
                stopBot(client, player, "you died");
                return;
            }
        }

        if (client.currentScreen != null) {      // menus / chat open: pause
            releaseKeys(client);
            return;
        }

        // The target is dead or gone.
        if (STOP_AT_ROUND_END && lastTarget != null) {
            boolean down = lastTarget.isDead() || lastTarget.getHealth() <= 0.0f;
            targetDeadTicks = down ? targetDeadTicks + 1 : 0;            // their totem pop does not count
            if (targetDeadTicks > 10 || lastTarget.isRemoved()) {
                stopBot(client, player, "target down");
                return;
            }
        }

        PlayerEntity target = findPartner(client, player);
        if (target == null) {
            releaseKeys(client);
            if (STOP_AT_ROUND_END && lastTarget != null && ++noTargetTicks > 60) {   // it left / was teleported away
                stopBot(client, player, "target gone");
                return;
            }
            if (--noticeCooldown <= 0) {
                if (infoHold == 0) player.sendMessage(Text.literal("Spar bot: no partner nearby"), true);
                noticeCooldown = 40;
            }
            return;
        }
        noTargetTicks = 0;
        lastTarget = target;
        if (player.distanceTo(target) < 12.0f) fightTicks++;
        ClientWorld world = client.world;
        tickNo++;
        trackMotion(player, target);
        trackResults(player, target);

        hotbarRefill(client, player);                  // elytra mode: rockets / mace / axe / spear from the inventory
        ensureTotem(client, player);                   // auto totem: a new one into the off-hand right after every pop
        if (mode == 2) {                               // ELYTRA MACE: takeoff, aim, strike. No ground fight here.
            elytraAct(client, world, player, target);
            return;
        }

        int swordSlot = SWORD_SLOT;
        if (player.getInventory().getSelectedSlot() != swordSlot) {
            player.getInventory().setSelectedSlot(swordSlot);
        }

        aim(player, target, rush > 0 || insane());

        if (--strafeTicks <= 0) {
            if (skill > 0.55f) {                      // skilled: always moving, flips direction often
                strafeDir = RND.nextBoolean() ? 1 : -1;
                strafeTicks = insane() ? 2 + RND.nextInt(3) : Math.round(lerp(14f, 4f, skill)) + RND.nextInt(6);
            } else {
                strafeDir = RND.nextInt(3) - 1;       // -1 left, 0 none, 1 right
                strafeTicks = 10 + RND.nextInt(20);
            }
        }

        double dist = player.distanceTo(target);


        boolean onGround = player.isOnGround();
        boolean falling = !onGround && player.getVelocity().y < -0.06;
        float charge = player.getAttackCooldownProgress(0.0F);

        if (dist <= 5.0) ticksSinceHit++; else ticksSinceHit = 0;


        boolean forward = true;
        boolean sprint = true;
        boolean jump = false;

        if (wTapTicks > 0) {                          // W-tap: let go of forward to reset sprint
            wTapTicks--;
            forward = false;
            sprint = false;
            if (skill > 0.55f && dist < 2.6) wantBack = true;   // S-tap: step back too when we are tight on the target
        }

        boolean aimedInReach = canHit(player, target);
        boolean quick = rush > 0;                     // just teleported: don't wait for the sword to charge
        boolean ready = charge >= hitCharge() || quick;

        if (hopCd > 0) hopCd--;
        if (spaceDist() > 0f && !ready && dist < spaceDist() && wTapTicks == 0 && rush == 0) {
            wantBack = true;
            forward = false;
            sprint = false;
        }

        if (dist <= CLOSE_DIST) {
            if (critNext) {
                // Optional crit mode: jump early, release W while falling, hit on the way down.
                if (onGround && charge >= JUMP_CHARGE && dist <= JUMP_DIST && wTapTicks == 0) {
                    jump = true;
                }
                if (ready && aimedInReach) critWait++;
                if (falling) {
                    forward = false;
                    sprint = false;
                }
            }

            // Shield up? Swap to the axe and hit at once (the sword comes back next tick).
            if (shieldCooldown > 0) shieldCooldown--;
            boolean blocking = target.isBlocking();

            // Sprint-hit combo: 1) hold W (sprinting)  2) hit  3) release W, then press it again.
            if (reaction > 0 && !quick) {
                reaction--;
            } else if (blocking && aimedInReach && shieldCooldown == 0) {
                int axe = findHotbar(player, st -> st.isIn(ItemTags.AXES));
                player.getInventory().setSelectedSlot(axe >= 0 ? axe : swordSlot);   // no axe: the sword is all we have
                client.interactionManager.attackEntity(player, target);
                lastHitNo = tickNo;
                player.swingHand(Hand.MAIN_HAND);
                shieldCooldown = SHIELD_BREAK_COOLDOWN;
                wTapTicks = wtapTicks();
                reaction = RND.nextInt(maxReaction() + 1);
            } else if (ready && aimedInReach && !blocking
                    && (!critNext || (falling && !player.isSprinting()) || critWait > 14)) {
                client.interactionManager.attackEntity(player, target);
                lastHitNo = tickNo;
                player.swingHand(Hand.MAIN_HAND);
                wTapTicks = wtapTicks();                   // release W so the sprint resets
                reaction = quick ? 0 : RND.nextInt(maxReaction() + 1);
                ticksSinceHit = 0;
                rush = 0;
                critNext = false;                            // no jump crits
                critWait = 0;

            }
        }

        if (DEBUG && infoHold == 0 && --debugTicks <= 0) {
            debugTicks = 10;
            player.sendMessage(Text.literal(String.format(Locale.ROOT,
                    "d=%.1f charge=%.2f %s%s%s aim=%s ely=%d rush=%d skill=%.2f %s tot=%s",
                    dist, charge, onGround ? "G" : "-", falling ? "F" : "-",
                    player.isSprinting() ? "S" : "-", aimedInReach ? "Y" : "N",
                    elyStage, rush, skill, DIFF_NAMES[difficulty],
                    player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING) ? "Y" : "N")), true);
        }

        jump = false;                                  // no jump hits, ever

        // Stuck behind a wall? (pushing forward into it with no line to the target): walk along the wall to
        // find the way around, alternating the side every attempt, and hop up 1-block steps.
        boolean noLine = !lineClear(client.world, player, target);
        if (forward && player.horizontalCollision && noLine) stuckTicks++;
        else if (stuckTicks > 0) stuckTicks--;
        if (detourTicks <= 0 && stuckTicks > 10) {
            Vec3d look = player.getRotationVec(1.0F);
            double cross = look.x * (target.getZ() - player.getZ()) - look.z * (target.getX() - player.getX());
            int towardTarget = cross < 0 ? -1 : 1;     // -1 = left, 1 = right
            detourDir = (detourFlips % 2 == 0) ? towardTarget : -towardTarget;
            detourFlips++;
            detourTicks = 30 + RND.nextInt(20);
            stuckTicks = 0;
        }
        if (detourTicks > 0) {
            detourTicks--;
            if (noLine) {
                forward = true;
                sprint = false;
                strafeDir = detourDir;
                if (player.horizontalCollision && onGround) jump = true;   // a 1-block step: hop it
            } else {
                detourTicks = 0;                       // the way is clear again
            }
        }
        setKeys(client, forward, sprint, jump, strafeDir);
    }

}
