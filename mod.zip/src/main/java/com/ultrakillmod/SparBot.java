package com.ultrakillmod;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;

/**
 * Sparring partner (client side). Press the key to start, press again to stop.
 * It only ever targets the usernames listed in PARTNERS, so it is a training opponent
 * for your own accounts and cannot be pointed at anyone else.
 *
 * Far away it ender-pearls straight onto the target (slot 1) instead of walking. Up close it hits with
 * the sword and, in crystal mode, follows with obsidian + crystals in the same tick (no waiting). When
 * blocks around make the sword + crystal combo awkward, it switches to pure crystal spam: pop and
 * re-place every tick, as fast as the connection allows.
 */
public final class SparBot {
    // Only these players can be targeted (lower-case).
    private static final Set<String> PARTNERS = Set.of(
            "babaykala22", "axyzet", "rico46_5556", "theobaldthebot");

    // ---- Tunables ----
    private static final int SWORD_SLOT = 4;          // hotbar slot 5 (0-based index)
    private static final int AXE_SLOT = 2;            // hotbar slot 3: swung once to break a raised shield
    private static final int SHIELD_BREAK_COOLDOWN = 25; // ticks before it will try to break a shield again
    private static final int CRYSTAL_SLOT = 5;       // hotbar slot 6: end crystals
    private static final int OBSIDIAN_SLOT = 8;      // hotbar slot 9: obsidian
    private static final int PEARL_SLOT = 0;          // hotbar slot 1: ender pearls
    private static final boolean PEARL_ENABLED = true;
    private static final double PEARL_MIN_DIST = 8.0; // pearl in from at least this far away
    private static final double PEARL_MAX_DIST = 40.0;
    private static final int PEARL_COOLDOWN = 22;     // ticks between pearl throws
    private static final double PEARL_SPEED = 1.5;
    private static final int RUSH_TICKS = 30;         // after a pearl: hit instantly, perfect aim, no cooldowns
    private static final int CRYSTAL_COOLDOWN = 8;   // ticks of sword fighting between crystal combos
    private static final int COMBO_POPS = 2;          // sword hit, then place+pop this many crystals
    private static final double SPAM_RANGE = 6.5;     // crystal spam only when the target is this close
    private static final int SPAM_HOLD = 20;          // keep spamming this long after the blocks stop being a problem
    private static final int STUCK_TICKS = 30;        // near the target this long without landing a sword hit = spam
    private static final int STUCK_HOLD = 60;
    private static final int CROWDED_BLOCKS = 8;      // solid blocks around feet+head (of 16) = cramped
    private static final double POP_REACH = 4.5;
    private static final int POP_REPEAT = 3;          // don't re-hit the same crystal within this many ticks
    private static final int PLACE_RETRY = 2;         // ticks before placing again if no crystal showed up
    private static final float SAFE_HEALTH = 8.0f;   // below this (4 hearts) with no totem it skips crystals
    private static final double SEARCH_RANGE = 48.0;  // how far away it looks for a partner
    private static final double CLOSE_DIST = 3.4;     // below this it starts the fight loop
    private static final double HIT_REACH = 3.0;      // a sword hit needs the target this close (eye to hitbox)
    private static final float MAX_TURN_YAW = 35.0f;  // degrees per tick
    private static final float MAX_TURN_PITCH = 25.0f;
    private static final float AIM_NOISE_YAW = 2.5f;  // aim wobble (degrees)
    private static final float AIM_NOISE_PITCH = 1.5f;
    private static final float HIT_CHARGE = 0.90f;    // attack charge needed before swinging (90%)
    private static final float JUMP_CHARGE = 0.5f;    // starts the jump early so the crit lands at ~95%
    private static final double JUMP_DIST = 2.8;      // only jump when this close (jumping from far away overshoots)
    private static final boolean CRIT_JUMPS = false;  // true = jump and hit on the way down (no sprint hit then)
    private static final boolean DEBUG = true;        // shows a status line above the hotbar
    private static final int WTAP_TICKS = 2;          // forward released this long after a hit
    private static final int MAX_REACTION_TICKS = 2;  // random extra delay before a hit

    private static final Random RND = new Random();

    private static boolean active = false;
    private static int mode = 0;                      // 0 = off, 1 = sword, 2 = crystal
    private static int crystalStage = 0;              // 0 = none, 1 = sword+crystal combo, 2 = crystal spam
    private static int crystalCooldown = 0;
    private static int stageTicks = 0;
    private static int obsidianTries = 0;
    private static int pops = 0;
    private static int placeCd = 0;
    private static int noBaseTicks = 0;
    private static int spamHold = 0;
    private static int spamBlock = 0;
    private static int ticksSinceHit = 0;
    private static int tickNo = 0;
    private static int pearlCooldown = 0;
    private static boolean pearlPending = false;
    private static int rush = 0;
    private static Vec3d lastBotPos = null;
    private static Vec3d lastTargetPos = null;
    private static int lastTargetId = -1;
    private static Vec3d targetVel = Vec3d.ZERO;
    private static final Map<Integer, Integer> recentPops = new HashMap<>();
    private static int totemCooldown = 0;
    private static int totemWarn = 0;
    private static int wTapTicks = 0;
    private static int strafeTicks = 0;
    private static int strafeDir = 0;
    private static int reaction = 0;
    private static int noiseTicks = 0;
    private static float noiseYaw = 0f;
    private static float noisePitch = 0f;
    private static int noticeCooldown = 0;
    private static int debugTicks = 0;
    private static int shieldCooldown = 0;

    // ---- difficulty: 0 = adaptive (follows how you are doing), 1 easy, 2 normal, 3 hard, 4 insane ----
    private static final float SKILL_MIN = 0.25f;
    private static final float SKILL_MAX = 1.0f;
    private static final float[] FIXED_SKILL = {0.65f, 0.30f, 0.55f, 0.80f, 1.00f};
    private static final String[] DIFF_NAMES = {"ADAPTIVE", "EASY", "NORMAL", "HARD", "INSANE"};
    private static int difficulty = 0;
    private static float skill = 0.65f;               // 0.25 .. 1.0, drives everything below
    private static float hitBalance = 0f;             // + when the bot is winning exchanges, - when you are
    private static int adaptTicks = 0;
    private static float lastTargetHealth = -1f;
    private static float lastBotHealth = -1f;
    private static boolean critNext = false;          // next swing is a jump crit instead of a sprint hit
    private static int critWait = 0;
    private static int hopCd = 0;
    private static boolean wantBack = false;          // S key for this tick (spacing)
    private static int infoHold = 0;                  // ticks the mode/difficulty message stays on screen

    private static String modeName() {
        return mode == 1 ? "SWORD" : mode == 2 ? "CRYSTAL" : "OFF";
    }

    private static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    private static float turnYaw() { return lerp(14f, 90f, skill); }          // degrees per tick
    private static float turnPitch() { return lerp(10f, 60f, skill); }
    private static float noiseYawMax() { return lerp(6.0f, 0.3f, skill); }   // aim wobble
    private static float noisePitchMax() { return lerp(4.0f, 0.2f, skill); }
    private static int maxReaction() { return Math.round(lerp(5f, 0f, skill)); }   // extra ticks before a swing
    private static float hitCharge() { return lerp(1.0f, 0.88f, skill); }
    private static float leadTicks() { return lerp(0f, 2.5f, skill); }       // aims ahead of a moving target
    private static float critChance() {
        return skill < 0.4f ? 0f : lerp(0.10f, 0.55f, (skill - 0.4f) / 0.6f);
    }

    /** Cycles ADAPTIVE -> EASY -> NORMAL -> HARD -> INSANE. */
    public static void cycleDifficulty(MinecraftClient client) {
        difficulty = (difficulty + 1) % DIFF_NAMES.length;
        skill = FIXED_SKILL[difficulty];
        hitBalance = 0f;
        if (client.player != null) {
            infoHold = 30;
            client.player.sendMessage(Text.literal("Spar bot: " + modeName() + " mode, difficulty "
                    + DIFF_NAMES[difficulty] + (difficulty == 0 ? " (adjusts to you)" : "")), true);
        }
    }

    /** Watches health on both sides: counts hits, and in ADAPTIVE mode turns the skill up when you are winning. */
    private static void trackResults(ClientPlayerEntity player, PlayerEntity target) {
        float th = target.getHealth();
        float bh = player.getHealth();
        if (lastTargetHealth >= 0f && th < lastTargetHealth - 0.01f) {
            hitBalance += 1f;                                  // the bot landed a hit
        }
        if (lastBotHealth >= 0f && bh < lastBotHealth - 0.01f && crystalStage == 0) {
            hitBalance -= 1f;                                  // you landed a hit
            strafeTicks = 0;                                   // react: change direction right away
            if (skill > 0.5f && player.isOnGround()) hopCd = 0;
        }
        lastTargetHealth = th;
        lastBotHealth = bh;

        if (difficulty == 0 && ++adaptTicks >= 40) {          // every 2 seconds
            adaptTicks = 0;
            if (hitBalance < -1.5f) skill = Math.min(SKILL_MAX, skill + 0.04f);       // you are ahead: harder
            else if (hitBalance > 3.0f) skill = Math.max(SKILL_MIN, skill - 0.02f);   // bot is far ahead: ease off
            hitBalance *= 0.7f;                                // forget old exchanges
        }
    }

    private SparBot() {}

    public static boolean isActive() {
        return active;
    }

    /** I cycles: sword mode -> crystal mode -> off. */
    public static void toggle(MinecraftClient client) {
        if (client.player == null) return;
        mode = (mode + 1) % 3;
        active = mode != 0;
        crystalStage = 0;
        if (active) {
            wTapTicks = 0;
            strafeTicks = 0;
            reaction = 0;
            shieldCooldown = 0;
            crystalCooldown = 0;
            totemCooldown = 0;
            resetFight();
            client.player.getInventory().setSelectedSlot(SWORD_SLOT);
            infoHold = 30;                             // keep this message up for ~1.5 s before the PvP info
            client.player.sendMessage(Text.literal("Spar bot: " + modeName() + " mode, difficulty "
                    + DIFF_NAMES[difficulty] + " (I = next mode, J = difficulty)"), true);
        } else {
            releaseKeys(client);
            infoHold = 30;
            client.player.sendMessage(Text.literal("Spar bot OFF"), true);
        }
    }

    public static void reset(MinecraftClient client) {
        active = false;
        mode = 0;
        crystalStage = 0;
        resetFight();
        if (client != null && client.options != null) releaseKeys(client);
    }

    private static void resetFight() {
        pearlPending = false;
        pearlCooldown = 0;
        rush = 0;
        spamHold = 0;
        spamBlock = 0;
        ticksSinceHit = 0;
        noBaseTicks = 0;
        placeCd = 0;
        lastBotPos = null;
        lastTargetPos = null;
        lastTargetId = -1;
        targetVel = Vec3d.ZERO;
        recentPops.clear();
        lastTargetHealth = -1f;
        lastBotHealth = -1f;
        hitBalance = 0f;
        adaptTicks = 0;
        critNext = false;
        critWait = 0;
        hopCd = 0;
    }

    private static void releaseKeys(MinecraftClient client) {
        client.options.forwardKey.setPressed(false);
        client.options.sprintKey.setPressed(false);
        client.options.leftKey.setPressed(false);
        client.options.rightKey.setPressed(false);
        client.options.jumpKey.setPressed(false);
        client.options.backKey.setPressed(false);
    }

    private static PlayerEntity findPartner(MinecraftClient client, ClientPlayerEntity self) {
        PlayerEntity best = null;
        double bestDist = SEARCH_RANGE * SEARCH_RANGE;
        for (PlayerEntity other : client.world.getPlayers()) {
            if (other == self || !other.isAlive() || other.isSpectator()) continue;
            String name = other.getName().getString().toLowerCase(Locale.ROOT);
            if (!PARTNERS.contains(name)) continue;
            double d = self.squaredDistanceTo(other);
            if (d < bestDist) {
                bestDist = d;
                best = other;
            }
        }
        return best;
    }

    /** True if the line of sight reaches the target's hitbox within sword reach (a little forgiving). */
    private static boolean canHit(ClientPlayerEntity player, Entity target) {
        Vec3d eye = player.getEyePos();
        Vec3d dir = player.getRotationVec(1.0F);
        Vec3d end = eye.add(dir.multiply(HIT_REACH));
        Box box = target.getBoundingBox().expand(0.12);
        return box.contains(eye) || box.raycast(eye, end).isPresent();
    }

    private static void aim(ClientPlayerEntity player, Entity target, boolean snap) {
        if (--noiseTicks <= 0) {
            noiseTicks = 6 + RND.nextInt(8);
            noiseYaw = (RND.nextFloat() * 2f - 1f) * noiseYawMax();
            noisePitch = (RND.nextFloat() * 2f - 1f) * noisePitchMax();
        }
        Vec3d eye = player.getEyePos();
        double dx = target.getX() + targetVel.x * leadTicks() - eye.x;
        double dy = (target.getY() + target.getHeight() * 0.65) - eye.y;
        double dz = target.getZ() + targetVel.z * leadTicks() - eye.z;
        double horizontal = Math.sqrt(dx * dx + dz * dz);

        float nYaw = snap ? 0f : noiseYaw;
        float nPitch = snap ? 0f : noisePitch;
        float wantYaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0f + nYaw;
        float wantPitch = (float) -Math.toDegrees(Math.atan2(dy, horizontal)) + nPitch;

        if (snap) {                                    // right after a pearl: look at the target instantly
            player.setYaw(wantYaw);
            player.setPitch(MathHelper.clamp(wantPitch, -90.0f, 90.0f));
            return;
        }
        float dYaw = MathHelper.clamp(MathHelper.wrapDegrees(wantYaw - player.getYaw()), -turnYaw(), turnYaw());
        float dPitch = MathHelper.clamp(wantPitch - player.getPitch(), -turnPitch(), turnPitch());
        player.setYaw(player.getYaw() + dYaw);
        player.setPitch(MathHelper.clamp(player.getPitch() + dPitch, -90.0f, 90.0f));
    }

    private static void trackMotion(ClientPlayerEntity player, PlayerEntity target) {
        if (rush > 0) rush--;
        if (pearlCooldown > 0) pearlCooldown--;
        if (spamBlock > 0) spamBlock--;
        Vec3d pos = new Vec3d(player.getX(), player.getY(), player.getZ());
        if (lastBotPos != null && pos.distanceTo(lastBotPos) > 4.0) rush = RUSH_TICKS;   // we just teleported
        lastBotPos = pos;
        Vec3d tp = new Vec3d(target.getX(), target.getY(), target.getZ());
        if (lastTargetPos != null && lastTargetId == target.getId()) {
            Vec3d v = tp.subtract(lastTargetPos);
            targetVel = new Vec3d(MathHelper.clamp(v.x, -0.5, 0.5), 0.0, MathHelper.clamp(v.z, -0.5, 0.5));
        } else {
            targetVel = Vec3d.ZERO;
        }
        lastTargetPos = tp;
        lastTargetId = target.getId();
    }

    // ------------------------------------------------------------------
    // Terrain checks
    // ------------------------------------------------------------------

    /** True if nothing solid is between our eyes and the target. */
    private static boolean lineClear(ClientWorld world, ClientPlayerEntity player, Entity target) {
        Vec3d from = player.getEyePos();
        Vec3d to = target.getBoundingBox().getCenter();
        HitResult hit = world.raycast(new RaycastContext(from, to,
                RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, player));
        return hit.getType() == HitResult.Type.MISS;
    }

    /** Solid blocks in the 8 columns around a position, at feet and head height (max 16). */
    private static int solidAround(ClientWorld world, BlockPos pos) {
        int n = 0;
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                if (dx == 0 && dz == 0) continue;
                for (int dy = 0; dy <= 1; dy++) {
                    BlockPos p = pos.add(dx, dy, dz);
                    if (!world.getBlockState(p).getCollisionShape(world, p).isEmpty()) n++;
                }
            }
        }
        return n;
    }

    /** Blocks make the sword hit + crystal combo awkward: walls in the way, or either of us boxed in. */
    private static boolean isCrowded(ClientWorld world, ClientPlayerEntity player, Entity target) {
        return !lineClear(world, player, target)
                || solidAround(world, target.getBlockPos()) >= CROWDED_BLOCKS
                || solidAround(world, player.getBlockPos()) >= CROWDED_BLOCKS;
    }

    // ------------------------------------------------------------------
    // Ender pearl: instead of walking over, throw one onto the target
    // ------------------------------------------------------------------

    /** Pitch (degrees) that makes a pearl thrown at speed 1.5 land horiz blocks away and dy blocks up/down. NaN = out of range. */
    private static float solvePitch(double horiz, double dy) {
        float best = Float.NaN;
        double bestErr = 2.0;
        for (float elev = -20f; elev <= 75f; elev += 0.5f) {   // flattest (fastest) solution wins ties
            double rad = Math.toRadians(elev);
            double vx = PEARL_SPEED * Math.cos(rad);
            double vy = PEARL_SPEED * Math.sin(rad);
            double x = 0, y = 0;
            for (int t = 0; t < 150; t++) {
                double px = x, py = y;
                x += vx;
                y += vy;
                vx *= 0.99;
                vy = vy * 0.99 - 0.03;
                if (x >= horiz) {
                    double f = (horiz - px) / (x - px);
                    double err = Math.abs(py + f * (y - py) - dy);
                    if (err < bestErr - 0.05) {
                        bestErr = err;
                        best = -elev;
                    }
                    break;
                }
                if (vx < 0.01) break;
            }
        }
        return best;
    }

    /** Snaps the view onto the pearl's arc to the target (with a little lead). False if it can't be reached. */
    private static boolean aimPearl(ClientPlayerEntity player, PlayerEntity target) {
        Vec3d eye = player.getEyePos();
        double flight = player.distanceTo(target) / 1.3;
        double tx = target.getX() + targetVel.x * flight * 0.8;
        double tz = target.getZ() + targetVel.z * flight * 0.8;
        double ty = target.getY() + target.getHeight() * 0.5;
        double dx = tx - eye.x, dz = tz - eye.z, dy = ty - eye.y;
        float pitch = solvePitch(Math.sqrt(dx * dx + dz * dz), dy);
        if (Float.isNaN(pitch)) return false;
        player.setYaw((float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0f);
        player.setPitch(pitch);
        return true;
    }

    /** Phase 1: look along the pearl arc now, so the server has the rotation before the throw next tick. */
    private static void tryStartPearl(ClientWorld world, ClientPlayerEntity player, PlayerEntity target, double dist) {
        if (!PEARL_ENABLED || pearlCooldown > 0) return;
        if (dist < PEARL_MIN_DIST || dist > PEARL_MAX_DIST) return;
        if (!player.getInventory().getStack(PEARL_SLOT).isOf(Items.ENDER_PEARL)) return;
        if (!lineClear(world, player, target)) return;
        if (aimPearl(player, target)) pearlPending = true;
    }

    /** Phase 2: throw it. */
    private static void throwPearl(MinecraftClient client, ClientPlayerEntity player, PlayerEntity target, double dist) {
        pearlPending = false;
        if (dist < PEARL_MIN_DIST - 2.0 || dist > PEARL_MAX_DIST + 4.0) return;
        if (!player.getInventory().getStack(PEARL_SLOT).isOf(Items.ENDER_PEARL)) return;
        if (!aimPearl(player, target)) return;
        player.getInventory().setSelectedSlot(PEARL_SLOT);
        client.interactionManager.interactItem(player, Hand.MAIN_HAND);
        player.swingHand(Hand.MAIN_HAND);
        pearlCooldown = PEARL_COOLDOWN;
        rush = RUSH_TICKS;
    }

    // ------------------------------------------------------------------
    // Auto totem
    // ------------------------------------------------------------------

    /** Keeps a totem in the off-hand: after a pop, the next one is moved there within a few ticks. */
    private static void ensureTotem(MinecraftClient client, ClientPlayerEntity player) {
        if (totemCooldown > 0) {
            totemCooldown--;
            return;
        }
        if (player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;
        for (int i = 0; i < 36; i++) {
            if (player.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) {
                int slotId = i < 9 ? 36 + i : i;     // hotbar slots are 36-44 in the inventory screen
                client.interactionManager.clickSlot(
                        player.playerScreenHandler.syncId, slotId, 40, SlotActionType.SWAP, player);
                totemCooldown = 1;
                return;
            }
        }
        if (--totemWarn <= 0) {
            if (infoHold == 0) player.sendMessage(Text.literal("Spar bot: out of totems"), true);
            totemWarn = 100;
        }
    }

    private static boolean crystalSafe(ClientPlayerEntity player) {
        return player.getHealth() > SAFE_HEALTH || player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING);
    }

    // ------------------------------------------------------------------
    // Crystals. Combo: sword hit, then place + pop twice. Spam: place + pop every tick, no sword.
    // Everything is chained in the same tick: no delays between obsidian, crystal and pop.
    // ------------------------------------------------------------------

    private static boolean hasCrystals(ClientPlayerEntity player) {
        return player.getInventory().getStack(CRYSTAL_SLOT).isOf(Items.END_CRYSTAL);
    }

    private static void startCrystal() {
        crystalStage = 1;
        stageTicks = 0;
        obsidianTries = 0;
        pops = 0;
        placeCd = 0;
        noBaseTicks = 0;
    }

    private static void startSpam(boolean crowded) {
        crystalStage = 2;
        spamHold = crowded ? SPAM_HOLD : STUCK_HOLD;
        obsidianTries = 0;
        noBaseTicks = 0;
        placeCd = 0;
    }

    private static void endCrystal(ClientPlayerEntity player) {
        crystalStage = 0;
        crystalCooldown = CRYSTAL_COOLDOWN;
        ticksSinceHit = 0;
        player.getInventory().setSelectedSlot(SWORD_SLOT);
    }

    private static boolean isBase(ClientWorld world, BlockPos pos) {
        BlockState state = world.getBlockState(pos);
        return state.isOf(Blocks.OBSIDIAN) || state.isOf(Blocks.BEDROCK);
    }

    /** Best block next to the target for a crystal. Existing obsidian/bedrock is preferred (saves a placement). */
    private static BlockPos findBase(ClientWorld world, ClientPlayerEntity bot, Entity target) {
        BlockPos t = target.getBlockPos();
        int gy = t.getY();
        for (int i = 0; i < 8; i++) {                 // the target may be in the air: find the ground below
            if (!world.getBlockState(new BlockPos(t.getX(), gy - 1, t.getZ())).isAir()) break;
            gy--;
        }
        Vec3d eye = bot.getEyePos();
        Vec3d center = target.getBoundingBox().getCenter();
        BlockPos best = null;
        double bestScore = Double.MAX_VALUE;

        for (int dx = -3; dx <= 3; dx++) {
            for (int dz = -3; dz <= 3; dz++) {
                int x = t.getX() + dx;
                int z = t.getZ() + dz;
                BlockPos floor = new BlockPos(x, gy - 1, z);
                BlockState floorState = world.getBlockState(floor);
                BlockPos base;
                boolean existing = false;
                if (floorState.isOf(Blocks.OBSIDIAN) || floorState.isOf(Blocks.BEDROCK)) {
                    base = floor;                      // already a crystal base
                    existing = true;
                } else if (floorState.isSideSolidFullSquare(world, floor, Direction.UP)
                        && world.getBlockState(floor.up()).isAir()) {
                    base = floor.up();                 // obsidian goes here
                } else {
                    continue;
                }
                if (!world.getBlockState(base.up()).isAir() || !world.getBlockState(base.up().up()).isAir()) continue;

                Box zone = new Box(x, base.getY(), z, x + 1, base.getY() + 3, z + 1);
                if (target.getBoundingBox().intersects(zone) || bot.getBoundingBox().intersects(zone)) continue;

                double reachSq = eye.squaredDistanceTo(x + 0.5, base.getY() + 1.0, z + 0.5);
                if (reachSq > 4.4 * 4.4) continue;

                double dT = Math.sqrt(center.squaredDistanceTo(x + 0.5, base.getY() + 1.0, z + 0.5));
                double score = dT - 0.25 * Math.sqrt(reachSq) - (existing ? 1.5 : 0.0);
                if (score < bestScore) {
                    bestScore = score;
                    best = base;
                }
            }
        }
        return best;
    }

    /** Right-click the top face of a block. */
    private static void clickTop(MinecraftClient client, ClientPlayerEntity player, BlockPos block) {
        Vec3d hit = new Vec3d(block.getX() + 0.5, block.getY() + 1.0, block.getZ() + 0.5);
        client.interactionManager.interactBlock(player, Hand.MAIN_HAND,
                new BlockHitResult(hit, Direction.UP, block, false));
        player.swingHand(Hand.MAIN_HAND);
    }

    private static EndCrystalEntity findCrystal(ClientWorld world, BlockPos base) {
        Box box = new Box(base.up()).expand(0.8);
        List<EndCrystalEntity> list = world.getEntitiesByClass(EndCrystalEntity.class, box, e -> e.isAlive());
        return list.isEmpty() ? null : list.get(0);
    }

    /**
     * One tick of crystal work: pop every crystal in reach next to the target, then (in the same tick)
     * put the next one down. In combo mode it stops after COMBO_POPS pops, in spam mode it never stops.
     */
    private static void crystalCycle(MinecraftClient client, ClientPlayerEntity player, PlayerEntity target) {
        ClientWorld world = client.world;
        boolean spam = crystalStage == 2;
        if (!spam && ++stageTicks > 40) {              // combo took too long: back to the sword
            endCrystal(player);
            return;
        }
        if (placeCd > 0) placeCd--;

        // 1) pop right away
        boolean popped = false;
        int hits = 0;
        Vec3d eye = player.getEyePos();
        for (EndCrystalEntity c : world.getEntitiesByClass(EndCrystalEntity.class,
                target.getBoundingBox().expand(7.0), e -> e.isAlive())) {
            Integer last = recentPops.get(c.getId());
            if (last != null && tickNo - last < POP_REPEAT) continue;
            if (eye.distanceTo(c.getBoundingBox().getCenter()) > POP_REACH) continue;
            client.interactionManager.attackEntity(player, c);
            player.swingHand(Hand.MAIN_HAND);
            recentPops.put(c.getId(), tickNo);
            popped = true;
            pops++;
            if (++hits >= 2) break;
        }
        if (recentPops.size() > 64) recentPops.clear();
        if (!spam && pops >= COMBO_POPS) {
            endCrystal(player);
            return;
        }

        // 2) base block
        BlockPos base = findBase(world, player, target);
        if (base == null) {                            // no space for a crystal anywhere
            if (spam) noBaseTicks++; else endCrystal(player);
            return;
        }
        if (!isBase(world, base)) {
            if (!player.getInventory().getStack(OBSIDIAN_SLOT).isOf(Items.OBSIDIAN) || ++obsidianTries > 6) {
                if (spam) noBaseTicks += 4; else endCrystal(player);
                return;
            }
            player.getInventory().setSelectedSlot(OBSIDIAN_SLOT);
            clickTop(client, player, base.down());     // the client predicts it, so the crystal can go down this same tick
        } else {
            obsidianTries = 0;
        }

        // 3) crystal: straight after a pop (same tick), or when nothing is on the base
        if (!hasCrystals(player)) {
            if (spam) noBaseTicks += 4; else endCrystal(player);
            return;
        }
        noBaseTicks = 0;
        if (popped || (placeCd == 0 && findCrystal(world, base) == null)) {
            player.getInventory().setSelectedSlot(CRYSTAL_SLOT);
            clickTop(client, player, base);
            placeCd = PLACE_RETRY;
        }
    }

    private static boolean keepSpamming(ClientWorld world, ClientPlayerEntity player, PlayerEntity target, double dist) {
        if (dist > SPAM_RANGE + 2.0 || !crystalSafe(player) || !hasCrystals(player)) return false;
        if (noBaseTicks > 12) {                        // nowhere to put a crystal: fight with the sword instead
            spamBlock = 60;
            return false;
        }
        if (isCrowded(world, player, target)) spamHold = Math.max(spamHold, SPAM_HOLD);
        return --spamHold > 0;
    }

    private static void setKeys(MinecraftClient client, boolean forward, boolean sprint, boolean jump, int strafe) {
        client.options.forwardKey.setPressed(forward);
        client.options.sprintKey.setPressed(sprint);
        client.options.jumpKey.setPressed(jump);
        client.options.leftKey.setPressed(strafe < 0);
        client.options.rightKey.setPressed(strafe > 0);
        client.options.backKey.setPressed(wantBack);
        wantBack = false;
    }

    public static void tick(MinecraftClient client) {
        if (infoHold > 0) infoHold--;
        if (!active) return;
        ClientPlayerEntity player = client.player;
        if (player == null || client.world == null || client.interactionManager == null) {
            reset(client);
            return;
        }
        if (client.currentScreen != null) {      // menus / chat open: pause
            releaseKeys(client);
            return;
        }

        PlayerEntity target = findPartner(client, player);
        if (target == null) {
            releaseKeys(client);
            crystalStage = 0;
            pearlPending = false;
            if (--noticeCooldown <= 0) {
                if (infoHold == 0) player.sendMessage(Text.literal("Spar bot: no partner nearby"), true);
                noticeCooldown = 40;
            }
            return;
        }

        ClientWorld world = client.world;
        tickNo++;
        trackMotion(player, target);
        trackResults(player, target);

        if (crystalStage == 0 && !pearlPending && player.getInventory().getSelectedSlot() != SWORD_SLOT) {
            player.getInventory().setSelectedSlot(SWORD_SLOT);
        }

        if (!pearlPending) aim(player, target, rush > 0);   // while a pearl is lined up the view stays on its arc
        ensureTotem(client, player);

        if (--strafeTicks <= 0) {
            if (skill > 0.55f) {                      // skilled: always moving, flips direction often
                strafeDir = RND.nextBoolean() ? 1 : -1;
                strafeTicks = Math.round(lerp(14f, 4f, skill)) + RND.nextInt(6);
            } else {
                strafeDir = RND.nextInt(3) - 1;       // -1 left, 0 none, 1 right
                strafeTicks = 10 + RND.nextInt(20);
            }
        }

        double dist = player.distanceTo(target);

        if (pearlPending) throwPearl(client, player, target, dist);

        if (crystalStage == 2) {                       // crystal spam: no sword, place + pop every tick
            if (keepSpamming(world, player, target, dist)) {
                setKeys(client, false, false, false, strafeDir);
                crystalCycle(client, player, target);
                return;
            }
            crystalStage = 0;
            ticksSinceHit = 0;
            player.getInventory().setSelectedSlot(SWORD_SLOT);
        } else if (crystalStage == 1) {                // sword hit landed: run the crystals
            releaseKeys(client);
            crystalCycle(client, player, target);
            return;
        }
        if (crystalCooldown > 0) crystalCooldown--;

        boolean onGround = player.isOnGround();
        boolean falling = !onGround && player.getVelocity().y < -0.06;
        float charge = player.getAttackCooldownProgress(0.0F);

        if (dist <= 5.0) ticksSinceHit++; else ticksSinceHit = 0;

        // Far away: pearl onto the target instead of walking over.
        if (!pearlPending) tryStartPearl(world, player, target, dist);

        // Blocks around (or no way to land the sword hit): skip the sword, just spam crystals.
        if (mode == 2 && crystalStage == 0 && spamBlock == 0 && dist <= SPAM_RANGE
                && crystalSafe(player) && hasCrystals(player)) {
            boolean crowded = isCrowded(world, player, target);
            if (crowded || ticksSinceHit > STUCK_TICKS) {
                startSpam(crowded);
                setKeys(client, false, false, false, strafeDir);
                crystalCycle(client, player, target);
                return;
            }
        }

        boolean forward = true;
        boolean sprint = true;
        boolean jump = false;

        if (wTapTicks > 0) {                          // W-tap: let go of forward to reset sprint
            wTapTicks--;
            forward = false;
            sprint = false;
        }

        boolean aimedInReach = canHit(player, target);
        boolean quick = rush > 0;                     // just pearled in: don't wait for the sword to charge
        boolean ready = charge >= hitCharge() || quick;

        // Skilled: bunny-hop while closing in to keep sprint speed, and back off a step while the sword
        // recharges so you cannot get the first hit in.
        if (hopCd > 0) hopCd--;
        if (skill > 0.55f && dist > CLOSE_DIST + 0.6 && onGround && hopCd == 0 && wTapTicks == 0) {
            jump = true;
            hopCd = 6 + RND.nextInt(4);
        }
        if (skill > 0.5f && !ready && dist < 2.2 && wTapTicks == 0 && rush == 0) {
            wantBack = true;
            forward = false;
            sprint = false;
        }

        if (dist <= CLOSE_DIST) {
            if (critNext) {
                // Optional crit mode: jump early, release W while falling, hit on the way down.
                if (onGround && charge >= JUMP_CHARGE && dist <= JUMP_DIST && wTapTicks == 0) {
                    jump = true;
                }
                if (ready && aimedInReach) critWait++;
                if (falling) {
                    forward = false;
                    sprint = false;
                }
            }

            // Shield up? Swap to the axe and hit at once (the sword comes back next tick).
            if (shieldCooldown > 0) shieldCooldown--;
            boolean blocking = target.isBlocking();

            // Sprint-hit combo: 1) hold W (sprinting)  2) hit  3) release W, then press it again.
            if (reaction > 0 && !quick) {
                reaction--;
            } else if (blocking && aimedInReach && shieldCooldown == 0) {
                player.getInventory().setSelectedSlot(AXE_SLOT);
                client.interactionManager.attackEntity(player, target);
                player.swingHand(Hand.MAIN_HAND);
                shieldCooldown = SHIELD_BREAK_COOLDOWN;
                wTapTicks = WTAP_TICKS;
                reaction = RND.nextInt(maxReaction() + 1);
            } else if (ready && aimedInReach && !blocking
                    && (!critNext || (falling && !player.isSprinting()) || critWait > 14)) {
                client.interactionManager.attackEntity(player, target);
                player.swingHand(Hand.MAIN_HAND);
                wTapTicks = WTAP_TICKS;                   // release W so the sprint resets
                reaction = quick ? 0 : RND.nextInt(maxReaction() + 1);
                ticksSinceHit = 0;
                rush = 0;
                critNext = RND.nextFloat() < critChance();   // sometimes the next one is a jump crit
                critWait = 0;

                // Crystal mode: right after the sword hit, obsidian + crystal + pop + crystal + pop, same tick onward.
                if (mode == 2 && (crystalCooldown == 0 || quick) && crystalSafe(player) && hasCrystals(player)) {
                    startCrystal();
                    crystalCycle(client, player, target);
                }
            }
        }

        if (DEBUG && infoHold == 0 && --debugTicks <= 0) {
            debugTicks = 10;
            player.sendMessage(Text.literal(String.format(Locale.ROOT,
                    "d=%.1f charge=%.2f %s%s%s aim=%s st=%d rush=%d pearl=%s skill=%.2f %s",
                    dist, charge, onGround ? "G" : "-", falling ? "F" : "-",
                    player.isSprinting() ? "S" : "-", aimedInReach ? "Y" : "N",
                    crystalStage, rush, pearlPending ? "Y" : "N", skill, DIFF_NAMES[difficulty])), true);
        }

        setKeys(client, forward, sprint, jump, strafeDir);
    }
}
