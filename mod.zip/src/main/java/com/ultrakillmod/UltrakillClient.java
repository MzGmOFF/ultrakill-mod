package com.ultrakillmod;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.event.client.player.ClientPreAttackCallback;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class UltrakillClient implements ClientModInitializer {
    public static KeyBinding DASH_KEY;
    public static KeyBinding SWITCH_KEY;
    public static KeyBinding SLIDE_KEY;
    public static KeyBinding STUN_KEY;
    public static KeyBinding SPAR_KEY;
    public static KeyBinding SPAR_DIFF_KEY;
    private static int coinCooldown = 0;

    @Override
    public void onInitializeClient() {
        KeyBinding.Category category = KeyBinding.Category.create(UltrakillMod.id("main"));
        DASH_KEY = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.ultrakill.dash", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_X, category));
        SWITCH_KEY = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.ultrakill.switch", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_V, category));

        SLIDE_KEY = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.ultrakill.slide", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_Z, category));
        STUN_KEY = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.ultrakill.stun_slam", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_O, category));
        SPAR_KEY = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.ultrakill.spar_bot", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_I, category));
        SPAR_DIFF_KEY = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.ultrakill.spar_difficulty", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_J, category));

        // Marksman: left click tosses a coin instead of swinging.
        ClientPreAttackCallback.EVENT.register((client, player, clickCount) -> {
            if (player.getMainHandStack().getItem() == ModItems.MARKSMAN_REVOLVER) {
                if (coinCooldown == 0) {
                    ClientPlayNetworking.send(new Networking.CoinPayload());
                    coinCooldown = 10;
                }
                return true;
            }
            return false;
        });

        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            SlideTracker.clear();
            AirMoves.reset();
            SparBot.reset(client);
        });

        ClientPlayNetworking.registerGlobalReceiver(Networking.StylePayload.ID,
                (payload, context) -> StyleMeter.add(payload.gain(), payload.variant()));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) return;
            DashState.tick();
            StyleMeter.tick();
            SlideState.tick(client.player);
            AirMoves.tick(client);
            StunSlam.tick(client);
            SparBot.tick(client);
            if (coinCooldown > 0) coinCooldown--;

            while (DASH_KEY.wasPressed()) {
                DashState.tryDash(client.player);
            }
            while (SPAR_KEY.wasPressed()) {
                SparBot.toggle(client);
            }
            while (SPAR_DIFF_KEY.wasPressed()) {
                SparBot.cycleDifficulty(client);
            }
            while (STUN_KEY.wasPressed()) {
                StunSlam.start(client);
            }
            while (SLIDE_KEY.wasPressed()) {
                SlideState.tryStart(client.player);
            }
            while (SWITCH_KEY.wasPressed()) {
                if (client.player.getMainHandStack().getItem() instanceof RevolverItem) {
                    ClientPlayNetworking.send(new Networking.SwitchPayload());
                }
            }
        });

        // Our own effect icons replace the vanilla ones (same corner).
        HudElementRegistry.replaceElement(VanillaHudElements.STATUS_EFFECTS, original -> (context, tickCounter) -> {});

        HudElementRegistry.addLast(UltrakillMod.id("hud"), UltrakillHud::render);
    }
}
