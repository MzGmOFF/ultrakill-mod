package com.ultrakillmod;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class UltrakillClient implements ClientModInitializer {
    public static KeyBinding DASH_KEY;
    public static KeyBinding SWITCH_KEY;

    @Override
    public void onInitializeClient() {
        KeyBinding.Category category = KeyBinding.Category.create(UltrakillMod.id("main"));
        DASH_KEY = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.ultrakill.dash", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_X, category));
        SWITCH_KEY = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.ultrakill.switch", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_V, category));

        ClientPlayNetworking.registerGlobalReceiver(Networking.StylePayload.ID,
                (payload, context) -> StyleMeter.add(payload.gain(), payload.variant()));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) return;
            DashState.tick();
            StyleMeter.tick();

            while (DASH_KEY.wasPressed()) {
                DashState.tryDash(client.player);
            }
            while (SWITCH_KEY.wasPressed()) {
                if (client.player.getMainHandStack().getItem() instanceof RevolverItem) {
                    ClientPlayNetworking.send(new Networking.SwitchPayload());
                }
            }
        });

        HudElementRegistry.addLast(UltrakillMod.id("hud"), UltrakillHud::render);
    }
}
