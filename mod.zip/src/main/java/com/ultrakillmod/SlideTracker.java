package com.ultrakillmod;

import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Which players are currently sliding. Used on the client (own player) and on the server (from packets). */
public final class SlideTracker {
    private static final Set<UUID> SLIDING = ConcurrentHashMap.newKeySet();

    private SlideTracker() {}

    public static void set(UUID id, boolean sliding) {
        if (sliding) SLIDING.add(id);
        else SLIDING.remove(id);
    }

    public static boolean isSliding(UUID id) {
        return SLIDING.contains(id);
    }

    public static void clear() {
        SLIDING.clear();
    }
}
