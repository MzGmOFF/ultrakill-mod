package com.ultrakillmod;

import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;

/** The three revolver variants. Stats are simple placeholders for now. */
public enum Variant {
    // damage, cooldown (ticks), pierces entities, range, tracer particle, sound pitch
    PIERCER(5.0f, 12, true, 80.0, ParticleTypes.ELECTRIC_SPARK, 1.3f),
    MARKSMAN(4.0f, 6, false, 80.0, ParticleTypes.HAPPY_VILLAGER, 1.7f),
    SHARPSHOOTER(9.0f, 20, false, 80.0, ParticleTypes.FLAME, 0.8f);

    public final float damage;
    public final int cooldownTicks;
    public final boolean pierce;
    public final double range;
    public final ParticleEffect particle;
    public final float pitch;

    Variant(float damage, int cooldownTicks, boolean pierce, double range, ParticleEffect particle, float pitch) {
        this.damage = damage;
        this.cooldownTicks = cooldownTicks;
        this.pierce = pierce;
        this.range = range;
        this.particle = particle;
        this.pitch = pitch;
    }
}
