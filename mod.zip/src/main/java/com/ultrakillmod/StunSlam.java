package com.ultrakillmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Vec3d;

/**
 * Stun slam combo with an attribute swap (client side), spread over 2 ticks:
 *   tick 1: slot 2 -> slot 3 -> hit
 *   tick 2: slot 2 -> slot 8 -> hit
 * Runs every time the key is pressed. It does not care what items are in the slots,
 * and it does not need a target: if nothing is in reach, the hands just swing.
 * Slot numbers below are 0-based (hotbar slot 2 = index 1).
 */
public final class StunSlam {
    private static final int FIRST_SLOT = 1;   // hotbar slot 2
    private static final int AXE_SLOT = 2;     // hotbar slot 3
    private static final int MACE_SLOT = 7;    // hotbar slot 8
    private static final int GAP_TICKS = 1;    // second hit lands on tick 2
    private static final double REACH = 4.5;   // spear reach

    private static int countdown = 0;
    private static Entity lastTarget = null;

    private StunSlam() {}

    public static void start(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        if (player == null || client.interactionManager == null || countdown > 0) return;
        lastTarget = findTarget(player);
        strike(client, player, AXE_SLOT);
        countdown = GAP_TICKS;
    }

    /** Call once per tick BEFORE handling the key. */
    public static void tick(MinecraftClient client) {
        if (countdown <= 0) return;
        countdown--;
        if (countdown == 0) {
            ClientPlayerEntity player = client.player;
            if (player != null && client.interactionManager != null) {
                strike(client, player, MACE_SLOT);
            }
            lastTarget = null;
        }
    }

    /** What the crosshair is on, out to spear reach (4.5 blocks), whatever you are holding. */
    private static Entity findTarget(ClientPlayerEntity player) {
        Vec3d start = player.getEyePos();
        Vec3d dir = player.getRotationVec(1.0F);
        Vec3d end = start.add(dir.multiply(REACH));
        EntityHitResult hit = ProjectileUtil.raycast(player, start, end,
                player.getBoundingBox().stretch(dir.multiply(REACH)).expand(1.0),
                e -> !e.isSpectator() && e.canHit(), REACH * REACH);
        return hit == null ? null : hit.getEntity();
    }

    /** Select slot 2, then the weapon slot, then attack, all inside the same tick. */
    private static void strike(MinecraftClient client, ClientPlayerEntity player, int weaponSlot) {
        player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(FIRST_SLOT));
        player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(weaponSlot));
        player.getInventory().setSelectedSlot(weaponSlot);

        // Re-aim for this hit; fall back to the earlier target if it is still close.
        Entity target = findTarget(player);
        if (target == null && lastTarget != null && lastTarget.isAlive()
                && player.squaredDistanceTo(lastTarget) <= REACH * REACH) {
            target = lastTarget;
        }
        if (target != null) {
            client.interactionManager.attackEntity(player, target);
            lastTarget = target;
        }
        player.swingHand(Hand.MAIN_HAND);
    }
}
