package com.ultrakillmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;

/**
 * Stun slam combo with an attribute swap (client side):
 *   tick 1: spear slot -> axe slot -> hit
 *   tick 2: spear slot -> mace slot -> hit
 * Slot numbers below are 0-based (hotbar slot 2 = index 1).
 */
public final class StunSlam {
    private static final int SPEAR_SLOT = 1; // hotbar slot 2
    private static final int AXE_SLOT = 2;   // hotbar slot 3
    private static final int MACE_SLOT = 7;  // hotbar slot 8

    private static boolean pending = false;
    private static Entity target = null;

    private StunSlam() {}

    private static boolean isSpear(ItemStack stack) {
        return !stack.isEmpty() && Registries.ITEM.getId(stack.getItem()).getPath().endsWith("spear");
    }

    public static void start(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        if (player == null || client.interactionManager == null || pending) return;

        if (!(client.crosshairTarget instanceof EntityHitResult hit)) return; // must be aiming at something

        if (!isSpear(player.getInventory().getStack(SPEAR_SLOT))
                || !player.getInventory().getStack(AXE_SLOT).isIn(ItemTags.AXES)
                || !player.getInventory().getStack(MACE_SLOT).isOf(Items.MACE)) {
            player.sendMessage(Text.literal("Stun slam: spear in slot 2, axe in slot 3, mace in slot 8"), true);
            return;
        }

        target = hit.getEntity();
        strike(client, player, AXE_SLOT);
        pending = true;
    }

    /** Call once per tick BEFORE handling the key, so the second hit lands exactly one tick later. */
    public static void tick(MinecraftClient client) {
        if (!pending) return;
        pending = false;
        ClientPlayerEntity player = client.player;
        if (player != null && client.interactionManager != null && target != null && target.isAlive()) {
            strike(client, player, MACE_SLOT);
        }
        target = null;
    }

    /** Select the spear, then the weapon, then attack, all inside the same tick. */
    private static void strike(MinecraftClient client, ClientPlayerEntity player, int weaponSlot) {
        player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(SPEAR_SLOT));
        player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(weaponSlot));
        player.getInventory().setSelectedSlot(weaponSlot);
        client.interactionManager.attackEntity(player, target);
        player.swingHand(Hand.MAIN_HAND);
    }
}
