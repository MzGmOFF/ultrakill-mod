package com.ultrakillmod;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

public class RevolverItem extends Item {
    private static final double RICOCHET_RANGE = 40.0;

    private final Variant variant;

    public RevolverItem(Settings settings, Variant variant) {
        super(settings);
        this.variant = variant;
    }

    public Variant getVariant() {
        return variant;
    }

    @Override
    public ActionResult use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (world instanceof ServerWorld serverWorld && user instanceof ServerPlayerEntity player) {
            fire(serverWorld, player);
            player.getItemCooldownManager().set(stack, variant.cooldownTicks);
        }
        return ActionResult.SUCCESS;
    }

    private record Hit(LivingEntity entity, double distSq) {}

    private void fire(ServerWorld world, ServerPlayerEntity player) {
        Vec3d start = player.getEyePos();
        Vec3d dir = player.getRotationVec(1.0F);
        Vec3d end = start.add(dir.multiply(variant.range));
        Vec3d origin = start.add(dir.multiply(1.2)).add(0.0, -0.15, 0.0);

        // Stop the shot at the first solid block.
        BlockHitResult blockHit = world.raycast(new RaycastContext(
                start, end, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, player));
        Vec3d stop = blockHit.getType() == HitResult.Type.MISS ? end : blockHit.getPos();

        // Find every living thing along the ray.
        Box area = new Box(start, stop).expand(1.0);
        List<LivingEntity> candidates = world.getEntitiesByClass(
                LivingEntity.class, area, e -> e != player && e.isAlive() && !e.isSpectator());
        List<Hit> hits = new ArrayList<>();
        for (LivingEntity e : candidates) {
            Optional<Vec3d> point = e.getBoundingBox().expand(0.15).raycast(start, stop);
            if (point.isPresent()) {
                hits.add(new Hit(e, start.squaredDistanceTo(point.get())));
            }
        }
        hits.sort(Comparator.comparingDouble(Hit::distSq));

        // Did the shot cross a coin before it reached anything else?
        Coins.Coin coinHit = null;
        double coinDist = Double.MAX_VALUE;
        List<Coins.Coin> coinList = variant == Variant.MARKSMAN ? Coins.alive() : new ArrayList<>();
        for (Coins.Coin c : coinList) {
            Optional<Vec3d> point = c.entity().getBoundingBox().expand(0.4).raycast(start, stop);
            if (point.isPresent()) {
                double d = start.squaredDistanceTo(point.get());
                if (d < coinDist) {
                    coinDist = d;
                    coinHit = c;
                }
            }
        }
        double firstEntityDist = hits.isEmpty() ? Double.MAX_VALUE : hits.get(0).distSq();

        playShot(world, player);
        int gain = 0;

        if (coinHit != null && coinDist <= firstEntityDist) {
            Vec3d coinPos = coinHit.entity().getBoundingBox().getCenter();
            tracer(world, variant.particle, origin, coinPos);
            gain = ricochet(world, player, coinHit);
        } else {
            DamageSource source = world.getDamageSources().playerAttack(player);
            for (Hit hit : hits) {
                hit.entity().damage(world, source, variant.damage);
                gain += 30;
                if (!hit.entity().isAlive()) {
                    gain += 70;
                }
                if (!variant.pierce) {
                    break;
                }
            }
            tracer(world, variant.particle, origin, stop);
        }

        if (gain > 0) {
            ServerPlayNetworking.send(player, new Networking.StylePayload(gain, variant.ordinal()));
        }
    }

    /** The shot hit a coin: bounce to other coins first, then to the nearest enemy. Returns style gain. */
    private int ricochet(ServerWorld world, ServerPlayerEntity player, Coins.Coin first) {
        DamageSource source = world.getDamageSources().playerAttack(player);
        Vec3d from = first.entity().getBoundingBox().getCenter();
        Coins.remove(first);
        int level = 1;
        int gain = 80;
        chime(world, from, level);

        for (int i = 0; i < 8; i++) {
            Coins.Coin next = nearestCoin(world, player, from);
            if (next != null) {
                Vec3d to = next.entity().getBoundingBox().getCenter();
                tracer(world, ParticleTypes.END_ROD, from, to);
                Coins.remove(next);
                from = to;
                level++;
                gain += 80;
                chime(world, from, level);
                continue;
            }

            LivingEntity target = findTarget(world, player, from);
            if (target != null) {
                Vec3d to = target.getBoundingBox().getCenter();
                tracer(world, ParticleTypes.END_ROD, from, to);
                target.damage(world, source, variant.damage * (1.0F + level));
                gain += 100;
                if (!target.isAlive()) {
                    gain += 100;
                }
                chime(world, to, level + 1);
            } else {
                tracer(world, ParticleTypes.END_ROD, from, from.add(0.0, 6.0, 0.0));
            }
            break;
        }
        return gain;
    }

    private static boolean clear(ServerWorld world, ServerPlayerEntity player, Vec3d a, Vec3d b) {
        return world.raycast(new RaycastContext(
                a, b, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, player))
                .getType() == HitResult.Type.MISS;
    }

    private static Coins.Coin nearestCoin(ServerWorld world, ServerPlayerEntity player, Vec3d from) {
        Coins.Coin best = null;
        double bestDist = RICOCHET_RANGE * RICOCHET_RANGE;
        for (Coins.Coin c : Coins.alive()) {
            Vec3d center = c.entity().getBoundingBox().getCenter();
            double d = from.squaredDistanceTo(center);
            if (d < bestDist && d > 0.01 && clear(world, player, from, center)) {
                bestDist = d;
                best = c;
            }
        }
        return best;
    }

    private static LivingEntity findTarget(ServerWorld world, ServerPlayerEntity player, Vec3d from) {
        Box box = new Box(from, from).expand(RICOCHET_RANGE);
        List<LivingEntity> list = world.getEntitiesByClass(LivingEntity.class, box,
                e -> e != player && !(e instanceof PlayerEntity) && e.isAlive()
                        && !e.isSpectator() && !(e instanceof ArmorStandEntity));
        LivingEntity best = null;
        double bestScore = Double.MAX_VALUE;
        for (LivingEntity e : list) {
            Vec3d center = e.getBoundingBox().getCenter();
            double d = from.squaredDistanceTo(center);
            if (d > RICOCHET_RANGE * RICOCHET_RANGE || !clear(world, player, from, center)) continue;
            double score = d + (e instanceof Monster ? 0.0 : 100000.0); // hostile mobs first
            if (score < bestScore) {
                bestScore = score;
                best = e;
            }
        }
        return best;
    }

    private static void tracer(ServerWorld world, ParticleEffect particle, Vec3d from, Vec3d to) {
        Vec3d delta = to.subtract(from);
        double length = delta.length();
        if (length < 0.1) return;
        Vec3d step = delta.multiply(1.0 / length);
        for (double t = 0.0; t < length; t += 0.6) {
            Vec3d p = from.add(step.multiply(t));
            world.spawnParticles(particle, p.x, p.y, p.z, 1, 0.0, 0.0, 0.0, 0.0);
        }
    }

    private void playShot(ServerWorld world, ServerPlayerEntity player) {
        world.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.ENTITY_FIREWORK_ROCKET_BLAST, SoundCategory.PLAYERS, 1.0F, variant.pitch);
    }

    private static void chime(ServerWorld world, Vec3d pos, int level) {
        float pitch = Math.min(2.0F, 0.8F + 0.2F * level);
        world.playSound(null, pos.x, pos.y, pos.z,
                SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, SoundCategory.PLAYERS, 1.0F, pitch);
    }
}
