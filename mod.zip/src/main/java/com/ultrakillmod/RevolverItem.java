package com.ultrakillmod;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

public class RevolverItem extends Item {
    private final Variant variant;

    public RevolverItem(Settings settings, Variant variant) {
        super(settings);
        this.variant = variant;
    }

    public Variant getVariant() {
        return variant;
    }

    @Override
    public ActionResult use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (world instanceof ServerWorld serverWorld && user instanceof ServerPlayerEntity player) {
            fire(serverWorld, player);
            player.getItemCooldownManager().set(stack, variant.cooldownTicks);
        }
        return ActionResult.SUCCESS;
    }

    private record Hit(LivingEntity entity, double distSq) {}

    private void fire(ServerWorld world, ServerPlayerEntity player) {
        Vec3d start = player.getEyePos();
        Vec3d dir = player.getRotationVec(1.0F);
        Vec3d end = start.add(dir.multiply(variant.range));

        // Stop the shot at the first solid block.
        BlockHitResult blockHit = world.raycast(new RaycastContext(
                start, end, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, player));
        Vec3d stop = blockHit.getType() == HitResult.Type.MISS ? end : blockHit.getPos();
        double length = start.distanceTo(stop);

        // Find every living thing along the ray.
        Box area = new Box(start, stop).expand(1.0);
        List<LivingEntity> candidates = world.getEntitiesByClass(
                LivingEntity.class, area, e -> e != player && e.isAlive() && !e.isSpectator());
        List<Hit> hits = new ArrayList<>();
        for (LivingEntity e : candidates) {
            Optional<Vec3d> point = e.getBoundingBox().expand(0.15).raycast(start, stop);
            if (point.isPresent()) {
                hits.add(new Hit(e, start.squaredDistanceTo(point.get())));
            }
        }
        hits.sort(Comparator.comparingDouble(Hit::distSq));

        int gain = 0;
        DamageSource source = world.getDamageSources().playerAttack(player);
        for (Hit hit : hits) {
            hit.entity().damage(world, source, variant.damage);
            gain += 30;
            if (!hit.entity().isAlive()) {
                gain += 70;
            }
            if (!variant.pierce) {
                break;
            }
        }

        // Tracer particles from just below the eyes to the impact point.
        Vec3d origin = start.add(dir.multiply(1.2)).add(0.0, -0.15, 0.0);
        for (double d = 0.0; d < length - 1.2; d += 0.6) {
            Vec3d p = origin.add(dir.multiply(d));
            world.spawnParticles(variant.particle, p.x, p.y, p.z, 1, 0.0, 0.0, 0.0, 0.0);
        }

        world.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.ENTITY_FIREWORK_ROCKET_BLAST, SoundCategory.PLAYERS, 1.0F, variant.pitch);

        if (gain > 0) {
            ServerPlayNetworking.send(player, new Networking.StylePayload(gain, variant.ordinal()));
        }
    }
}
