package com.ultrakillmod;

import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;

import java.util.ArrayList;
import java.util.List;

public final class ModItems {
    public static final List<RevolverItem> REVOLVERS = new ArrayList<>();

    public static RevolverItem PIERCER_REVOLVER;
    public static RevolverItem MARKSMAN_REVOLVER;
    public static RevolverItem SHARPSHOOTER_REVOLVER;
    public static Item COIN;

    private ModItems() {}

    private static RevolverItem registerRevolver(String name, Variant variant) {
        RegistryKey<Item> key = RegistryKey.of(RegistryKeys.ITEM, UltrakillMod.id(name));
        RevolverItem item = new RevolverItem(new Item.Settings().registryKey(key).maxCount(1), variant);
        Registry.register(Registries.ITEM, key, item);
        REVOLVERS.add(item);
        return item;
    }

    public static void register() {
        PIERCER_REVOLVER = registerRevolver("piercer_revolver", Variant.PIERCER);
        MARKSMAN_REVOLVER = registerRevolver("marksman_revolver", Variant.MARKSMAN);
        SHARPSHOOTER_REVOLVER = registerRevolver("sharpshooter_revolver", Variant.SHARPSHOOTER);

        RegistryKey<Item> coinKey = RegistryKey.of(RegistryKeys.ITEM, UltrakillMod.id("coin"));
        COIN = Registry.register(Registries.ITEM, coinKey, new Item(new Item.Settings().registryKey(coinKey).maxCount(1)));
    }

    /** Next variant in the cycle: Piercer -> Marksman -> Sharpshooter -> Piercer. */
    public static RevolverItem next(RevolverItem current) {
        int i = REVOLVERS.indexOf(current);
        return REVOLVERS.get((i + 1) % REVOLVERS.size());
    }
}
