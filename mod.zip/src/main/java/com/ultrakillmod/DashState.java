package com.ultrakillmod;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Vec3d;

/** Client-side dash stamina: 3 charges, each refills in about 2 seconds. */
public final class DashState {
    public static final float MAX_CHARGES = 3f;
    private static float charge = MAX_CHARGES;
    private static int cooldown = 0;

    private DashState() {}

    public static float charge() {
        return charge;
    }

    public static void tick() {
        charge = Math.min(MAX_CHARGES, charge + 1f / 40f);
        if (cooldown > 0) cooldown--;
    }

    public static void tryDash(ClientPlayerEntity player) {
        if (cooldown > 0 || charge < 1f) return;
        charge -= 1f;
        cooldown = 6;

        // Dash in the direction you are facing (horizontal).
        double yaw = Math.toRadians(player.getYaw());
        double dx = -Math.sin(yaw);
        double dz = Math.cos(yaw);
        double speed = 1.5;
        Vec3d v = player.getVelocity();
        player.setVelocity(dx * speed, v.y * 0.3, dz * speed);

        player.playSound(SoundEvents.ENTITY_ENDER_DRAGON_FLAP, 0.7f, 1.8f);
    }
}
