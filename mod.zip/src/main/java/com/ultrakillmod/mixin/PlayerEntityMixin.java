package com.ultrakillmod.mixin;

import com.ultrakillmod.SlideTracker;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** While sliding, force the low crawl pose (0.6 blocks tall) so you fit under 1-block gaps. */
@Mixin(PlayerEntity.class)
public abstract class PlayerEntityMixin {
    @Inject(method = "updatePose", at = @At("TAIL"))
    private void ultrakill$slidePose(CallbackInfo ci) {
        PlayerEntity self = (PlayerEntity) (Object) this;
        if (SlideTracker.isSliding(self.getUuid())) {
            self.setPose(EntityPose.SWIMMING);
        }
    }
}
