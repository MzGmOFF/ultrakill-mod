package com.ultrakillmod.mixin;

import com.ultrakillmod.SparBot;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Tells the spar bot about titles the server shows ("Match over", ...). require = 0: never crashes if a name differs. */
@Mixin(InGameHud.class)
public abstract class InGameHudMixin {
    @Inject(method = "setTitle", at = @At("HEAD"), require = 0)
    private void ultrakill$title(Text title, CallbackInfo ci) {
        SparBot.onServerText(title, true);
    }

    @Inject(method = "setSubtitle", at = @At("HEAD"), require = 0)
    private void ultrakill$subtitle(Text subtitle, CallbackInfo ci) {
        SparBot.onServerText(subtitle, true);
    }
}
