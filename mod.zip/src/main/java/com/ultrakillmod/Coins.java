package com.ultrakillmod;

import net.minecraft.entity.ItemEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

/** Tossed coins: floating glowing item entities that expire after about 2 seconds. */
public final class Coins {
    public record Coin(ItemEntity entity, int expireTick) {}

    private static final List<Coin> COINS = new ArrayList<>();
    private static final int LIFETIME_TICKS = 40;
    private static final int MAX_COINS = 4;

    private Coins() {}

    public static void spawn(ServerWorld world, ServerPlayerEntity player, int nowTick) {
        Vec3d dir = player.getRotationVec(1.0F);
        Vec3d pos = player.getEyePos().add(dir.multiply(0.6)).add(0.0, -0.3, 0.0);

        ItemEntity entity = new ItemEntity(world, pos.x, pos.y, pos.z, new ItemStack(ModItems.COIN));
        entity.setPickupDelay(32767); // never picked up, never merged
        entity.setGlowing(true);
        entity.setVelocity(dir.x * 0.3, 0.42, dir.z * 0.3);
        world.spawnEntity(entity);

        COINS.add(new Coin(entity, nowTick + LIFETIME_TICKS));
        while (COINS.size() > MAX_COINS) {
            COINS.remove(0).entity().discard();
        }

        world.playSound(null, pos.x, pos.y, pos.z,
                SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, SoundCategory.PLAYERS, 0.6F, 1.6F);
    }

    public static void remove(Coin coin) {
        coin.entity().discard();
        COINS.remove(coin);
    }

    public static List<Coin> alive() {
        return new ArrayList<>(COINS);
    }

    public static void tick(int nowTick) {
        COINS.removeIf(c -> {
            if (c.entity().isRemoved()) return true;
            if (nowTick >= c.expireTick()) {
                c.entity().discard();
                return true;
            }
            return false;
        });
    }
}
