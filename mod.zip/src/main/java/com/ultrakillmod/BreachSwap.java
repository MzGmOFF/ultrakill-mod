package com.ultrakillmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Vec3d;

/**
 * Breach swap (client side), all inside one tick: sword slot -> mace slot -> hit.
 * Runs every time the key (H) is pressed. It does not care what items are in the slots, and it does not need a
 * target: if nothing is in reach, the hand just swings. Slot numbers are 0-based (hotbar slot 5 = index 4).
 */
public final class BreachSwap {
    private static final int SWORD_SLOT = 4;   // hotbar slot 5
    private static final int MACE_SLOT = 7;    // hotbar slot 8
    private static final double REACH = 4.5;

    private BreachSwap() {}

    public static void start(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        if (player == null || client.interactionManager == null) return;
        player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(SWORD_SLOT));
        player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(MACE_SLOT));
        player.getInventory().setSelectedSlot(MACE_SLOT);
        Entity target = findTarget(player);
        if (target != null) {
            client.interactionManager.attackEntity(player, target);
        }
        player.swingHand(Hand.MAIN_HAND);
    }

    /** What the crosshair is on, out to REACH blocks, whatever you are holding. */
    private static Entity findTarget(ClientPlayerEntity player) {
        Vec3d start = player.getEyePos();
        Vec3d dir = player.getRotationVec(1.0F);
        Vec3d end = start.add(dir.multiply(REACH));
        EntityHitResult hit = ProjectileUtil.raycast(player, start, end,
                player.getBoundingBox().stretch(dir.multiply(REACH)).expand(1.0),
                e -> !e.isSpectator() && e.canHit(), REACH * REACH);
        return hit == null ? null : hit.getEntity();
    }
}
