package com.ultrakillmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import org.joml.Matrix3x2fStack;

public final class UltrakillHud {
    private UltrakillHud() {}

    public static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;
        renderDash(ctx, mc);
        renderStyle(ctx, mc);
    }

    private static void renderDash(DrawContext ctx, MinecraftClient mc) {
        int w = mc.getWindow().getScaledWidth();
        int h = mc.getWindow().getScaledHeight();
        int x0 = w / 2 - 91;
        int y = h - 62;
        float charge = DashState.charge();
        for (int i = 0; i < 3; i++) {
            int sx = x0 + i * 31;
            ctx.fill(sx, y, sx + 28, y + 5, 0xAA000000);
            float f = Math.max(0f, Math.min(1f, charge - i));
            int fw = (int) (26 * f);
            int col = f >= 1f ? 0xFF3DD6FF : 0xFF1B7A99;
            if (fw > 0) {
                ctx.fill(sx + 1, y + 1, sx + 1 + fw, y + 4, col);
            }
        }
    }

    private static void renderStyle(DrawContext ctx, MinecraftClient mc) {
        float pts = StyleMeter.points();
        if (pts < 1f) return;

        TextRenderer tr = mc.textRenderer;
        int w = mc.getWindow().getScaledWidth();
        int rank = StyleMeter.rank();
        int color = StyleMeter.color(rank, mc.player.age);

        int pw = 112;
        int ph = 50;
        int px = w - pw - 8;
        int py = 10;

        ctx.fill(px, py, px + pw, py + ph, 0xA0000000);
        ctx.fill(px, py, px + 3, py + ph, color);

        // Rank-up flash.
        int flashAlpha = (int) (StyleMeter.flash() * 50f);
        if (flashAlpha > 0) {
            ctx.fill(px, py, px + pw, py + ph, (flashAlpha << 24) | 0xFFFFFF);
        }

        String name = StyleMeter.NAMES[rank];
        float scale = name.length() > 3 ? 1.6f : 3.2f;
        Matrix3x2fStack m = ctx.getMatrices();
        m.pushMatrix();
        m.translate(px + 10, py + 7);
        m.scale(scale, scale);
        ctx.drawText(tr, name, 0, 0, color, true);
        m.popMatrix();

        // Progress to the next rank.
        float lo = StyleMeter.THRESHOLDS[rank];
        float hi = rank + 1 < StyleMeter.THRESHOLDS.length ? StyleMeter.THRESHOLDS[rank + 1] : StyleMeter.MAX;
        float ratio = Math.max(0f, Math.min(1f, (pts - lo) / (hi - lo)));
        int bx = px + 10;
        int by = py + ph - 10;
        int bw = pw - 18;
        ctx.fill(bx, by, bx + bw, by + 4, 0xFF202020);
        ctx.fill(bx, by, bx + (int) (bw * ratio), by + 4, color);

        if (StyleMeter.varietyActive()) {
            ctx.drawText(tr, "+VARIETY", px, py + ph + 4, 0xFFFFD34D, true);
        }
    }
}
