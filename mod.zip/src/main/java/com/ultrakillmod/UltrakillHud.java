package com.ultrakillmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectCategory;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import org.joml.Matrix3x2fStack;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class UltrakillHud {
    private UltrakillHud() {}

    public static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;
        renderDash(ctx, mc);
        renderArmor(ctx, mc);
        renderEffects(ctx, mc);
        renderStyle(ctx, mc);
    }

    private static void renderDash(DrawContext ctx, MinecraftClient mc) {
        int w = mc.getWindow().getScaledWidth();
        int h = mc.getWindow().getScaledHeight();
        int x0 = w / 2 - 91;
        int y = h - 62;
        float charge = DashState.charge();
        for (int i = 0; i < 3; i++) {
            int sx = x0 + i * 31;
            ctx.fill(sx, y, sx + 28, y + 5, 0xAA000000);
            float f = Math.max(0f, Math.min(1f, charge - i));
            int fw = (int) (26 * f);
            int col = f >= 1f ? 0xFF3DD6FF : 0xFF1B7A99;
            if (fw > 0) {
                ctx.fill(sx + 1, y + 1, sx + 1 + fw, y + 4, col);
            }
        }
    }

    private static final EquipmentSlot[] ARMOR_SLOTS = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
    };

    /** Worn armor with durability, on the left of the hotbar. Pieces you are not wearing are skipped. */
    private static void renderArmor(DrawContext ctx, MinecraftClient mc) {
        List<ItemStack> worn = new ArrayList<>();
        for (EquipmentSlot slot : ARMOR_SLOTS) {
            ItemStack stack = mc.player.getEquippedStack(slot);
            if (!stack.isEmpty()) worn.add(stack);
        }
        if (worn.isEmpty()) return;

        TextRenderer tr = mc.textRenderer;
        int w = mc.getWindow().getScaledWidth();
        int h = mc.getWindow().getScaledHeight();

        int rowH = 17;
        int panelW = 63;
        int panelH = worn.size() * rowH + 2;
        // Just left of the hotbar (and the off-hand slot), but never off-screen.
        int px = Math.max(2, w / 2 - 91 - 34 - panelW);
        int py = h - panelH - 3;

        ctx.fill(px, py, px + panelW, py + panelH, 0x80000000);

        for (int i = 0; i < worn.size(); i++) {
            ItemStack stack = worn.get(i);
            int rx = px + 11; // left column is reserved for the warning mark
            int ry = py + 1 + i * rowH;
            ctx.drawItem(stack, rx, ry);

            if (stack.isDamageable()) {
                int max = stack.getMaxDamage();
                int left = Math.max(0, max - stack.getDamage());
                int percent = Math.round(100f * left / max);
                int color = 0xFF000000 | stack.getItemBarColor();

                // Under 10%: a red "!" next to this piece, blinking until it is repaired above 10%.
                boolean critical = left * 100f / max < 10f;
                if (critical) {
                    color = 0xFFFF3030;
                    if ((mc.player.age / 4) % 2 == 0) {
                        ctx.drawText(tr, "!", px + 4, ry + 4, 0xFFFF2020, true);
                    }
                }
                ctx.drawText(tr, percent + "%", rx + 19, ry + 1, color, true);
                int barW = 30;
                ctx.fill(rx + 19, ry + 11, rx + 19 + barW, ry + 14, 0xFF202020);
                ctx.fill(rx + 19, ry + 11, rx + 19 + Math.max(1, barW * left / max), ry + 14, color);
            }
        }
    }

    private static String roman(int n) {
        String[] r = {"", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};
        return n >= 1 && n < r.length ? r[n] : String.valueOf(n);
    }

    private static final int CELL = 24;
    private static final int CELL_GAP = 2;
    private static final int PER_ROW = 8;
    private static int effectsBottom = 6;

    private static String shortTime(int ticks) {
        int seconds = (ticks + 19) / 20;
        if (seconds < 60) return String.valueOf(seconds);
        return (seconds / 60) + ":" + String.format("%02d", seconds % 60);
    }

    /**
     * Potion effects, top-right: the effect icon with its timer on it.
     * Green frame = helpful, red frame = harmful. Flashes when 15 seconds or less are left.
     */
    private static void renderEffects(DrawContext ctx, MinecraftClient mc) {
        effectsBottom = 6;
        List<StatusEffectInstance> list = new ArrayList<>(mc.player.getStatusEffects());
        if (list.isEmpty()) return;
        list.sort(Comparator.comparingInt(e -> e.isInfinite() ? Integer.MAX_VALUE : e.getDuration()));

        TextRenderer tr = mc.textRenderer;
        int w = mc.getWindow().getScaledWidth();
        int total = Math.min(list.size(), 16);

        for (int i = 0; i < total; i++) {
            StatusEffectInstance effect = list.get(i);
            StatusEffect type = effect.getEffectType().value();
            boolean good = type.getCategory() == StatusEffectCategory.BENEFICIAL;
            int base = good ? 0xFF4CE06A : 0xFFFF5252;
            boolean blink = !effect.isInfinite() && effect.getDuration() <= 300
                    && (mc.player.age / 4) % 2 == 0;

            int row = i / PER_ROW;
            int col = i % PER_ROW;
            int x = w - 4 - (col + 1) * CELL - col * CELL_GAP;
            int y = 4 + row * (CELL + 2);

            // Frame and background (the background floods with the colour while blinking).
            ctx.fill(x, y, x + CELL, y + CELL, base);
            int bg = blink ? (0xC0000000 | (base & 0x00FFFFFF)) : 0xD0101010;
            ctx.fill(x + 1, y + 1, x + CELL - 1, y + CELL - 1, bg);

            // Effect icon.
            Identifier id = Registries.STATUS_EFFECT.getId(type);
            if (id != null) {
                Identifier sprite = Identifier.of(id.getNamespace(), "mob_effect/" + id.getPath());
                ctx.drawGuiTexture(RenderPipelines.GUI_TEXTURED, sprite, x + 3, y + 3, 18, 18);
            }

            // Level, top-left.
            if (effect.getAmplifier() > 0) {
                ctx.drawText(tr, roman(effect.getAmplifier() + 1), x + 2, y + 2, 0xFFFFFFFF, true);
            }

            // Timer, on the icon.
            String time = effect.isInfinite() ? "inf" : shortTime(effect.getDuration());
            int tx = x + (CELL - tr.getWidth(time)) / 2;
            ctx.drawText(tr, time, tx, y + CELL - 10, blink ? 0xFFFFFFFF : base, true);
        }

        int rows = (total - 1) / PER_ROW + 1;
        effectsBottom = 4 + rows * (CELL + 2);
    }

    private static void renderStyle(DrawContext ctx, MinecraftClient mc) {
        float pts = StyleMeter.points();
        if (pts < 1f) return;

        TextRenderer tr = mc.textRenderer;
        int w = mc.getWindow().getScaledWidth();
        int rank = StyleMeter.rank();
        int color = StyleMeter.color(rank, mc.player.age);

        int pw = 112;
        int ph = 50;
        int px = w - pw - 8;
        int py = effectsBottom + 4;

        ctx.fill(px, py, px + pw, py + ph, 0xA0000000);
        ctx.fill(px, py, px + 3, py + ph, color);

        // Rank-up flash.
        int flashAlpha = (int) (StyleMeter.flash() * 50f);
        if (flashAlpha > 0) {
            ctx.fill(px, py, px + pw, py + ph, (flashAlpha << 24) | 0xFFFFFF);
        }

        String name = StyleMeter.NAMES[rank];
        float scale = name.length() > 3 ? 1.6f : 3.2f;
        Matrix3x2fStack m = ctx.getMatrices();
        m.pushMatrix();
        m.translate(px + 10, py + 7);
        m.scale(scale, scale);
        ctx.drawText(tr, name, 0, 0, color, true);
        m.popMatrix();

        // Progress to the next rank.
        float lo = StyleMeter.THRESHOLDS[rank];
        float hi = rank + 1 < StyleMeter.THRESHOLDS.length ? StyleMeter.THRESHOLDS[rank + 1] : StyleMeter.MAX;
        float ratio = Math.max(0f, Math.min(1f, (pts - lo) / (hi - lo)));
        int bx = px + 10;
        int by = py + ph - 10;
        int bw = pw - 18;
        ctx.fill(bx, by, bx + bw, by + 4, 0xFF202020);
        ctx.fill(bx, by, bx + (int) (bw * ratio), by + 4, color);

        if (StyleMeter.varietyActive()) {
            ctx.drawText(tr, "+VARIETY", px, py + ph + 4, 0xFFFFD34D, true);
        }
    }
}
