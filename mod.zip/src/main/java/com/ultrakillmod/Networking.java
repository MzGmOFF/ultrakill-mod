package com.ultrakillmod;

import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.item.ItemStack;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Hand;

public final class Networking {
    private Networking() {}

    /** Client -> server: "cycle my revolver variant". */
    public record SwitchPayload() implements CustomPayload {
        public static final CustomPayload.Id<SwitchPayload> ID = new CustomPayload.Id<>(UltrakillMod.id("switch_variant"));
        public static final PacketCodec<RegistryByteBuf, SwitchPayload> CODEC = PacketCodec.unit(new SwitchPayload());

        @Override
        public CustomPayload.Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    /** Server -> client: "you earned style points with this variant". */
    public record StylePayload(int gain, int variant) implements CustomPayload {
        public static final CustomPayload.Id<StylePayload> ID = new CustomPayload.Id<>(UltrakillMod.id("style"));
        public static final PacketCodec<RegistryByteBuf, StylePayload> CODEC = PacketCodec.tuple(
                PacketCodecs.VAR_INT, StylePayload::gain,
                PacketCodecs.VAR_INT, StylePayload::variant,
                StylePayload::new);

        @Override
        public CustomPayload.Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    public static void register() {
        PayloadTypeRegistry.playC2S().register(SwitchPayload.ID, SwitchPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(StylePayload.ID, StylePayload.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(SwitchPayload.ID, (payload, context) -> {
            ServerPlayerEntity player = context.player();
            if (player.getMainHandStack().getItem() instanceof RevolverItem current) {
                player.setStackInHand(Hand.MAIN_HAND, new ItemStack(ModItems.next(current)));
            }
        });
    }
}
