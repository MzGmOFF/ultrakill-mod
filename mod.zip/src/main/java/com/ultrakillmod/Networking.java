package com.ultrakillmod;

import io.netty.buffer.ByteBuf;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.item.ItemStack;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Hand;

public final class Networking {
    private Networking() {}

    /** Client -> server: "cycle my revolver variant". */
    public record SwitchPayload() implements CustomPayload {
        public static final CustomPayload.Id<SwitchPayload> ID = new CustomPayload.Id<>(UltrakillMod.id("switch_variant"));
        public static final PacketCodec<RegistryByteBuf, SwitchPayload> CODEC = PacketCodec.unit(new SwitchPayload());

        @Override
        public CustomPayload.Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    /** Client -> server: "toss a coin". */
    public record CoinPayload() implements CustomPayload {
        public static final CustomPayload.Id<CoinPayload> ID = new CustomPayload.Id<>(UltrakillMod.id("toss_coin"));
        public static final PacketCodec<RegistryByteBuf, CoinPayload> CODEC = PacketCodec.unit(new CoinPayload());

        @Override
        public CustomPayload.Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    /** Client -> server: "I started / stopped sliding". */
    public record SlidePayload(boolean active) implements CustomPayload {
        public static final CustomPayload.Id<SlidePayload> ID = new CustomPayload.Id<>(UltrakillMod.id("slide"));
        public static final PacketCodec<ByteBuf, SlidePayload> CODEC =
                PacketCodecs.BOOLEAN.xmap(SlidePayload::new, SlidePayload::active);

        @Override
        public CustomPayload.Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    /** Server -> client: "you earned style points with this variant". */
    public record StylePayload(int gain, int variant) implements CustomPayload {
        public static final CustomPayload.Id<StylePayload> ID = new CustomPayload.Id<>(UltrakillMod.id("style"));
        public static final PacketCodec<RegistryByteBuf, StylePayload> CODEC = PacketCodec.tuple(
                PacketCodecs.VAR_INT, StylePayload::gain,
                PacketCodecs.VAR_INT, StylePayload::variant,
                StylePayload::new);

        @Override
        public CustomPayload.Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    public static void register() {
        PayloadTypeRegistry.playC2S().register(SwitchPayload.ID, SwitchPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(CoinPayload.ID, CoinPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(SlidePayload.ID, SlidePayload.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(SlidePayload.ID, (payload, context) ->
                SlideTracker.set(context.player().getUuid(), payload.active()));
        PayloadTypeRegistry.playS2C().register(StylePayload.ID, StylePayload.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(CoinPayload.ID, (payload, context) -> {
            ServerPlayerEntity player = context.player();
            // Coins are the Marksman's thing.
            if (player.getMainHandStack().getItem() != ModItems.MARKSMAN_REVOLVER) return;
            // Find the world this player is in.
            for (ServerWorld world : context.server().getWorlds()) {
                if (world.getPlayerByUuid(player.getUuid()) == player) {
                    Coins.spawn(world, player, context.server().getTicks());
                    break;
                }
            }
        });

        ServerPlayNetworking.registerGlobalReceiver(SwitchPayload.ID, (payload, context) -> {
            ServerPlayerEntity player = context.player();
            if (player.getMainHandStack().getItem() instanceof RevolverItem current) {
                player.setStackInHand(Hand.MAIN_HAND, new ItemStack(ModItems.next(current)));
            }
        });
    }
}
