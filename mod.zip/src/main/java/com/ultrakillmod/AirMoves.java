package com.ultrakillmod;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

/** Client-side air moves: double jump (Space in mid-air) and ground slam (Shift in mid-air, 2+ blocks up). */
public final class AirMoves {
    private static final double DOUBLE_JUMP_SPEED = 0.8;   // vanilla jump is 0.42
    private static final double SLAM_SPEED = -2.0;
    private static final double MIN_SLAM_HEIGHT = 2.0;

    private static boolean prevJump = false;
    private static boolean prevSneak = false;
    private static boolean doubleJumpUsed = false;
    private static boolean slamming = false;
    private static int airTicks = 0;
    private static double slamStartY = 0.0;

    private AirMoves() {}

    public static void reset() {
        prevJump = false;
        prevSneak = false;
        doubleJumpUsed = false;
        slamming = false;
        airTicks = 0;
    }

    public static void tick(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        if (player == null || client.world == null) return;

        boolean jump = client.options.jumpKey.isPressed();
        boolean sneak = client.options.sneakKey.isPressed();
        boolean onGround = player.isOnGround();
        boolean blocked = player.getAbilities().flying || player.isTouchingWater()
                || player.isInLava() || player.hasVehicle() || player.isClimbing();

        if (blocked) {
            if (slamming) endSlam(player, 0);
            doubleJumpUsed = false;
            airTicks = 0;
            prevJump = jump;
            prevSneak = sneak;
            return;
        }

        if (onGround) {
            if (slamming) {
                endSlam(player, (int) Math.max(0.0, slamStartY - player.getY()));
            }
            airTicks = 0;
            doubleJumpUsed = false;
        } else {
            airTicks++;
        }

        // Double jump: a fresh Space press while in the air.
        if (jump && !prevJump && !onGround && airTicks > 2 && !doubleJumpUsed && !slamming) {
            Vec3d v = player.getVelocity();
            player.setVelocity(v.x, DOUBLE_JUMP_SPEED, v.z);
            doubleJumpUsed = true;
            player.playSound(SoundEvents.ENTITY_ENDER_DRAGON_FLAP, 0.8f, 1.4f);
        }

        // Ground slam: a fresh Shift press while at least 2 blocks above the ground.
        if (sneak && !prevSneak && !onGround && !slamming && highEnough(client, player)) {
            slamming = true;
            slamStartY = player.getY();
            ClientPlayNetworking.send(new Networking.SlamPayload(0, 0));
            player.playSound(SoundEvents.ENTITY_ENDER_DRAGON_FLAP, 0.8f, 0.6f);
        }

        if (slamming) {
            player.setVelocity(0.0, SLAM_SPEED, 0.0);
        }

        prevJump = jump;
        prevSneak = sneak;
    }

    private static boolean highEnough(MinecraftClient client, ClientPlayerEntity player) {
        Vec3d from = new Vec3d(player.getX(), player.getY(), player.getZ());
        BlockHitResult hit = client.world.raycast(new RaycastContext(
                from, from.add(0.0, -MIN_SLAM_HEIGHT, 0.0),
                RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, player));
        return hit.getType() == HitResult.Type.MISS;
    }

    private static void endSlam(ClientPlayerEntity player, int height) {
        slamming = false;
        ClientPlayNetworking.send(new Networking.SlamPayload(1, height));
    }
}
